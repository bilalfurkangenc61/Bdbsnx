# Copilot Instructions

## General Guidelines
- First general instruction
- Second general instruction

## Code Style
- Use specific formatting rules
- Follow naming conventions

## Project-Specific Rules
- �� ak��� karar�: Operasyon 2 a�amas�nda 'Mail g�nderdim = Hay�r' olsa bile durum 'Saha Canli Bekleniyor' olarak devam eder; m��teri kayd� olu�tu�unda `Musteri.Durum` her zaman 'Aktif' yaz�l�r.