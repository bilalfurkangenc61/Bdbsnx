namespace BtOperasyonTakip.ViewModels;

public sealed class VposDashboardViewModel
{
    public int ToplamMusteri { get; set; }
    public int BuAyEklenen { get; set; }
    public int LookbackMonths { get; set; } = 6;

    public bool GrafanaBilgisiKayitli { get; set; }
    public string? GrafanaKullaniciAdi { get; set; }
    public string? GrafanaUrl { get; set; }
    public string? ElasticUrl { get; set; }

    public bool GrafanaHazir { get; set; }
    public string? GrafanaMesaj { get; set; }
    public DateTime? GrafanaGuncellemeZamani { get; set; }

    public string? DatasourceAdi { get; set; }
    public string? DatasourceUid { get; set; }
    public string? Index { get; set; }
    public string? TimestampField { get; set; }
    public string? CompanyField { get; set; }
    public string? ErrorCodeField { get; set; }

    public List<string> Aylar { get; set; } = new();
    public List<VposFirmaIslemSerisiViewModel> FirmaSerileri { get; set; } = new();
    public List<VposHataKodViewModel> HataKodlari { get; set; } = new();
    public List<VposFirmaHataViewModel> HataAlanFirmalar { get; set; } = new();
    public VposInsightsViewModel? Insights { get; set; }
    public VposBankPerformanceViewModel? BankaPerformansi { get; set; }
}

public sealed class VposFirmaIslemSerisiViewModel
{
    public string Firma { get; set; } = string.Empty;
    public List<long> Degerler { get; set; } = new();
    public long Toplam { get; set; }
}

public sealed class VposHataKodViewModel
{
    public string HataKodu { get; set; } = string.Empty;
    public long Adet { get; set; }
    public string? ElasticUrl { get; set; }
}

public sealed class VposGrafanaSnapshot
{
    public bool Basarili { get; set; }
    public string? Mesaj { get; set; }
    public DateTime AlinmaZamani { get; set; } = DateTime.Now;
    public int LookbackMonths { get; set; } = 6;

    public string? DatasourceAdi { get; set; }
    public string? DatasourceUid { get; set; }
    public string? Index { get; set; }
    public string? TimestampField { get; set; }
    public string? CompanyField { get; set; }
    public string? ErrorCodeField { get; set; }

    public List<string> Aylar { get; set; } = new();
    public List<VposFirmaIslemSerisiViewModel> FirmaSerileri { get; set; } = new();
    public List<VposHataKodViewModel> HataKodlari { get; set; } = new();
    public List<VposFirmaHataViewModel> HataAlanFirmalar { get; set; } = new();
    public VposInsightsViewModel? Insights { get; set; }
    public VposBankPerformanceViewModel? BankaPerformansi { get; set; }
}

public sealed class VposGrafanaConnectionTest
{
    public bool Basarili { get; set; }
    public string? Mesaj { get; set; }
    public string? DatasourceAdi { get; set; }
    public string? DatasourceUid { get; set; }
    public string? Index { get; set; }
    public string? TimestampField { get; set; }
    public string? CompanyField { get; set; }
    public string? ErrorCodeField { get; set; }
}

public sealed class VposFirmaHataViewModel
{
    public string Firma { get; set; } = string.Empty;
    public long HataAdedi { get; set; }
}

public sealed class VposInsightsViewModel
{
    public long SimdikiIslem { get; set; }
    public long OncekiIslem { get; set; }
    public long SimdikiHataKoduKaydi { get; set; }
    public long OncekiHataKoduKaydi { get; set; }
    public List<VposMonthlySummary> Aylik { get; set; } = new();
    public string? Uyari { get; set; }
}
public sealed class VposMonthlySummary
{
    public string Ay { get; set; } = "";
    public long Islem { get; set; }
    public long HataKoduKaydi { get; set; }
}

public sealed class VposBankPerformanceViewModel
{
    public string? BankField { get; set; }
    public string? DurationField { get; set; }
    public double? P50 { get; set; }
    public double? P95 { get; set; }
    public double? P99 { get; set; }
    public List<VposBankRowViewModel> Banks { get; set; } = new();
}
public sealed class VposBankRowViewModel
{
    public string Bank { get; set; } = "";
    public long TotalRecords { get; set; }
    public long ErrorCodeRecords { get; set; }
}
