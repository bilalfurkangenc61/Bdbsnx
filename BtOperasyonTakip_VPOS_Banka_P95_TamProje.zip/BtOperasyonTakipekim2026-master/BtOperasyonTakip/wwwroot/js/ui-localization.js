﻿(function () {
    const storageKey = 'ui-language-en-v1';
    const defaultLanguage = 'en';
    const supportedLanguages = new Set(['tr', 'en']);
    const skipTags = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'CODE', 'PRE', 'TEXTAREA']);

    const exactTranslations = {
        tr: {
            'Operations Tracking': 'Operasyon Takip',
            'Operations Tracking System': 'Operasyon Takip Sistemi',
            'Home': 'Ana Sayfa',
            'Customers': 'Müşteriler',
            'Details': 'Detaylar',
            'Excel Import': 'Excel Aktarım',
            'Meeting Notes': 'Toplantı Notları',
            'Work Tracking': 'İş Takip',
            'Tickets': 'Ticketlar',
            'Issues': 'Hatalar',
            'Leave Tracking': 'İzin Takip',
            'Parameters': 'Parametreler',
            'User List': 'Kullanıcı Listesi',
            'User Management': 'Kullanıcı Yönetimi',
            'Field Team Work': 'Saha Ekibi İşleri',
            'Saha Super Admin': 'Saha Süper Admin',
            'Role': 'Rol',
            'Make Field Super Admin': 'Saha Süper Admin Yap',
            'Normal Field User': 'Normal Saha Yap',
            'Operations Super Admin': 'Operasyon Süper Admin',
            'Make Operations Super Admin': 'Operasyon Süper Admin Yap',
            'Normal Operations User': 'Normal Operasyon Yap',
            'Admin can promote field users to Field Super Admin or revoke the permission here.': 'Admin buradan saha kullanıcılarını Saha Süper Admin yapabilir veya geri alabilir.',
            'Admin can promote field users to Field Super Admin and operations users to Operations Super Admin, or revoke those permissions here.': 'Admin buradan saha kullanıcılarını Saha Süper Admin, operasyon kullanıcılarını Operasyon Süper Admin yapabilir veya geri alabilir.',
            'You can promote field users to Field Super Admin or revoke the permission.': 'Saha kullanıcılarını Saha Süper Admin yapabilir veya geri alabilirsiniz.',
            'Field Super Admin view shows all active work assigned to field users. Normal field users still see only their own assigned work.': 'Saha Süper Admin görünümü, saha kullanıcılarına atanmış tüm aktif işleri gösterir. Normal saha kullanıcıları yine sadece kendi atanmış işlerini görür.',
            'No active work assigned to field users was found. Matching is based on the Assigned To field of work tracking records.': 'Saha kullanıcılarına atanmış aktif iş bulunamadı. Eşleşme iş takip kayıtlarındaki Takip Eden alanına göre yapılır.',
            'Actions': 'İşlemler',
            '+ Add New User': '+ Yeni Kullanıcı Ekle',
            'Sign In': 'Giriş',
            'Sign Out': 'Çıkış Yap',
            'Manage operations from a single hub.': 'Operasyon süreçlerini tek merkezden yönetin.',
            'Manage customers, tickets, issues, meeting notes, and work tracking flows in a faster and more organized way.': 'Müşteri, ticket, hata, toplantı notları ve iş takip akışlarını daha düzenli ve hızlı şekilde yönetin.',
            'Customer Management': 'Müşteri Yönetimi',
            'Ticket Tracking': 'Ticket Takibi',
            'Secure sign-in provides role-based screen routing.': 'Güvenli giriş ile rol bazlı ekranlara yönlendirme yapılır.',
            'Secure Sign-In': 'Güvenli Giriş',
            'Welcome': 'Hoş geldiniz',
            'Sign in with your account to continue': 'Devam etmek için hesabınızla giriş yapın',
            'Username': 'Kullanıcı Adı',
            'Enter your username': 'Kullanıcı adınızı girin',
            'Password': 'Şifre',
            'Enter your password': 'Şifrenizi girin',
            'Remember Me': 'Beni Hatırla',
            'Register': 'Kayıt Ol',
            'Create New Account': 'Yeni Hesap Oluştur',
            'Email': 'E-posta',
            'User Type': 'Kullanıcı Tipi',
            'Already have an account? Sign in': 'Zaten hesabın var mı? Giriş yap',
            'Welcome Page': 'Karşılama Sayfası',
            'You have successfully signed in to the IT Operations Tracking system.': 'BT Operasyon Takip sistemine başarıyla giriş yaptın.',
            'Enter Dashboard': 'Panele Giriş Yap',
            'Redirecting...': 'Yönlendiriliyor...',
            'Starting the system...': 'Sistemi başlatıyor...',
            'Establishing the database connection...': 'Veritabanı bağlantısı kuruluyor...',
            'Loading modules...': 'Modüller yükleniyor...',
            'Preparing the dashboard...': 'Dashboard hazırlanıyor...',
            'Monthly Filter': 'Aylık Filtre',
            'Apply': 'Uygula',
            'Total Customers': 'Toplam Müşteri',
            'Selected Month Customers': 'Seçili Ay Müşteri',
            'Added This Month': 'Aylık Eklenen',
            'Active Customers': 'Aktif Müşteri',
            'Selected Month Active Customers': 'Seçili Ay Aktif Müşteri',
            'Overall Portfolio': 'Genel Portföy',
            'Open Jira Items': 'Jira Açık',
            'Total Issues': 'Toplam Hata',
            'Customer Status': 'Müşteri Durumu',
            'Status distribution for the selected month': 'Seçili aydaki durum dağılımı',
            'Monthly Customer Growth': 'Aylık Müşteri Artışı',
            'New customer trend over the last 6 months': 'Son 6 ay yeni müşteri trendi',
            'Monthly New Record': 'Aylık Yeni Kayıt',
            'New record trend over the last 6 months': 'Son 6 ay yeni kayıt trendi',
            'New Records': 'Yeni Kayıtlar',
            'Jira Status': 'Jira Durumu',
            'Pending, active, and completed work items': 'Bekleyen, aktif ve tamamlanan işler',
            'Ticket Status': 'Ticket Durumu',
            'Awaiting approval, approved, and rejected items': 'Onay bekleyen, onaylanan ve reddedilenler',
            'System Tickets': 'Sistem Ticketları',
            'No Tickets Found': 'Ticket Bulunmuyor',
            'No tickets have been created yet.': 'Henüz hiç ticket oluşturulmamıştır.',
            'Ticket Search': 'Ticket Arama',
            'Filter by website, developer, email, or creator': 'Web sitesi, yazılımcı, mail veya oluşturan ile filtrele',
            'Search...': 'Arayın...',
            'File name / customer / description / added by...': 'Dosya adı / müşteri / açıklama / ekleyen...',
            'Clear': 'Temizle',
            'Search Company': 'Firma Ara',
            'Enter company name...': 'Firma adı yazın...',
            'Requested By': 'Kimden Geldi',
            'Open operation flow faster': 'İş akışını daha hızlı yönetin',
            'Manage person-based view, quick filtering, task status updates, and detail tracking on a single screen.': 'Kişi bazlı görünüm, hızlı filtreleme, görev durumu güncelleme ve detay takibini tek ekranda yönetin.',
            'View:': 'Görünüm:',
            'All People': 'Tüm Kişiler',
            'Search Customer': 'Müşteri Ara',
            'Company, contact, phone, technology...': 'Firma, yetkili, telefon, teknoloji...',
            'Excel Month (empty = All Months)': 'Excel Ay (boş = Tüm Aylar)',
            'Choose File': 'Dosya Seç',
            'No file selected': 'Dosya seçilmedi',
            'Excel Month': 'Excel Ay',
            'Full Excel': 'Tüm Excel',
            'New Customers Excel': 'Yeni Müşteriler Excel',
            'Filter': 'Filtrele',
            'Customer': 'Müşteri',
            'Authorized Person': 'Yetkili',
            'Status': 'Durum',
            'Status *': 'Durum *',
            'Description is required when changing status.': 'Durum değiştirirken açıklama zorunludur.',
            'Requester': 'Talep Sahibi',
            'Phone': 'Telefon',
            'Description': 'Açıklama',
            'Created Date': 'Kayıt Tarihi',
            'Status Date': 'Durum Tarihi',
            'Source': 'Kaynak',
            'Website URL': 'Site URL',
            'Technology': 'Teknoloji',
            'Company Name *': 'Firma Adı *',
            'Authorized Contact': 'Firma Yetkilisi',
            'Open Website': 'Siteyi Aç',
            'Total': 'Toplam',
            'Displayed': 'Gösterilen',
            'Page': 'Sayfa',
            'Previous': 'Önceki',
            'Next': 'Sonraki',
            'Search': 'Ara',
            'Search Section': 'Arama',
            'Filter by customer, creator, or note content.': 'Müşteri, ekleyen veya not içeriğine göre filtreleyin.',
            'All': 'Tümü',
            'Open Details': 'Detayları Aç',
            'Edit Customer': 'Müşteri Düzenle',
            'Select': 'Seçiniz',
            'Cancel': 'İptal',
            'Update': 'Güncelle',
            'Delete': 'Sil',
            'Date Range': 'Tarih Aralığı',
            'Add Work Item': 'İş Ekle',
            'Create a new record quickly with key information': 'Temel bilgilerle hızlı kayıt oluşturun',
            'Default status: Pending': 'Varsayılan durum: Beklemede',
            'Filters and view': 'Filtreler ve görünüm',
            'Manage person, search, and column view from a single panel': 'Kişi, arama ve kolon görünümünü tek panelden yönetin',
            'Person': 'Kişi',
            'Column Filter': 'Kolon Filtre',
            'Extra status columns': 'Ek durum kolonları',
            'Month': 'Ay',
            'Month:': 'Ay:',
            'May 2025': 'Mayıs 2025',
            'April 2025': 'Nisan 2025',
            'Visible work in selected month': 'Seçilen ayda görünen iş',
            'Select status': 'Durum seçiniz',
            'Selected columns': 'Seçilen kolonlar',
            'Work Type': 'İş Tipi',
            'Request Subject': 'Talep Konusu',
            'Assigned To': 'Takip Eden',
            'Search customer...': 'Müşteri ara...',
            'Search by typing...': 'Yazarak ara...',
            'Subject / Requester / Assignee / Status...': 'Konu / Açan / Takip Eden / Durum...',
            'This Page': 'Bu Sayfa',
            'Records awaiting action': 'Aksiyon bekleyen kayıt',
            'Ongoing work': 'Devam eden iş',
            'Closed work': 'Kapanmış iş',
            'In-progress work': 'Çalışılan işler',
            'Completed work': 'Sonuçlanan işler',
            'Records for this status': 'Bu duruma ait kayıtlar',
            'Note:': 'Not:',
            'This screen displays 6 active tracking columns side by side. Records in Compliance Approval are listed in the Pending column; they appear as Compliance Approval under the Status filter in Excel.': 'Bu ekranda 6 aktif takip kolonu yan yana gösterilir. Uyum Onayında olan kayıtlar Beklemede kolonunda listelenir; Excelde Durum filtresinde Uyum Onayında olarak görünür.',
            'Rejected': 'Reddedildi',
            'Pending': 'Beklemede',
            'Compliance Approval': 'Uyum Onayında',
            'In Compliance Approval': 'Uyum Onayında',
            'Active': 'Aktif',
            'Inactive': 'Pasif',
            'Completed': 'Tamamlandı',
            'Document Sent': 'Döküman İletildi',
            'Awaiting Approval': 'Onay Bekleyen',
            'Approved': 'Onaylanan',
            'Open': 'Açık',
            'Closed': 'Kapalı',
            'On Hold': 'Askıda',
            'Other': 'Diğer',
            'Issue': 'Hata',
            'Issue List': 'Hata Listesi',
            'New': 'Yeni',
            'No records found.': 'Kayıt yok.',
            'No records yet.': 'Henüz kayıt yok.',
            'No customers found for the selected criteria.': 'Aradığınız kriterlere uygun müşteri bulunamadı.',
            'Excel (Grouped by JiraId)': 'Excel (JiraId Gruplu)',
            'Excel (All Months)': 'Excel (Tüm Aylar)',
            'Development / Training List': 'Geliştirme / Eğitim Listesi',
            'Download Excel': 'Excel İndir',
            'Skip to main content': 'Ana içeriğe geç',
            'Error': 'Hata',
            'An error occurred while processing your request.': 'İsteğiniz işlenirken bir hata oluştu.',
            'Request ID:': 'İstek ID:',
            'Development Mode': 'Geliştirme Modu',
            'Home Page': 'Ana Sayfa',
            'Learn about building Web apps with ASP.NET Core.': 'ASP.NET Core ile web uygulamaları geliştirme hakkında bilgi edinin.',
            'Issue Management': 'Hatalar Yönetimi',
            'Download Excel File': 'Excel\'e İndir',
            'Add New Issue': 'Yeni Hata Ekle',
            'Search issue name, description, or customer...': 'Hata adı, açıklama veya müşteri ara...',
            'All Statuses': 'Tüm Durumlar',
            'All Categories': 'Tüm Kategoriler',
            'Software': 'Yazılım',
            'Hardware': 'Donanım',
            'Network': 'Ağ',
            'Database': 'Veritabanı',
            'Category': 'Kategori',
            'Assigned User': 'Atanan Kullanıcı',
            'Date': 'Tarih',
            'Leave Tracker': 'İzin Takip',
            'Filters': 'Filtreler',
            'Quickly filter by company, status, or requester.': 'Firma, durum veya talep eden kişiye göre hızlı filtreleme yapın.',
            'Requester': 'Talep Eden',
            'Filter by status': 'Duruma göre filtrele',
            'Filter by requester': 'Talep edene göre filtrele',
            'No tickets yet.': 'Henüz ticket bulunmamaktadır.',
            'Ticket List': 'Ticket Listesi',
            'Details, status, and workflow information are displayed in a single table.': 'Detay, durum ve süreç bilgileri tek tabloda gösterilir.',
            'Assigned Operation': 'Atanan Operasyon',
            'Compliance Decision Maker': 'Uyum Kararı Veren',
            'Contact': 'İrtibat',
            'Action': 'İşlem',
            'Yes': 'Evet',
            'No': 'Hayır',
            'Operation 1 Approval Pending': 'Operasyon 1 Onay Bekleniyor',
            'Operation 2 Approval Pending': 'Operasyon 2 Onay Bekleniyor',
            'Compliance Approval Pending': 'Uyum Onay Bekleniyor',
            'Customer Recorded': 'Musteri Kaydedildi',
            'Field Go-Live Pending': 'Saha Canli Bekleniyor',
            'Missing Documents Pending': 'Eksik Evrak Bekleniyor',
            'Meeting Notes': 'Toplantı Notları',
            'Parameter Management': 'Parametre Yönetimi',
            'Manage system types and parameter values centrally': 'Sistem içindeki tür ve parametre değerlerini merkezi olarak yönetin',
            'Excel Upload': 'Excel Aktarım',
            'Upload an Excel file, save its data to the database, and process matching customer details.': 'Excel yükleyin, veriler veritabanına kaydedilsin ve eşleşen müşterilerin detaylarına işlensin.',
            'Matched': 'Eşleşen',
            'Unmatched': 'Eşleşmeyen',
            'Conversation Details': 'Görüşme Detayları',
            'You can open details by selecting from customer cards.': 'Müşteri kartlarından seçim yaparak detayları açabilirsiniz.',
            'Customer details': 'Müşteri detayları',
            'Total:': 'Toplam:',
            'Pending:': 'Beklemede:',
            'Active:': 'Aktif:',
            'Document Sent:': 'Döküman İletildi:',
            'Customer #': 'Müşteri #',
            'Record:': 'Kayıt:',
            'Latest Detail': 'Son Detay',
            'Added Latest Comment': 'Son Yorumu Ekleyen',
            'Site': 'Site',
            'Latest Comment': 'Son Yorum',
            'Latest Work / Contact': 'Son İş / Görüşülen',
            'Selected Customer:': 'Seçilen Müşteri:',
            'User Management': 'Kullanıcı Yönetimi',
            'Field Team Work': 'Saha Ekibi İşleri',
            'Saha Super Admin': 'Saha Süper Admin',
            'Role': 'Rol',
            'Make Field Super Admin': 'Saha Süper Admin Yap',
            'Normal Field User': 'Normal Saha Yap',
            'Operations Super Admin': 'Operasyon Süper Admin',
            'Make Operations Super Admin': 'Operasyon Süper Admin Yap',
            'Normal Operations User': 'Normal Operasyon Yap',
            'Admin can promote field users to Field Super Admin or revoke the permission here.': 'Admin buradan saha kullanıcılarını Saha Süper Admin yapabilir veya geri alabilir.',
            'Admin can promote field users to Field Super Admin and operations users to Operations Super Admin, or revoke those permissions here.': 'Admin buradan saha kullanıcılarını Saha Süper Admin, operasyon kullanıcılarını Operasyon Süper Admin yapabilir veya geri alabilir.',
            'You can promote field users to Field Super Admin or revoke the permission.': 'Saha kullanıcılarını Saha Süper Admin yapabilir veya geri alabilirsiniz.',
            'Field Super Admin view shows all active work assigned to field users. Normal field users still see only their own assigned work.': 'Saha Süper Admin görünümü, saha kullanıcılarına atanmış tüm aktif işleri gösterir. Normal saha kullanıcıları yine sadece kendi atanmış işlerini görür.',
            'No active work assigned to field users was found. Matching is based on the Assigned To field of work tracking records.': 'Saha kullanıcılarına atanmış aktif iş bulunamadı. Eşleşme iş takip kayıtlarındaki Takip Eden alanına göre yapılır.',
            'Actions': 'İşlemler',
            'Delete': 'Sil',
            'Total Records': 'Toplam Kayıt',
            'Total Types': 'Toplam Tür',
            'New Parameter': 'Yeni Parametre',
            'New Type': 'Yeni Tür',
            'Add Type': 'Tür Ekle',
            'Add New Type': 'Yeni Tür Ekle',
            'Status Management': 'Durum Yönetimi',
            'Parameter List': 'Parametre Listesi',
            'Parameter Name': 'Parametre Adı',
            'Parameter Type': 'Parametre Türü',
            'Type': 'Tür',
            'Order': 'Sıra',
            'Move Up': 'Yukarı',
            'Move Down': 'Aşağı',
            'Visible in Work Tracking columns': 'İş Takip kolonu olarak görünür',
            'Configure the order of columns and status visibility for the Work Tracking screen here.': 'İş Takip ekranındaki kolon sırasını ve durum görünümünü buradan yönetin',
            'Add a new parameter value to an existing type.': 'Mevcut bir türe yeni parametre değeri ekleyin',
            'Define a new type for parameter groups.': 'Parametre grupları için yeni tür tanımlayın',
            'Meeting Notes': 'Toplantı Notları',
            'Meeting Type': 'Toplantı Türü',
            'Work Tracking column': 'İş Takip kolonu',
            'Back to Work Tracking': 'İş Takip\'e Dön',
            'Excluded development and training work items are listed here.': 'Excel\'e dahil edilmeyen geliştirme ve eğitim işleri burada listelenir.',
            'No record found.': 'Kayıt bulunamadı.',
            'No record found': 'Kayıt bulunamadı',
            'New Parameter Value': 'Yeni Parametre Değeri',
            'Record No:': 'Kayıt No:',
            'Issue Name': 'Hata Adı',
            'Created By': 'Oluşturan',
            'Record Creator': 'Kayıt Ekleyen',
            'Company Website': 'Müşteri Web Sitesi',
            'Developer Name': 'Yazılımcı',
            'Meeting Title': 'Toplantı Başlığı',
            'Meeting Notes': 'Toplantı Notları',
            'Meeting Type': 'Toplantı Türü',
            'Action Owner': 'Aksiyon Sahibi',
            'Target Date': 'Hedef Tarihi',
            'Participants': 'Katılımcı',
            'Conversation Date': 'Görüşme Tarihi',
            'Date Time': 'Tarih Saat',
            'Business / Contact': 'İş / Görüşülen',
            'Added By': 'Ekleyen',
            'Excel Transfer': 'Excel Aktarım',
            'Upload Excel': 'Excel Yükle',
            'Import starts if one of these columns exists: Customer/Company, Date, Work-Contact, Description, Added By.': 'Şu sütunlardan biri varsa aktarım yapılır: Müşteri/Firma, Tarih, İş-Görüşülen, Açıklama, Ekleyen.',
            'Matched Customers': 'Eşleşen Müşteriler',
            'Unmatched Customers': 'Eşleşmeyen Müşteriler',
            'Record deleted.': 'Kayıt silindi.',
            'Task added.': 'Görev eklendi.',
            'Status updated.': 'Durum güncellendi.',
            'Assigned user updated.': 'Takip eden güncellendi.',
            'Comment added.': 'Yorum eklendi.',
            'Comment cannot be empty.': 'Yorum boş olamaz.',
            'Invalid status update.': 'Geçersiz durum güncellemesi.',
            'Invalid work type selected.': 'Geçersiz iş tipi seçildi.',
            'Invalid record.': 'Geçersiz kayıt.',
            'Task not found.': 'Görev bulunamadı.',
            'Jira ID and Request Subject are required.': 'Jira ID ve Talep Konusu zorunludur.',
            'Selected customer could not be found.': 'Seçilen müşteri bulunamadı.',
            'Request Subject is required.': 'Talep Konusu zorunludur.',
            'Document status cannot be updated for this customer.': 'Bu müşteri için döküman durumu güncellenemez.',
            'Company name is required.': 'Firma adı zorunludur.',
            'Please select a valid status.': 'Geçerli bir durum seçiniz.',
            'Customer not found.': 'Müşteri bulunamadı.',
            'Document status updated.': 'Döküman durumu güncellendi.',
            'Customer added successfully!': 'Müşteri başarıyla eklendi!',
            'Customer updated successfully!': 'Müşteri başarıyla güncellendi!',
            'No records were found to import from Excel.': 'Excel içinde aktarılacak kayıt bulunamadı.',
            'Please select an Excel file.': 'Lütfen bir Excel dosyası seçiniz.',
            'Only .xlsx files can be uploaded.': 'Sadece .xlsx dosyaları yüklenebilir.',
            'Note content updated': 'Not içeriği güncellendi',
            'Created successfully.': 'Başarıyla oluşturuldu.',
            'Updated successfully.': 'Başarıyla güncellendi.',
            'Deleted successfully.': 'Başarıyla silindi.',
            'Issue': 'Hata',
            'Assigned': 'Atanan',
            'Detail': 'Detay',
            'Download to Excel': 'Excel\'e İndir',
            'Export to Excel': 'Excel\'e Aktar',
            'Leave allowance defined': 'Tanımlı izin hakkı',
            'Approved leave used': 'Onaylanmış kullanılan izin',
            'Remaining leave': 'Kalan izin',
            'day': 'gün',
            'Update Leave Request': 'İzin Talebini Güncelle',
            'New Leave Request': 'Yeni İzin Talebi',
            'Every saved change is sent back to admin approval.': 'Kaydedilen her değişiklik admin onayına yeniden düşer.',
            'Start Date': 'Başlangıç Tarihi',
            'End Date': 'Bitiş Tarihi',
            'Description / Reason': 'Açıklama / Mazeret',
            'Update and Send for Approval': 'Güncelle ve Onaya Gönder',
            'Create Request': 'Talep Oluştur',
            'User Leave Balances': 'Kullanıcı İzin Hakları',
            'Only operation users are listed.': 'Sadece operasyon kullanıcıları listelenir.',
            'User': 'Kullanıcı',
            'Total Allowance': 'Toplam Hak',
            'Used': 'Kullanılan',
            'Remaining': 'Kalan',
            'New Allowance Definition': 'Yeni Hak Tanımı',
            'No operation user found.': 'Operasyon kullanıcısı bulunamadı.',
            'Save': 'Kaydet',
            'All Leave Requests': 'Tüm İzin Talepleri',
            'My Leave Requests': 'İzin Taleplerim',
            'Edited records are moved back to pending.': 'Düzenlenen kayıtlar tekrar beklemeye alınır.',
            'Request Owner': 'Talep Sahibi',
            'Day': 'Gün',
            'Admin Note': 'Admin Notu',
            'Request Date': 'Talep Tarihi',
            'No leave request exists yet.': 'Henüz izin talebi bulunmuyor.',
            'Edit': 'Düzenle',
            'Approval note or rejection reason...': 'Onay notu veya red mazereti...',
            'Approve': 'Onayla',
            'Reject': 'Reddet',
            'Manage operation leave requests and define leave balances.': 'Operasyon izin taleplerini yönetin ve izin hakkı tanımlayın.',
            'Create or update your leave request and track the admin decision.': 'İzin talebinizi oluşturun, güncelleyin ve admin kararını takip edin.',
            'Total Parameter': 'Toplam Parametre',
            'No parameter is defined yet for the Status type.': 'Henüz Durum türünde parametre tanımlı değil.',
            'Defined types and parameter values': 'Tanımlı türler ve parametre değerleri',
            'Name': 'Ad',
            'The values of': 'değerleri parametrelerden çekilir.',
            'New Ticket Create': 'Yeni Ticket Oluştur',
            'New Ticket Oluştur': 'Yeni Ticket Oluştur',
            'Enter customer, payment, and technical details completely through a single form.': 'Müşteri, ödeme ve teknik bilgileri tek form üzerinden eksiksiz girin.',
            'Process starts: Operation 1': 'Süreç başlangıcı: Operasyon 1',
            'Customer type is required': 'Müşteri tipi zorunlu',
            'Ticket Information': 'Ticket Bilgileri',
            'Fill in the required fields and create the record.': 'Zorunlu alanları doldurup kaydı oluşturun.',
            'General Information': 'Genel Bilgiler',
            'Company Name': 'Firma Adı',
            'What Will the Customer Use?': 'Müşteri Ne Kullanacak?',
            'Who Developed the Website?': 'Web Sitesi Kim Tarafından Yazıldı?',
            'What Payment Methods Will Be Used?': 'Hangi Ödeme Yöntemleri Kullanılacak?',
            'Developer First Name': 'Yazılımcı Adı',
            'Developer Last Name': 'Yazılımcı Soyadı',
            'Email Address': 'Mail Adresi',
            'Contact Number': 'İrtibat Numarası',
            'Process Summary': 'Süreç Özeti',
            'After submission, the ticket directly moves to the Operation 1 approval step. Completing all required fields accelerates the process.': 'Kayıt sonrası ticket doğrudan Operasyon 1 onay adımına düşer. Gerekli alanları eksiksiz doldurmanız süreci hızlandırır.',
            'Things to Watch': 'Dikkat Edilecekler',
            'If there is already an open ticket for the same company, website, or email, the record is blocked.': 'Aynı firma, site veya mail için açık ticket varsa kayıt engellenir.',
            'Company, website, and contact details must be entered completely.': 'Firma, web sitesi ve iletişim bilgileri eksiksiz girilmelidir.',
            'Payment and website selections must be marked correctly.': 'Ödeme ve web sitesi seçimleri doğru işaretlenmelidir.',
            'Actions': 'Aksiyonlar',
            'Go to the Submit Button Below': 'Aşağıdaki Gönder Butonuna Git',
            'Back to List': 'Listeye Dön',
            'Send Ticket': 'Ticket Gönder',
            'At least one topic must be entered.': 'En az bir konu girmelisiniz.',
            'No records to display in this column.': 'Bu kolonda gösterilecek kayıt yok.',
            'Do you want to delete this record?': 'Bu kaydı silmek istiyor musunuz?',
            'Total (DB):': 'Toplam (DB):',
            'records · Page': 'kayıt · Sayfa',
            'Meeting record created.': 'Toplantı kaydı oluşturuldu.',
            'Record validation failed.': 'Kayıt doğrulanamadı.',
            'Empty status': 'Durum boş olamaz.',
            'Task not found': 'Görev bulunamadı.',
            'Status updated': 'Durum güncellendi.',
            'Error:': 'Hata:',
            'Invalid model': 'Geçersiz kayıt.',
            'Record not found': 'Kayıt bulunamadı.',
            'Yet': 'Henüz',
            'The up / down buttons define the column order.': 'Yukarı / aşağı butonları kolon sırasını belirler.',
            'No parameter is defined for the Status type yet.': 'Henüz Durum türünde parametre tanımlı değil.',
            'Customer Meeting Notes': 'Müşteri Toplantı Notları',
            'Create, review, and export meeting records.': 'Toplantı kayıtlarını oluşturun, inceleyin ve dışa aktarın.',
            'Type Options': 'Tür Seçenekleri',
            'Filter by customer, creator, or note content.': 'Müşteri, ekleyen veya not içeriğine göre filtreleyin.',
            'Search (Customer / Creator / Note)': 'Ara (Müşteri / Ekleyen / Not)',
            'New Meeting Record': 'Yeni Toplantı Kaydı',
            'Save meeting information and subject/target dates from a single form.': 'Toplantı bilgilerini ve konu/hedef tarihlerini tek formdan kaydedin.',
            'Meeting Title *': 'Toplantı Başlığı *',
            'Location *': 'Konum *',
            'Date *': 'Tarih *',
            'Time *': 'Saat *',
            'Prepared By *': 'Hazırlayan *',
            'Participants *': 'Katılımcılar *',
            'Topics and Target Dates *': 'Konular ve Hedef Tarihleri *',
            'Add New Topic': 'Yeni Konu Ekle',
            'Meeting Note': 'Toplantı Notu',
            'Meeting Minutes': 'Toplantı Tutanağı',
            'Name': 'İsim',
            'Meeting Title:': 'Toplantı Başlığı:',
            'Location:': 'Konum:',
            'Time:': 'Saat:',
            'Prepared By:': 'Hazırlayan:',
            'Participants:': 'Katılımcılar:',
            'Excel File (.xlsx)': 'Excel Dosyası (.xlsx)',
            'If a matching customer is found, the related record is also added to the Details page.': 'Eşleşen müşteri bulunursa ilgili kayıt Detaylar sayfasına da eklenir.',
            'Upload and Save': 'Yükle ve Kaydet',
            'Imported Records': 'İçe Aktarılan Kayıtlar',
            'You can view the Excel data uploaded on this page separately.': 'Bu sayfada yüklediğiniz Excel verilerini ayrı olarak görüntüleyebilirsiniz.',
            'Upload': 'Yükleme',
            'File': 'Dosya',
            'Row': 'Satır',
            'Uploader': 'Yükleyen',
            'Matched': 'Eşleşti',
            'Not Matched': 'Eşleşmedi',
            'Go to Details': 'Detaya Git',
            'No imported records yet.': 'Henüz aktarılmış kayıt yok.',
            'Username': 'Kullanıcı Adı',
            'Email Address': 'E-posta',
            'Meeting Minutes': 'Toplantı Tutanağı',
            'Meeting Title': 'Toplantı Başlığı',
            'Location': 'Konum',
            'Topic': 'Konu',
            'Target Date': 'Hedef Tarihi',
            'Prepared By': 'Hazırlayan',
            'Action Owner': 'Aksiyon Sahibi',
            'Please select an Excel file.': 'Lütfen bir Excel dosyası seçiniz.',
            'Excel could not be read:': 'Excel okunamadı:',
            'records were imported.': 'kayıt içe aktarıldı.',
            'records were added to details.': 'kayıt detaylara eklendi.',
            'Ticket created. Operation 1 approval is pending.': 'Ticket oluşturuldu. Operasyon 1 onayı bekleniyor.',
            'Invalid ticket ID.': 'Geçersiz ticket ID.',
            'Ticket not found.': 'Ticket bulunamadı.',
            'You cannot perform this action because this ticket is not assigned to you.': 'Bu ticket size atanmadığı için işlem yapamazsınız.',
            'Operation 1 decision saved. Compliance approval is pending.': 'Operasyon 1 kararı kaydedildi. Uyum onayı bekleniyor.',
            'Operation 2 decision saved.': 'Operasyon 2 kararı kaydedildi.',
            'Integration completed. Ticket was moved back to Field Go-Live Pending status.': 'Entegrasyon tamamlandı. Ticket tekrar Saha Canli Bekleniyor durumuna alındı.',
            'Go-live recorded. Customer record was created or updated.': 'Canlı açılış kaydedildi. Müşteri kaydı oluşturuldu veya güncellendi.',
            'Ticket rejected.': 'Ticket reddedildi.',
            'Missing document completed. Ticket was sent back to compliance approval.': 'Eksik evrak tamamlandı. Ticket yeniden uyum onayına gönderildi.',
            'Request is invalid.': 'Geçersiz istek.',
            'Change reason is required.': 'Değişiklik nedeni zorunlu.',
            'Change reason must be at most 500 characters.': 'Değişiklik nedeni maksimum 500 karakter olmalıdır.',
            'The selected user is not in the operation role or could not be found.': 'Seçilen kullanıcı operasyon rolünde değil veya bulunamadı.',
            'The selected status is not valid.': 'Seçilen durum geçerli değil.',
            'No assignee or status change was made.': 'Kişi veya durum değişikliği yapmadınız.',
            'Assignee assignment updated.': 'Kişi ataması güncellendi.',
            'Assignee and status updated.': 'Kişi ve durum güncellendi.',
            'An open ticket already exists for this company name.': 'Bu firma adı ile açık bir ticket zaten var.',
            'An open ticket already exists for this website.': 'Bu web sitesi ile açık bir ticket zaten var.',
            'An open ticket already exists for this email address.': 'Bu mail adresi ile açık bir ticket zaten var.',
            'Customer type must be either Corporate or Individual.': 'Müşteri tipi \u0027Kurumsal\u0027 veya \u0027Bireysel\u0027 olmalıdır.',
            'The user named test could not be found for corporate ticket assignment. The user must have the Operation role and UserName value test.': 'Kurumsal ticket ataması için \u0027test\u0027 kullanıcısı bulunamadı. Kullanıcı Operasyon rolünde olmalı ve UserName değeri \u0027test\u0027 olmalıdır.',
            'Only the field user who opened the ticket can perform this action.': 'Sadece ticket\u0027ı açan saha kullanıcısı bu işlemi yapabilir.',
            'Description is required.': 'Açıklama zorunlu.',
            'Assignee updated.': 'Kişi ataması güncellendi.',
            'Assignee and status updated. ({0} → {1})': 'Kişi ve durum güncellendi. ({0} → {1})',
            'Status updated. ({0} → {1})': 'Durum güncellendi. ({0} → {1})',
            'Integration action is not valid at this stage. Status:': 'Ticket bu aşamada entegrasyon tamamlama işlemine uygun değil. Durum:',
            'Operation 1 action is not valid at this stage. Status:': 'Ticket bu aşamada Operasyon 1 kararına uygun değil. Durum:',
            'Operation 2 action is not valid at this stage. Status:': 'Ticket bu aşamada Operasyon 2 kararına uygun değil. Durum:',
            'Go-live action is not valid at this stage. Status:': 'Ticket bu aşamada canlı açılışa uygun değil. Durum:',
            'Missing document completion is not valid at this stage. Status:': 'Ticket bu aşamada eksik evrak tamamlama işlemine uygun değil. Durum:',
            'Customer Website': 'Müşteri Web Sitesi',
            'Developer': 'Yazılımcı',
            'Issue Resolution': 'Hata Çözüm',
            'Development': 'Geliştirme',
            'Training': 'Eğitim',
            'Integration': 'Entegrasyon',
            'Prepared': 'Hazır',
            'Back': 'Geri',
            'Include in Excel': 'Excel\'e dahil et',
            'International': 'Uluslararası',
            'Conversation': 'Görüşme',
            'Meeting': 'Toplantı',
            'Type': 'Türü',
            'Record Not Found': 'Kayıt bulunamadı',
            'No matching records were found.': 'Aradığınız kriterlere uygun kayıt bulunamadı.',
            'All Status': 'Tüm Durum',
            'All Categories': 'Tüm Kategoriler',
            'All Record Types': 'Tüm Türler',
            'Title': 'Başlık',
            'Notes': 'Notlar',
            'Approved By': 'Onaylayan',
            'Approval Date': 'Onay Tarihi',
            'Created By': 'Oluşturan',
            'Record Creator': 'Kayıt Ekleyen',
            'Company Name': 'Firma Adı',
            'Open Details': 'Detay Aç',
            'No data found.': 'Veri bulunamadı.',
            'No result found': 'Sonuç bulunamadı',
            'Awaiting': 'Bekleyen',
            'Dismissed': 'Reddedilen',
            'Back Out': 'Vazgeç',
            'Cancel Action': 'İptal Et',
            'Mail': 'Mail',
            'Track the current list and workflow steps on a single screen.': 'Mevcut liste ve süreç adımları tek ekranda izlenir.',
            'Saved': 'Kaydedilen',
            'New Ticket': 'Yeni Ticket',
            'Search by company name or developer name...': '🔍 Firma adı, yazılımcı adı ile ara...',
            'Search status...': 'Durum ara...',
            'Search requester...': 'Talep eden ara...',
            'Not selected': 'Seçilmedi',
            'Ticket Details': 'Ticket Detayı',
            'Status:': 'Durum:',
            'Created By:': 'Oluşturan:',
            'Created On:': 'Oluşturma Tarihi:',
            'Customer Selections:': 'Müşteri Seçimleri:',
            'Payment Types:': 'Ödeme Türleri:',
            'Payment Methods:': 'Ödeme Yöntemleri:',
            'Website Type:': 'Web Sitesi Tipi:',
            'Decision:': 'Karar:',
            'Decision Maker:': 'Karar Veren:',
            'Note:': 'Not:',
            'Date:': 'Tarih:',
            'Description:': 'Açıklama:',
            '1) Operation 1:': '1) Operasyon 1:',
            '2) Compliance:': '2) Uyum:',
            '3) Operation 2:': '3) Operasyon 2:',
            '4) Field:': '4) Saha:',
            'Was the email sent?': 'Mail Gönderildi Mi:',
            'Go-Live Date:': 'Canlı Açıldı Tarihi:',
            'Assign Person / Status (Admin)': 'Kişi / Durum Ata (Admin)',
            'Select operation': 'Operasyon seçiniz',
            'Select status': 'Durum seçiniz',
            'Reason for change': 'Değişiklik nedeni',
            'Close': 'Kapat',
            'Operation 1 - Can Integrate': 'Operasyon 1 - Entegre Olur',
            'Operation 1 - Cannot Integrate': 'Operasyon 1 - Entegre Olmaz',
            'Operation 2 - Email Sent': 'Operasyon 2 - Mail Gönderildi',
            'Operation 2 - Email Not Sent': 'Operasyon 2 - Mail Gönderilmedi',
            'Integration Completed': 'Entegrasyon Tamamlandı',
            'Approve Go-Live': 'Canlı Açılışı Onayla',
            'Missing Documents Added': 'Eksik Evrakı Ekledim',
            'Go-Live Approval': 'Canlı Açılış Onayı',
            'Live Environment ID': 'Canlı Ortam ID',
            'Enter digits only': 'Sadece rakam girin',
            'Only digits can be entered in this field.': 'Bu alana sadece rakam girilebilir.',
            'Optional': 'Opsiyonel',
            'Confirm': 'Onayla',
            'No ticket selected.': 'Ticket seçilmedi.',
            'You must select a person or status.': 'Kişi veya durum seçmelisiniz.',
            'Reason for change is required.': 'Değişiklik nedeni zorunludur.',
            'Operation completed.': 'İşlem tamamlandı.',
            'An error occurred while changing the assignment.': 'Atama değişikliği sırasında bir hata oluştu.',
            'Operation 1 note (optional):': 'Operasyon 1 notu (opsiyonel):',
            'An error occurred during the Operation 1 decision.': 'Operasyon 1 kararı sırasında bir hata oluştu.',
            'Operation 1 rejection note (required):': 'Operasyon 1 ret notu (zorunlu):',
            'Rejection note is required.': 'Ret notu zorunludur.',
            'Operation 2 note (optional):': 'Operasyon 2 notu (opsiyonel):',
            'An error occurred during the Operation 2 decision.': 'Operasyon 2 kararı sırasında bir hata oluştu.',
            'Has the integration been completed? The ticket will be moved to the Field Go-Live Pending status.': 'Entegrasyon tamamlandı mı? Ticket Saha Canli Bekleniyor durumuna alınacaktır.',
            'An error occurred while completing the integration.': 'Entegrasyon tamamlama işlemi sırasında bir hata oluştu.',
            'Live environment ID is required.': 'Canlı ortam ID zorunludur.',
            'Live environment ID must contain digits only.': 'Canlı ortam ID sadece rakamlardan oluşmalıdır.',
            'An error occurred during go-live approval.': 'Canlı açılış onayı sırasında bir hata oluştu.',
            'Cancellation reason is required:': 'İptal nedeni zorunludur:',
            'Cancellation reason is required.': 'İptal nedeni zorunludur.',
            'An error occurred during cancellation.': 'İptal işlemi sırasında bir hata oluştu.',
            'Do you confirm that the missing document has been completed? The ticket will be sent back for compliance approval.': 'Eksik evrakın tamamlandığını onaylıyor musunuz? Ticket yeniden uyum onayına gönderilecektir.',
            'An error occurred while completing the missing document process.': 'Eksik evrak tamamlama işlemi sırasında bir hata oluştu.'
        },
        en: {
            'Operasyon Takip': 'Operations Tracking',
            'Operasyon Takip Sistemi': 'Operations Tracking System',
            'Ana Sayfa': 'Home',
            'Müşteriler': 'Customers',
            'Detaylar': 'Details',
            'Excel Aktarım': 'Excel Import',
            'Toplantı Notları': 'Meeting Notes',
            'İş Takip': 'Work Tracking',
            'Ticketlar': 'Tickets',
            'Hatalar': 'Issues',
            'İzin Takip': 'Leave Tracking',
            'Filtreler': 'Filters',
            'Firma, durum veya talep eden kişiye göre hızlı filtreleme yapın.': 'Quickly filter by company, status, or requester.',
            'Talep Eden': 'Requester',
            'Duruma göre filtrele': 'Filter by status',
            'Talep edene göre filtrele': 'Filter by requester',
            'Henüz ticket bulunmamaktadır.': 'No tickets yet.',
            'Ticket Listesi': 'Ticket List',
            'Detay, durum ve süreç bilgileri tek tabloda gösterilir.': 'Details, status, and workflow information are displayed in a single table.',
            'Atanan Operasyon': 'Assigned Operation',
            'Uyum Kararı Veren': 'Compliance Decision Maker',
            'İrtibat': 'Contact',
            'İşlem': 'Action',
            'Evet': 'Yes',
            'Hayır': 'No',
            'Operasyon 1 Onay Bekleniyor': 'Operation 1 Approval Pending',
            'Operasyon 2 Onay Bekleniyor': 'Operation 2 Approval Pending',
            'Uyum Onay Bekleniyor': 'Compliance Approval Pending',
            'Uyum Onayında': 'Compliance Approval',
            'Not:': 'Note:',
            'Bu ekranda 6 aktif takip kolonu yan yana gösterilir. Uyum Onayında olan kayıtlar Beklemede kolonunda listelenir; Excelde Durum filtresinde Uyum Onayında olarak görünür.': 'This screen displays 6 active tracking columns side by side. Records in Compliance Approval are listed in the Pending column; they appear as Compliance Approval under the Status filter in Excel.',
            'Musteri Kaydedildi': 'Customer Recorded',
            'Saha Canli Bekleniyor': 'Field Go-Live Pending',
            'Eksik Evrak Bekleniyor': 'Missing Documents Pending',
            'Parametreler': 'Parameters',
            'Kullanıcı Listesi': 'User List',
            'Giriş': 'Sign In',
            'Çıkış Yap': 'Sign Out',
            'Operasyon süreçlerini tek merkezden yönetin.': 'Manage operations from a single hub.',
            'Müşteri, ticket, hata, toplantı notları ve iş takip akışlarını daha düzenli ve hızlı şekilde yönetin.': 'Manage customers, tickets, issues, meeting notes, and work tracking flows in a faster and more organized way.',
            'Müşteri Yönetimi': 'Customer Management',
            'Ticket Takibi': 'Ticket Tracking',
            'Güvenli giriş ile rol bazlı ekranlara yönlendirme yapılır.': 'Secure sign-in provides role-based screen routing.',
            'Güvenli Giriş': 'Secure Sign-In',
            'Hoş geldiniz': 'Welcome',
            'Devam etmek için hesabınızla giriş yapın': 'Sign in with your account to continue',
            'Kullanıcı Adı': 'Username',
            'Kullanıcı adınızı girin': 'Enter your username',
            'Şifre': 'Password',
            'Şifrenizi girin': 'Enter your password',
            'Beni Hatırla': 'Remember Me',
            'Giriş Yap': 'Sign In',
            'Kayıt Ol': 'Register',
            'Yeni Hesap Oluştur': 'Create New Account',
            'E-posta': 'Email',
            'Kullanıcı Tipi': 'User Type',
            'Kaydol': 'Register',
            'Zaten hesabın var mı? Giriş yap': 'Already have an account? Sign in',
            'Karşılama Sayfası': 'Welcome Page',
            'BT Operasyon Takip sistemine başarıyla giriş yaptın.': 'You have successfully signed in to the IT Operations Tracking system.',
            'Panele Giriş Yap': 'Enter Dashboard',
            'Yönlendiriliyor...': 'Redirecting...',
            'Sistemi başlatıyor...': 'Starting the system...',
            'Veritabanı bağlantısı kuruluyor...': 'Establishing the database connection...',
            'Modüller yükleniyor...': 'Loading modules...',
            'Dashboard hazırlanıyor...': 'Preparing the dashboard...',
            'Aylık Filtre': 'Monthly Filter',
            'Uygula': 'Apply',
            'Toplam Müşteri': 'Total Customers',
            'Seçili Ay Müşteri': 'Selected Month Customers',
            'Aylık Eklenen': 'Added This Month',
            'Aktif Müşteri': 'Active Customers',
            'Seçili Ay Aktif Müşteri': 'Selected Month Active Customers',
            'Genel Portföy': 'Overall Portfolio',
            'Jira Açık': 'Open Jira Items',
            'Toplam Hata': 'Total Issues',
            'Müşteri Durumu': 'Customer Status',
            'Seçili aydaki durum dağılımı': 'Status distribution for the selected month',
            'Aylık Müşteri Artışı': 'Monthly Customer Growth',
            'Son 6 ay yeni müşteri trendi': 'New customer trend over the last 6 months',
            'Jira Durumu': 'Jira Status',
            'Bekleyen, aktif ve tamamlanan işler': 'Pending, active, and completed work items',
            'Ticket Durumu': 'Ticket Status',
            'Onay bekleyen, onaylanan ve reddedilenler': 'Awaiting approval, approved, and rejected items',
            'Sistem Ticketları': 'System Tickets',
            'Ticket Bulunmuyor': 'No Tickets Found',
            'Henüz hiç ticket oluşturulmamıştır.': 'No tickets have been created yet.',
            'Ticket Arama': 'Ticket Search',
            'Web sitesi, yazılımcı, mail veya oluşturan ile filtrele': 'Filter by website, developer, email, or creator',
            'Arayın...': 'Search...',
            'Dosya adı / müşteri / açıklama / ekleyen...': 'File name / customer / description / added by...',
            'Temizle': 'Clear',
            'Firma Ara': 'Search Company',
            'Firma adı yazın...': 'Enter company name...',
            'Kimden Geldi': 'Requested By',
            'İş akışını daha hızlı yönetin': 'Open operation flow faster',
            'Kişi bazlı görünüm, hızlı filtreleme, görev durumu güncelleme ve detay takibini tek ekranda yönetin.': 'Manage person-based view, quick filtering, task status updates, and detail tracking on a single screen.',
            'Görünüm:': 'View:',
            'Tüm Kişiler': 'All People',
            'Müşteri Ara': 'Search Customer',
            'Firma, yetkili, telefon, teknoloji...': 'Company, contact, phone, technology...',
            'Excel Ay (boş = Tüm Aylar)': 'Excel Month (empty = All Months)',
            'Dosya Seç': 'Choose File',
            'Dosya seçilmedi': 'No file selected',
            'Excel Ay': 'Excel Month',
            'Tüm Excel': 'Full Excel',
            'Yeni Müşteriler Excel': 'New Customers Excel',
            'Filtrele': 'Filter',
            'Müşteri': 'Customer',
            'Yetkili': 'Authorized Person',
            'Durum': 'Status',
            'Durum *': 'Status *',
            'Durum değiştirirken açıklama zorunludur.': 'Description is required when changing status.',
            'Talep Sahibi': 'Requester',
            'Telefon': 'Phone',
            'Açıklama': 'Description',
            'Kayıt Tarihi': 'Created Date',
            'Durum Tarihi': 'Status Date',
            'Kaynak': 'Source',
            'Site URL': 'Website URL',
            'Teknoloji': 'Technology',
            'Firma Adı *': 'Company Name *',
            'Firma Yetkilisi': 'Authorized Contact',
            'Siteyi Aç': 'Open Website',
            'Toplam': 'Total',
            'Gösterilen': 'Displayed',
            'Sayfa': 'Page',
            'Önceki': 'Previous',
            'Sonraki': 'Next',
            'Ara': 'Search',
            'Arama': 'Search Section',
            'Müşteri, ekleyen veya not içeriğine göre filtreleyin.': 'Filter by customer, creator, or note content.',
            'Tümü': 'All',
            'Detayları Aç': 'Open Details',
            'Müşteri Düzenle': 'Edit Customer',
            'Seçiniz': 'Select',
            'İptal': 'Cancel',
            'Güncelle': 'Update',
            'Sil': 'Delete',
            'Tarih Aralığı': 'Date Range',
            'İş Ekle': 'Add Work Item',
            'Temel bilgilerle hızlı kayıt oluşturun': 'Create a new record quickly with key information',
            'Varsayılan durum: Beklemede': 'Default status: Pending',
            'Filtreler ve görünüm': 'Filters and view',
            'Kişi, arama ve kolon görünümünü tek panelden yönetin': 'Manage person, search, and column view from a single panel',
            'Kişi': 'Person',
            'Kolon Filtre': 'Column Filter',
            'Ek durum kolonları': 'Extra status columns',
            'İş Tipi': 'Work Type',
            'Talep Konusu': 'Request Subject',
            'Talep Açan': 'Requested By',
            'Takip Eden': 'Assigned To',
            'Müşteri ara...': 'Search customer...',
            'Yazarak ara...': 'Search by typing...',
            'Konu / Açan / Takip Eden / Durum...': 'Subject / Requester / Assignee / Status...',
            'Bu Sayfa': 'This Page',
            'Aksiyon bekleyen kayıt': 'Records awaiting action',
            'Devam eden iş': 'Ongoing work',
            'Kapanmış iş': 'Closed work',
            'Aksiyon bekleyen kayıtlar': 'Records awaiting action',
            'Çalışılan işler': 'In-progress work',
            'Sonuçlanan işler': 'Completed work',
            'Bu duruma ait kayıtlar': 'Records for this status',
            'Detay': 'Details',
            'Reddedildi': 'Rejected',
            'Beklemede': 'Pending',
            'Aktif': 'Active',
            'Pasif': 'Inactive',
            'Tamamlandı': 'Completed',
            'Döküman İletildi': 'Document Sent',
            'Onay Bekleyen': 'Awaiting Approval',
            'Onaylanan': 'Approved',
            'Açık': 'Open',
            'Kapalı': 'Closed',
            'Askıda': 'On Hold',
            'Diğer': 'Other',
            'Hata': 'Issue',
            'Hata Listesi': 'Issue List',
            'Yeni': 'New',
            'Kayıt yok.': 'No records found.',
            'Henüz kayıt yok.': 'No records yet.',
            'Aradığınız kriterlere uygun müşteri bulunamadı.': 'No customers found for the selected criteria.',
            'Excel (JiraId Gruplu)': 'Excel (Grouped by JiraId)',
            'Excel (Tüm Aylar)': 'Excel (All Months)',
            'Geliştirme / Eğitim Listesi': 'Development / Training List',
            'Excel İndir': 'Download Excel',
            'Tüm Aylar': 'All Months',
            'Ana içeriğe geç': 'Skip to main content',
            'Error': 'Error',
            'Error.': 'Error.',
            'An error occurred while processing your request.': 'An error occurred while processing your request.',
            'Request ID:': 'Request ID:',
            'Development Mode': 'Development Mode',
            'Görüşme Detayları': 'Conversation Details',
            'Müşteri kartlarından seçim yaparak detayları açabilirsiniz.': 'You can open details by selecting from customer cards.',
            'Toplam:': 'Total:',
            'Beklemede:': 'Pending:',
            'Aktif:': 'Active:',
            'Döküman İletildi:': 'Document Sent:',
            'Müşteri #': 'Customer #',
            'Kayıt:': 'Record:',
            'Son Detay': 'Latest Detail',
            'Son Yorumu Ekleyen': 'Added Latest Comment',
            'Site': 'Site',
            'Son Yorum': 'Latest Comment',
            'Son İş / Görüşülen': 'Latest Work / Contact',
            'Seçilen Müşteri:': 'Selected Customer:',
            '+ Yeni Müşteri': '+ New Customer',
            'Kullanıcı Yönetimi': 'User Management',
            'Saha Süper Admin': 'Field Super Admin',
            'Saha Ekibi İşleri': 'Field Team Work',
            'Rol': 'Role',
            'Saha Süper Admin Yap': 'Make Field Super Admin',
            'Normal Saha Yap': 'Normal Field User',
            'Admin buradan saha kullanıcılarını Saha Süper Admin yapabilir veya geri alabilir.': 'Admin can promote field users to Field Super Admin or revoke the permission here.',
            'Admin buradan saha kullanıcılarını Saha Süper Admin, operasyon kullanıcılarını Operasyon Süper Admin yapabilir veya geri alabilir.': 'Admin can promote field users to Field Super Admin and operations users to Operations Super Admin, or revoke those permissions here.',
            'Operasyon Süper Admin': 'Operations Super Admin',
            'Operasyon Süper Admin Yap': 'Make Operations Super Admin',
            'Normal Operasyon Yap': 'Normal Operations User',
            'Saha kullanıcılarını Saha Süper Admin yapabilir veya geri alabilirsiniz.': 'You can promote field users to Field Super Admin or revoke the permission.',
            'Kullanıcı silinsin mi?': 'Delete this user?',
            'İşlemler': 'Actions',
            '+ Yeni Kullanıcı Ekle': '+ Add New User',
            'Excel\'e İndir': 'Download Excel File',
            'Yeni Hata Ekle': 'Add New Issue',
            'Hata adı, açıklama veya müşteri ara...': 'Search issue name, description, or customer...',
            'Tüm Durumlar': 'All Statuses',
            'Tüm Kategoriler': 'All Categories',
            'Yazılım': 'Software',
            'Donanım': 'Hardware',
            'Ağ': 'Network',
            'Veritabanı': 'Database',
            'Kategori': 'Category',
            'Atanan Kullanıcı': 'Assigned User',
            'Tarih': 'Date',
            'Hatalar Yönetimi': 'Issue Management',
            'Excel yükleyin, veriler veritabanına kaydedilsin ve eşleşen müşterilerin detaylarına işlensin.': 'Upload an Excel file, save its data to the database, and process matching customer details.',
            'Eşleşen': 'Matched',
            'Eşleşmeyen': 'Unmatched',
            'Parametre Yönetimi': 'Parameter Management',
            'Sistem içindeki tür ve parametre değerlerini merkezi olarak yönetin': 'Manage system types and parameter values centrally',
            'Hoşgeldiniz': 'Welcome',
            'İstek ID:': 'Request ID:',
            'İsteğiniz işlenirken bir hata oluştu.': 'An error occurred while processing your request.',
            'Geliştirme Modu': 'Development Mode',
            'Ana içeriğe geç': 'Skip to main content',
            'ASP.NET Core ile web uygulamaları geliştirme hakkında bilgi edinin.': 'Learn about building Web apps with ASP.NET Core.',
            'Toplantı Başlığı': 'Meeting Title',
            'Toplantı Tutanağı': 'Meeting Minutes',
            'Aksiyon Sahibi': 'Action Owner',
            'Hedef Tarihi': 'Target Date',
            'Katılımcı': 'Participants',
            'Hata Adı': 'Issue Name',
            'Müşteri Web Sitesi': 'Customer Website',
            'Yazılımcı': 'Developer',
            'Hata Çözüm': 'Issue Resolution',
            'Geliştirme': 'Development',
            'Eğitim': 'Training',
            'Entegrasyon': 'Integration',
            'Hazır': 'Prepared',
            'Geri': 'Back',
            'Kayıt bulunamadı': 'Record Not Found',
            'Aradığınız kriterlere uygun kayıt bulunamadı.': 'No matching records were found.',
            'Tüm Durum': 'All Status',
            'Tüm Türler': 'All Record Types',
            'Başlık': 'Title',
            'Notlar': 'Notes',
            'Onaylayan': 'Approved By',
            'Onay Tarihi': 'Approval Date',
            'Oluşturan': 'Created By',
            'Kayıt Ekleyen': 'Record Creator',
            'Firma Adı': 'Company Name',
            'Detay Aç': 'Open Details',
            'Veri bulunamadı.': 'No data found.',
            'Sonuç bulunamadı': 'No result found',
            'Toplam Kayıt': 'Total Records',
            'Toplam Tür': 'Total Types',
            'Yeni Parametre': 'New Parameter',
            'Yeni Tür': 'New Type',
            'Tür Ekle': 'Add Type',
            'Yeni Tür Ekle': 'Add New Type',
            'Durum Yönetimi': 'Status Management',
            'Parametre Listesi': 'Parameter List',
            'Parametre Adı': 'Parameter Name',
            'Parametre Türü': 'Parameter Type',
            'Tür': 'Type',
            'Sıra': 'Order',
            'Yukarı': 'Move Up',
            'Aşağı': 'Move Down',
            'İş Takip kolonu olarak görünür': 'Visible in Work Tracking columns',
            'İş Takip ekranındaki kolon sırasını ve durum görünümünü buradan yönetin': 'Configure the order of columns and status visibility for the Work Tracking screen here.',
            'Mevcut bir türe yeni parametre değeri ekleyin': 'Add a new parameter value to an existing type.',
            'Parametre grupları için yeni tür tanımlayın': 'Define a new type for parameter groups.',
            'Toplantı Türü': 'Meeting Type',
            'İş Takip kolonu': 'Work Tracking column',
            'İş Takip\'e Dön': 'Back to Work Tracking',
            'Excel\'e dahil edilmeyen geliştirme ve eğitim işleri burada listelenir.': 'Excluded development and training work items are listed here.',
            'Kayıt bulunamadı.': 'No record found.',
            'Kayıt bulunamadı': 'No record found',
            'Yeni Parametre Değeri': 'New Parameter Value',
            'Kayıt No:': 'Record No:',
            'Görev eklendi.': 'Task added.',
            'Durum güncellendi.': 'Status updated.',
            'Takip eden güncellendi.': 'Assigned user updated.',
            'Yorum eklendi.': 'Comment added.',
            'Kayıt silindi.': 'Record deleted.',
            'Yorum boş olamaz.': 'Comment cannot be empty.',
            'Geçersiz durum güncellemesi.': 'Invalid status update.',
            'Geçersiz iş tipi seçildi.': 'Invalid work type selected.',
            'Geçersiz kayıt.': 'Invalid record.',
            'Görev bulunamadı.': 'Task not found.',
            'Jira ID ve Talep Konusu zorunludur.': 'Jira ID and Request Subject are required.',
            'Seçilen müşteri bulunamadı.': 'Selected customer could not be found.',
            'Talep Konusu zorunludur.': 'Request Subject is required.',
            'Bu müşteri için döküman durumu güncellenemez.': 'Document status cannot be updated for this customer.',
            'Firma adı zorunludur.': 'Company name is required.',
            'Geçerli bir durum seçiniz.': 'Please select a valid status.',
            'Müşteri bulunamadı.': 'Customer not found.',
            'Döküman durumu güncellendi.': 'Document status updated.',
            'Müşteri başarıyla eklendi!': 'Customer added successfully!',
            'Müşteri başarıyla güncellendi!': 'Customer updated successfully!',
            'Excel içinde aktarılacak kayıt bulunamadı.': 'No records were found to import from Excel.',
            'Lütfen bir Excel dosyası seçiniz.': 'Please select an Excel file.',
            'Sadece .xlsx dosyaları yüklenebilir.': 'Only .xlsx files can be uploaded.',
            'Not içeriği güncellendi': 'Note content updated',
            'Hata Adı': 'Issue Name',
            'Oluşturan': 'Created By',
            'Müşteri Web Sitesi': 'Company Website',
            'Yazılımcı': 'Developer Name',
            'Görüşme Tarihi': 'Conversation Date',
            'Tarih Saat': 'Date Time',
            'İş / Görüşülen': 'Business / Contact',
            'Ekleyen': 'Added By',
            'Excel Aktarım': 'Excel Transfer',
            'Excel Yükle': 'Upload Excel',
            'Şu sütunlardan biri varsa aktarım yapılır: Müşteri/Firma, Tarih, İş-Görüşülen, Açıklama, Ekleyen.': 'Import starts if one of these columns exists: Customer/Company, Date, Work-Contact, Description, Added By.',
            'Eşleşen Müşteriler': 'Matched Customers',
            'Eşleşmeyen Müşteriler': 'Unmatched Customers',
            'Başarıyla oluşturuldu.': 'Created successfully.',
            'Başarıyla güncellendi.': 'Updated successfully.',
            'Başarıyla silindi.': 'Deleted successfully.',
            'Mevcut liste ve süreç adımları tek ekranda izlenir.': 'Track the current list and workflow steps on a single screen.',
            'Bekleyen': 'Awaiting',
            'Kaydedilen': 'Saved',
            'Reddedilen': 'Dismissed',
            'Vazgeç': 'Back Out',
            'İptal Et': 'Cancel Action',
            'Yeni Ticket': 'New Ticket',
            '🔍 Firma adı, yazılımcı adı ile ara...': 'Search by company name or developer name...',
            'Durum ara...': 'Search status...',
            'Talep eden ara...': 'Search requester...',
            'Seçilmedi': 'Not selected',
            'Mail': 'Mail',
            'Ticket Detayı': 'Ticket Details',
            'Durum:': 'Status:',
            'Oluşturan:': 'Created By:',
            'Oluşturma Tarihi:': 'Created On:',
            'Müşteri Seçimleri:': 'Customer Selections:',
            'Ödeme Türleri:': 'Payment Types:',
            'Ödeme Yöntemleri:': 'Payment Methods:',
            'Web Sitesi Tipi:': 'Website Type:',
            'Karar:': 'Decision:',
            'Karar Veren:': 'Decision Maker:',
            'Not:': 'Note:',
            'Tarih:': 'Date:',
            'Açıklama:': 'Description:',
            '1) Operasyon 1:': '1) Operation 1:',
            '2) Uyum:': '2) Compliance:',
            '3) Operasyon 2:': '3) Operation 2:',
            '4) Saha:': '4) Field:',
            'Mail Gönderildi Mi:': 'Was the email sent?',
            'Canlı Açıldı Tarihi:': 'Go-Live Date:',
            'Kişi / Durum Ata (Admin)': 'Assign Person / Status (Admin)',
            'Operasyon seçiniz': 'Select operation',
            'Durum seçiniz': 'Select status',
            'Değişiklik nedeni': 'Reason for change',
            'Kapat': 'Close',
            'Operasyon 1 - Entegre Olur': 'Operation 1 - Can Integrate',
            'Operasyon 1 - Entegre Olmaz': 'Operation 1 - Cannot Integrate',
            'Operasyon 2 - Mail Gönderildi': 'Operation 2 - Email Sent',
            'Operasyon 2 - Mail Gönderilmedi': 'Operation 2 - Email Not Sent',
            'Entegrasyon Tamamlandı': 'Integration Completed',
            'Canlı Açılışı Onayla': 'Approve Go-Live',
            'Eksik Evrakı Ekledim': 'Missing Documents Added',
            'Canlı Açılış Onayı': 'Go-Live Approval',
            'Canlı Ortam ID': 'Live Environment ID',
            'Sadece rakam girin': 'Enter digits only',
            'Bu alana sadece rakam girilebilir.': 'Only digits can be entered in this field.',
            'Opsiyonel': 'Optional',
            'Onayla': 'Confirm',
            'Ticket seçilmedi.': 'No ticket selected.',
            'Kişi veya durum seçmelisiniz.': 'You must select a person or status.',
            'Değişiklik nedeni zorunludur.': 'Reason for change is required.',
            'İşlem tamamlandı.': 'Operation completed.',
            'Atama değişikliği sırasında bir hata oluştu.': 'An error occurred while changing the assignment.',
            'Operasyon 1 notu (opsiyonel):': 'Operation 1 note (optional):',
            'Operasyon 1 kararı sırasında bir hata oluştu.': 'An error occurred during the Operation 1 decision.',
            'Operasyon 1 ret notu (zorunlu):': 'Operation 1 rejection note (required):',
            'Ret notu zorunludur.': 'Rejection note is required.',
            'Operasyon 2 notu (opsiyonel):': 'Operation 2 note (optional):',
            'Operasyon 2 kararı sırasında bir hata oluştu.': 'An error occurred during the Operation 2 decision.',
            'Entegrasyon tamamlandı mı? Ticket Saha Canli Bekleniyor durumuna alınacaktır.': 'Has the integration been completed? The ticket will be moved to the Field Go-Live Pending status.',
            'Entegrasyon tamamlama işlemi sırasında bir hata oluştu.': 'An error occurred while completing the integration.',
            'Canlı ortam ID zorunludur.': 'Live environment ID is required.',
            'Canlı ortam ID sadece rakamlardan oluşmalıdır.': 'Live environment ID must contain digits only.',
            'Canlı açılış onayı sırasında bir hata oluştu.': 'An error occurred during go-live approval.',
            'İptal nedeni zorunludur:': 'Cancellation reason is required:',
            'İptal nedeni zorunludur.': 'Cancellation reason is required.',
            'İptal işlemi sırasında bir hata oluştu.': 'An error occurred during cancellation.',
            'Eksik evrakın tamamlandığını onaylıyor musunuz? Ticket yeniden uyum onayına gönderilecektir.': 'Do you confirm that the missing document has been completed? The ticket will be sent back for compliance approval.',
            'Eksik evrak tamamlama işlemi sırasında bir hata oluştu.': 'An error occurred while completing the missing document process.',
            'Müşteri Toplantı Notları': 'Customer Meeting Notes',
            'Toplantı kayıtlarını oluşturun, inceleyin ve dışa aktarın.': 'Create, review, and export meeting records.',
            'Tür Seçenekleri': 'Type Options',
            'Müşteri, ekleyen veya not içeriğine göre filtreleyin.': 'Filter by customer, creator, or note content.',
            'Ara (Müşteri / Ekleyen / Not)': 'Search (Customer / Creator / Note)',
            'Yeni Toplantı Kaydı': 'New Meeting Record',
            'Toplantı bilgilerini ve konu/hedef tarihlerini tek formdan kaydedin.': 'Save meeting information and subject/target dates from a single form.',
            'Toplantı Başlığı *': 'Meeting Title *',
            'Konum *': 'Location *',
            'Tarih *': 'Date *',
            'Saat *': 'Time *',
            'Hazırlayan *': 'Prepared By *',
            'Katılımcılar *': 'Participants *',
            'Konular ve Hedef Tarihleri *': 'Topics and Target Dates *',
            'Yeni Konu Ekle': 'Add New Topic',
            'Toplantı Notu': 'Meeting Note',
            'Toplantı Tutanağı': 'Meeting Minutes',
            'İsim': 'Name',
            'Toplantı Başlığı:': 'Meeting Title:',
            'Konum:': 'Location:',
            'Saat:': 'Time:',
            'Hazırlayan:': 'Prepared By:',
            'Katılımcılar:': 'Participants:',
            'Excel Dosyası (.xlsx)': 'Excel File (.xlsx)',
            'Eşleşen müşteri bulunursa ilgili kayıt Detaylar sayfasına da eklenir.': 'If a matching customer is found, the related record is also added to the Details page.',
            'Yükle ve Kaydet': 'Upload and Save',
            'İçe Aktarılan Kayıtlar': 'Imported Records',
            'Bu sayfada yüklediğiniz Excel verilerini ayrı olarak görüntüleyebilirsiniz.': 'You can view the Excel data uploaded on this page separately.',
            'Yükleme': 'Upload',
            'Dosya': 'File',
            'Satır': 'Row',
            'Yükleyen': 'Uploader',
            'Eşleşti': 'Matched',
            'Eşleşmedi': 'Not Matched',
            'Detaya Git': 'Go to Details',
            'Henüz aktarılmış kayıt yok.': 'No imported records yet.',
            'Kullanıcı Adı': 'Username',
            'E-posta': 'Email Address',
            'Hata': 'Issue',
            'Atanan': 'Assigned',
            'Detay': 'Detail',
            'Excel\'e İndir': 'Download to Excel',
            'Excel\'e Aktar': 'Export to Excel',
            'Tanımlı izin hakkı': 'Leave allowance defined',
            'Onaylanmış kullanılan izin': 'Approved leave used',
            'Kalan izin': 'Remaining leave',
            'gün': 'day',
            'İzin Talebini Güncelle': 'Update Leave Request',
            'Yeni İzin Talebi': 'New Leave Request',
            'Kaydedilen her değişiklik admin onayına yeniden düşer.': 'Every saved change is sent back to admin approval.',
            'Başlangıç Tarihi': 'Start Date',
            'Bitiş Tarihi': 'End Date',
            'Açıklama / Mazeret': 'Description / Reason',
            'Güncelle ve Onaya Gönder': 'Update and Send for Approval',
            'Talep Oluştur': 'Create Request',
            'Kullanıcı İzin Hakları': 'User Leave Balances',
            'Sadece operasyon kullanıcıları listelenir.': 'Only operation users are listed.',
            'Kullanıcı': 'User',
            'Toplam Hak': 'Total Allowance',
            'Kullanılan': 'Used',
            'Kalan': 'Remaining',
            'Yeni Hak Tanımı': 'New Allowance Definition',
            'Operasyon kullanıcısı bulunamadı.': 'No operation user found.',
            'Kaydet': 'Save',
            'Tüm İzin Talepleri': 'All Leave Requests',
            'İzin Taleplerim': 'My Leave Requests',
            'Düzenlenen kayıtlar tekrar beklemeye alınır.': 'Edited records are moved back to pending.',
            'Talep Sahibi': 'Request Owner',
            'Gün': 'Day',
            'Admin Notu': 'Admin Note',
            'Talep Tarihi': 'Request Date',
            'Henüz izin talebi bulunmuyor.': 'No leave request exists yet.',
            'Düzenle': 'Edit',
            'Onay notu veya red mazereti...': 'Approval note or rejection reason...',
            'Reddet': 'Reject',
            'Operasyon izin taleplerini yönetin ve izin hakkı tanımlayın.': 'Manage operation leave requests and define leave balances.',
            'İzin talebinizi oluşturun, güncelleyin ve admin kararını takip edin.': 'Create or update your leave request and track the admin decision.',
            'Toplam Parametre': 'Total Parameter',
            'Tanımlı türler ve parametre değerleri': 'Defined types and parameter values',
            'Ad': 'Name',
            'Yukarı / aşağı butonları kolon sırasını belirler.': 'The up / down buttons define the column order.',
            'Henüz': 'Yet',
            'türünde parametre tanımlı değil.': 'No parameter is defined yet for the Status type.',
            'değerleri parametrelerden çekilir.': 'The values of',
            'Yeni Ticket Oluştur': 'New Ticket Create',
            'Müşteri, ödeme ve teknik bilgileri tek form üzerinden eksiksiz girin.': 'Enter customer, payment, and technical details completely through a single form.',
            'Süreç başlangıcı: Operasyon 1': 'Process starts: Operation 1',
            'Müşteri tipi zorunlu': 'Customer type is required',
            'Ticket Bilgileri': 'Ticket Information',
            'Zorunlu alanları doldurup kaydı oluşturun.': 'Fill in the required fields and create the record.',
            'Genel Bilgiler': 'General Information',
            'Firma Adı': 'Company Name',
            'Müşteri Ne Kullanacak?': 'What Will the Customer Use?',
            'Web Sitesi Kim Tarafından Yazıldı?': 'Who Developed the Website?',
            'Hangi Ödeme Yöntemleri Kullanılacak?': 'What Payment Methods Will Be Used?',
            'Yazılımcı Adı': 'Developer First Name',
            'Yazılımcı Soyadı': 'Developer Last Name',
            'Mail Adresi': 'Email Address',
            'İrtibat Numarası': 'Contact Number',
            'Süreç Özeti': 'Process Summary',
            'Kayıt sonrası ticket doğrudan Operasyon 1 onay adımına düşer. Gerekli alanları eksiksiz doldurmanız süreci hızlandırır.': 'After submission, the ticket directly moves to the Operation 1 approval step. Completing all required fields accelerates the process.',
            'Dikkat Edilecekler': 'Things to Watch',
            'Aynı firma, site veya mail için açık ticket varsa kayıt engellenir.': 'If there is already an open ticket for the same company, website, or email, the record is blocked.',
            'Firma, web sitesi ve iletişim bilgileri eksiksiz girilmelidir.': 'Company, website, and contact details must be entered completely.',
            'Ödeme ve web sitesi seçimleri doğru işaretlenmelidir.': 'Payment and website selections must be marked correctly.',
            'Aksiyonlar': 'Actions',
            'Aşağıdaki Gönder Butonuna Git': 'Go to the Submit Button Below',
            'Listeye Dön': 'Back to List',
            'Ticket Gönder': 'Send Ticket',
            'En az bir konu girmelisiniz.': 'At least one topic must be entered.',
            'Bu kolonda gösterilecek kayıt yok.': 'No records to display in this column.',
            'Bu kaydı silmek istiyor musunuz?': 'Do you want to delete this record?',
            'Toplantı kaydı oluşturuldu.': 'Meeting record created.',
            'Kayıt doğrulanamadı.': 'Record validation failed.',
            'Durum boş olamaz.': 'Empty status',
            'Görev bulunamadı.': 'Task not found',
            'Durum güncellendi.': 'Status updated',
            'Hata:': 'Error:',
            'Geçersiz kayıt.': 'Invalid model',
            'Kayıt bulunamadı.': 'Record not found',
            'Toplantı Tutanağı': 'Meeting Minutes',
            'Toplantı Başlığı': 'Meeting Title',
            'Konum': 'Location',
            'Konu': 'Topic',
            'Hedef Tarihi': 'Target Date',
            'Hazırlayan': 'Prepared By',
            'Aksiyon Sahibi': 'Action Owner',
            'Excel okunamadı:': 'Excel could not be read:',
            'Ticket oluşturuldu. Operasyon 1 onayı bekleniyor.': 'Ticket created. Operation 1 approval is pending.',
            'Geçersiz ticket ID.': 'Invalid ticket ID.',
            'Ticket bulunamadı.': 'Ticket not found.',
            'Bu ticket size atanmadığı için işlem yapamazsınız.': 'You cannot perform this action because this ticket is not assigned to you.',
            'Operasyon 1 kararı kaydedildi. Uyum onayı bekleniyor.': 'Operation 1 decision saved. Compliance approval is pending.',
            'Operasyon 2 kararı kaydedildi.': 'Operation 2 decision saved.',
            'Entegrasyon tamamlandı. Ticket tekrar Saha Canli Bekleniyor durumuna alındı.': 'Integration completed. Ticket was moved back to Field Go-Live Pending status.',
            'Canlı açılış kaydedildi. Müşteri kaydı oluşturuldu veya güncellendi.': 'Go-live recorded. Customer record was created or updated.',
            'Ticket reddedildi.': 'Ticket rejected.',
            'Eksik evrak tamamlandı. Ticket yeniden uyum onayına gönderildi.': 'Missing document completed. Ticket was sent back to compliance approval.',
            'Geçersiz istek.': 'Request is invalid.',
            'Değişiklik nedeni zorunlu.': 'Change reason is required.',
            'Değişiklik nedeni maksimum 500 karakter olmalıdır.': 'Change reason must be at most 500 characters.',
            'Seçilen kullanıcı operasyon rolünde değil veya bulunamadı.': 'The selected user is not in the operation role or could not be found.',
            'Seçilen durum geçerli değil.': 'The selected status is not valid.',
            'Kişi veya durum değişikliği yapmadınız.': 'No assignee or status change was made.',
            'Kişi ataması güncellendi.': 'Assignee assignment updated.',
            'Kişi ve durum güncellendi.': 'Assignee and status updated.'
        }
    };


    const fullPageTranslations = {
        "en": {
            "Hesabın yok mu? Kayıt ol": "Don't have an account? Register",
            "📝 Yeni Hesap Oluştur": "📝 Create New Account",
            "Kullanıcı başarıyla eklendi.": "User added successfully.",
            "Kullanıcı başarıyla silindi.": "User deleted successfully.",
            "Kullanıcı bulunamadı.": "User not found.",
            "Geçersiz giriş. Lütfen tüm alanları doğru doldurun.": "Invalid entry. Please fill in all fields correctly.",
            "Hoş geldin,": "Welcome,",
            "Hoşgeldiniz!": "Welcome!",
            "Hoşgeldiniz": "Welcome",
            "Kullanıcı": "User",
            "Firma": "Company",
            "İşlem": "Action",
            "İşlemler": "Actions",
            "Kaydet": "Save",
            "Ekle": "Add",
            "Düzenle": "Edit",
            "Geri": "Back",
            "İndir": "Download",
            "Yükleniyor...": "Loading...",
            "Kayıt bulunamadı.": "No record found.",
            "Kayıt bulunamadı": "No record found",
            "Kayıt id bulunamadı.": "Record ID was not found.",
            "Yok": "None",
            "Var": "Exists",
            "Bekleyen": "Pending",
            "Kaydedilen": "Recorded",
            "Reddedilen": "Rejected",
            "Firma adı": "Company name",
            "Adı": "First Name",
            "Soyadı": "Last Name",
            "İrtibat": "Contact",
            "Firma Adı": "Company Name",
            "Talep Eden": "Requester",
            "Talep Açan": "Requester",
            "Başlık": "Title",
            "Açıklama": "Description",
            "Durum Değişiklik Tarihi": "Status Change Date",
            "Durum Değ. Tarihi": "Status Chg. Date",
            "Site": "Site",
            "Gönderildi": "Sent",
            "Gönderilmedi": "Not Sent",
            "Döküman Gönderildi": "Document Sent",
            "Doküman Gönderildi": "Document Sent",
            "Doküman İletildi": "Document Sent",
            "Dokuman İletildi": "Document Sent",
            "Satışa Bilgi Verildi": "Sales Informed",
            "Canlıda": "Live",
            "Canlıda Entegrasyon Tamamlandı": "Live Integration Completed",
            "Entegrasyon Tamamlandı": "Integration Completed",
            "Tüm Aylar": "All Months",
            "Tüm Zamanlar": "All Time",
            "Tüm Durum": "All Statuses",
            "Tüm Durumlar": "All Statuses",
            "Tüm Türler": "All Types",
            "Tür": "Type",
            "Türü": "Type",
            "İsim": "Name",
            "Gün": "Days",
            "gün": "days",
            "Kalan": "Remaining",
            "Kullanılan": "Used",
            "Toplam Kayıt": "Total Records",
            "Toplam Tür": "Total Types",
            "Tür Seçenekleri": "Type Options",
            "Ara (Müşteri / Ekleyen / Not)": "Search (Customer / Added By / Note)",
            "Örn: ABC toplantı...": "Example: ABC meeting...",
            "Örnek: .NET": "Example: .NET",
            "Örnek: Öncelik": "Example: Priority",
            "Seçili Ay Müşteri Yeni Kayıt": "Selected Month New Customer Records",
            "Aktif Müşteri Sayısı": "Active Customer Count",
            "Toplam aktif müşteri": "Total active customers",
            "Döküman İletilen Sayısı": "Documents Sent Count",
            "Güncel durum": "Current status",
            "Aylık Yeni Kayıt": "Monthly New Records",
            "Son 6 ay yeni kayıt trendi": "New record trend over the last 6 months",
            "Yeni Kayıtlar": "New Records",
            "Veritabanı Yedeği": "Database Backup",
            "DB Yedeği": "DB Backup",
            "SQL Server yedeğini sadece Admin kullanıcılar alabilir ve indirebilir.": "Only Admin users can create and download the SQL Server backup.",
            "DB Yedeği Al": "Create DB Backup",
            "Veritabanı:": "Database:",
            "Bağlantı:": "Connection:",
            "SQL Server servis hesabı:": "SQL Server service account:",
            "Önemli:": "Important:",
            "BACKUP DATABASE komutunda dosyayı ASP.NET değil, SQL Server servis hesabı oluşturur. Bu yüzden Desktop/proje klasörü yerine aşağıdaki gibi SQL Server'ın yazabileceği sade bir klasör kullanılmalıdır.": "With the BACKUP DATABASE command, the file is created by the SQL Server service account, not ASP.NET. For this reason, use a simple folder that SQL Server can write to, like the one below, instead of the Desktop/project folder.",
            "Alınan Yedekler": "Created Backups",
            "Son alınan .bak dosyaları buradan indirilebilir veya silinebilir.": "Recently created .bak files can be downloaded or deleted here.",
            "Henüz alınmış veritabanı yedeği yok.": "No database backup has been created yet.",
            "Oluşturma Tarihi": "Creation Date",
            "Yeni veritabanı yedeği alınsın mı? İşlem veritabanı boyutuna göre biraz sürebilir.": "Create a new database backup? The process may take a while depending on the database size.",
            "Bu yedek dosyası silinsin mi?": "Delete this backup file?",
            "Yedek başarıyla alındı:": "Backup created successfully:",
            "Yedek alınamadı:": "Backup could not be created:",
            "Yedek dosyası bulunamadı.": "Backup file was not found.",
            "Dosya adı geçersiz.": "The file name is invalid.",
            "Sadece .bak dosyaları indirilebilir.": "Only .bak files can be downloaded.",
            "Sadece .bak dosyaları silinebilir.": "Only .bak files can be deleted.",
            "Bulunamadı": "Not found",
            "Erişim engellendi": "Access denied",
            "ConnectionString bulunamadı. appsettings.json içinde ConnectionStrings:DefaultConnection veya AppDbContext tanımlı olmalı.": "ConnectionString was not found. ConnectionStrings:DefaultConnection or AppDbContext must be defined in appsettings.json.",
            "Veritabanı adı okunamadı.": "Database name could not be read.",
            "Okunamadı. SQL Server Configuration Manager > SQL Server Services ekranından bak.": "Could not be read. Check it from SQL Server Configuration Manager > SQL Server Services.",
            "Yeni Görüşme Detayı": "New Conversation Detail",
            "Yeni Görüşme Detayı Ekle": "Add New Conversation Detail",
            "Görüşülen": "Contacted Person",
            "Seçiniz...": "Select...",
            "Arşivde Göster": "Show in Archive",
            "Detay Düzenle": "Edit Detail",
            "Detay Aç": "Open Details",
            "Detay kaydı eklendi.": "Detail record added.",
            "Detay kaydı bulunamadı.": "Detail record was not found.",
            "Detay kaydı güncellendi.": "Detail record updated.",
            "Detay kaydı silindi.": "Detail record deleted.",
            "Detay Kaydı": "Detail Record",
            "İş Takip Yorumu": "Work Tracking Comment",
            "Detay yüklenemedi.": "Details could not be loaded.",
            "Detay yükleme hatası:": "Detail loading error:",
            "Açıklama girilmedi.": "No description entered.",
            "Açıklama girilmedi": "No description entered",
            "Excel aktarım sayfalama": "Excel import pagination",
            "Excel Aktarımı": "Excel Import",
            "Excel okunamadı:": "Excel could not be read:",
            "kayıt içe aktarıldı.": "records imported.",
            "kayıt detaylara eklendi.": "records added to details.",
            "Yeni Hata Oluştur": "Create New Issue",
            "Yeni Hata Ekle": "Add New Issue",
            "Hata Adı *": "Issue Name *",
            "Müşteri *": "Customer *",
            "Atanan Kullanıcı *": "Assigned User *",
            "Atanan Kullanıcı:": "Assigned User:",
            "Yeni Atanan Kullanıcı": "New Assigned User",
            "Atanan Kişiyi Değiştir": "Change Assigned User",
            "Atamayı Güncelle": "Update Assignment",
            "Operasyon Yanıtı": "Operation Response",
            "Yeni operasyon yanıtı kaydedildi.": "New operation response saved.",
            "Henüz operasyon tarafından cevap verilmemiş.": "No response has been given by the operation team yet.",
            "Bu kayda sadece atanmış kullanıcı cevap verebilir.": "Only the assigned user can respond to this record.",
            "Gönder": "Send",
            "Saha Hataları": "Field Issues",
            "Saha Hataları (Operasyon)": "Field Issues (Operation)",
            "Saha Hataları - Operasyon": "Field Issues - Operation",
            "Henüz hata raporu yok.": "No issue report yet.",
            "Yazılım": "Software",
            "Donanım": "Hardware",
            "Ağ": "Network",
            "Veritabanı": "Database",
            "Kategori": "Category",
            "Lütfen bir müşteri seçiniz.": "Please select a customer.",
            "Lütfen atanacak kullanıcı seçiniz.": "Please select the user to assign.",
            "Seçilen kullanıcı bulunamadı.": "Selected user was not found.",
            "Lütfen geçerli bir müşteri seçiniz.": "Please select a valid customer.",
            "Başlık zorunludur.": "Title is required.",
            "Operasyon izin taleplerini yönetin ve izin hakkı tanımlayın.": "Manage operation leave requests and define leave entitlements.",
            "İzin talebinizi oluşturun, güncelleyin ve admin kararını takip edin.": "Create and update your leave request and track the admin decision.",
            "Tanımlı izin hakkı": "Defined leave entitlement",
            "Onaylanmış kullanılan izin": "Approved used leave",
            "İzin Talebini Güncelle": "Update Leave Request",
            "Yeni İzin Talebi": "New Leave Request",
            "Kaydedilen her değişiklik admin onayına yeniden düşer.": "Every saved change is sent back to admin approval.",
            "Başlangıç Tarihi": "Start Date",
            "Bitiş Tarihi": "End Date",
            "Açıklama / Mazeret": "Description / Reason",
            "İzin nedeni veya açıklamasını yazın...": "Write the leave reason or description...",
            "Güncelle ve Onaya Gönder": "Update and Send for Approval",
            "Talep Oluştur": "Create Request",
            "Kullanıcı İzin Hakları": "User Leave Entitlements",
            "Sadece operasyon kullanıcıları listelenir.": "Only operation users are listed.",
            "Yeni Hak Tanımı": "New Entitlement Definition",
            "Operasyon kullanıcısı bulunamadı.": "No operation user was found.",
            "Tüm İzin Talepleri": "All Leave Requests",
            "İzin Taleplerim": "My Leave Requests",
            "Düzenlenen kayıtlar tekrar beklemeye alınır.": "Edited records are moved back to pending status.",
            "Tarih Aralığı": "Date Range",
            "Henüz izin talebi bulunmuyor.": "There are no leave requests yet.",
            "Onaylandı": "Approved",
            "Reddedildi": "Rejected",
            "Başlangıç ve bitiş tarihi zorunludur.": "Start and end dates are required.",
            "Bitiş tarihi başlangıç tarihinden küçük olamaz.": "End date cannot be earlier than start date.",
            "Kullanıcı bilgisi bulunamadı.": "User information was not found.",
            "İzin talebi bulunamadı.": "Leave request was not found.",
            "İzin talebi güncellendi ve yeniden onaya gönderildi.": "Leave request was updated and sent for approval again.",
            "İzin talebi oluşturuldu.": "Leave request was created.",
            "Bu kullanıcı için önce izin hakkı tanımlanmalıdır.": "Leave entitlement must be defined for this user first.",
            "Yetersiz izin hakkı.": "Insufficient leave entitlement.",
            "Red işlemi için mazeret girilmelidir.": "A reason is required for rejection.",
            "Geçersiz karar tipi.": "Invalid decision type.",
            "İzin talebi onaylandı.": "Leave request approved.",
            "İzin talebi reddedildi.": "Leave request rejected.",
            "İzin hakkı negatif olamaz.": "Leave entitlement cannot be negative.",
            "Gün Sayısı": "Number of Days",
            "🧩 Jira Kanban Görünüm": "🧩 Jira Kanban View",
            "🧾 Jira Tarzı İş Takip Sistemi": "🧾 Jira-Style Work Tracking System",
            "✅ Tamamlandı": "✅ Completed",
            "Bu taskı silmek istediğinizden emin misiniz?": "Are you sure you want to delete this task?",
            "Oluşturma": "Created",
            "Oluşturma:": "Created:",
            "Talep Açan:": "Requester:",
            "Henüz yorum yok.": "No comments yet.",
            "Talep Türü": "Request Type",
            "Gelişme, not veya işlem bilgisini yaz...": "Write progress, note, or action information...",
            "Atama yapılmadı": "No assignment made",
            "Sonuç bulunamadı": "No results found",
            "İş Tipi": "Work Type",
            "Request Subject": "Request Subject",
            "Talep konusu": "Request subject",
            "Talep Konusu": "Request Subject",
            "Takip Eden": "Assigned To",
            "Atanan Kullanıcı": "Assigned User",
            "Kişi": "Person",
            "Sıfırla": "Reset",
            "Operasyon · İş Takip": "Operation · Work Tracking",
            "Dökümanı iletilen iş": "Work items with documents sent",
            "Satışa aktarılan iş": "Work items passed to sales",
            "Entegrasyonu tamamlanan iş": "Work items with integration completed",
            "Varsayılan durum: Aktif": "Default status: Active",
            "Kişi ve arama filtrelerini tek panelden yönetin": "Manage person and search filters from a single panel",
            "Kişi:": "Person:",
            "Saha kullanıcısı Talep Açan alanında kendi adı olan tüm işleri görür. İş kimdeyse kartta görünür.": "Field users see all work items where their own name is in the Requester field. The assignee is shown on the card.",
            "Bu ekranda sadece aktif takip kolonları gösterilir. Diğer durumlar Excel ve arşiv tarafında eksiksiz kalır.": "Only active tracking columns are shown on this screen. Other statuses remain complete in Excel and archive screens.",
            "Sol taraftaki işler yerinden oynamaz; detay sağda sabit panel olarak açılır.": "Work items on the left do not move; details open in a fixed panel on the right.",
            "Durumu değiştirince işin ana durumu da aynı duruma çekilir.": "When the status is changed, the main work status is also moved to the same status.",
            "Talep konusunu detaylı yazın...": "Write the request subject in detail...",
            "Dökümanı iletilen işler": "Work items with documents sent",
            "Satış ekibine bilgi verilen işler": "Work items informed to sales team",
            "Canlı ortama alınan işler": "Work items moved to live environment",
            "Entegrasyonu tamamlanan işler": "Work items with integration completed",
            "Talep açtığım işler": "Requests I opened",
            "Bu kaydı silmek istiyor musunuz?": "Do you want to delete this record?",
            "Görev eklendi.": "Task added.",
            "Durum güncellendi.": "Status updated.",
            "Takip eden güncellendi.": "Assigned user updated.",
            "Yorum eklendi.": "Comment added.",
            "Kayıt silindi.": "Record deleted.",
            "Yorum boş olamaz.": "Comment cannot be empty.",
            "Geçersiz durum güncellemesi.": "Invalid status update.",
            "Geçersiz iş tipi seçildi.": "Invalid work type selected.",
            "Geçersiz kayıt.": "Invalid record.",
            "Görev bulunamadı.": "Task not found.",
            "Jira ID ve Talep Konusu zorunludur.": "Jira ID and Request Subject are required.",
            "Seçilen müşteri bulunamadı.": "Selected customer could not be found.",
            "Talep Konusu zorunludur.": "Request Subject is required.",
            "Geçersiz durum seçildi. İş Takip ekranında sadece ana takip durumları kullanılabilir.": "Invalid status selected. Only main tracking statuses can be used on the Work Tracking screen.",
            "Bu durum İş Takip ekranında kullanılamaz. Diğer durumlar sadece Excel tarafında tutulur.": "This status cannot be used on the Work Tracking screen. Other statuses are kept only on the Excel side.",
            "İş Takip durum güncellemesi": "Work Tracking status update",
            "Canlıda Entegrasyon Tamamlandı seçildi. Kayıt otomatik arşive alındı.": "Live Integration Completed was selected. The record was automatically archived.",
            "Durum güncellendi. Detay/Müşteri durumu da güncellendi.": "Status updated. Detail/Customer status was also updated.",
            "Detay durumu boş olamaz.": "Detail status cannot be empty.",
            "Bu durum İş Takip ekranında kullanılamaz.": "This status cannot be used on the Work Tracking screen.",
            "Takip detay ekranından durum güncellendi.": "Status updated from the tracking detail screen.",
            "Detay durumu güncellendi.": "Detail status updated.",
            "Geçersiz model": "Invalid model",
            "İş Takip sürükle-bırak durum güncellemesi": "Work Tracking drag-and-drop status update",
            "Durum ve detay durumu güncellendi.": "Status and detail status updated.",
            "Yeni Müşteri": "New Customer",
            "+ Yeni Müşteri": "+ New Customer",
            "Yeni Müşteri Ekle": "Add New Customer",
            "✏️ Müşteri Düzenle": "✏️ Edit Customer",
            "Müşteri bilgileri alınamadı.": "Customer information could not be retrieved.",
            "Müşteri bilgileri yüklenemedi. Lütfen tekrar deneyin.": "Customer information could not be loaded. Please try again.",
            "Bu müşteriyi ve tüm detaylarını silmek istediğinizden emin misiniz?": "Are you sure you want to delete this customer and all of its details?",
            "Beklenmeyen sunucu yanıtı alındı.": "Unexpected server response received.",
            "Silme işlemi başarısız oldu.": "Delete operation failed.",
            "Silme işlemi sırasında bir hata oluştu.": "An error occurred during delete operation.",
            "Firma adı zorunludur.": "Company name is required.",
            "Geçerli bir durum seçiniz.": "Please select a valid status.",
            "Müşteri bulunamadı.": "Customer not found.",
            "Döküman durumu güncellendi.": "Document status updated.",
            "Müşteri başarıyla eklendi!": "Customer added successfully!",
            "Müşteri başarıyla güncellendi!": "Customer updated successfully!",
            "Müşteri başarıyla silindi!": "Customer deleted successfully!",
            "Kayıt sırasında hata:": "Error during save:",
            "Güncelleme sırasında hata:": "Error during update:",
            "Silme sırasında hata:": "Error during delete:",
            "Telefon numarası 20 karakterden uzun olamaz.": "Phone number cannot be longer than 20 characters.",
            "Parametre Yönetimi": "Parameter Management",
            "Sistem içindeki tür ve parametre değerlerini merkezi olarak yönetin.": "Manage system types and parameter values centrally.",
            "Yeni Parametre Değeri": "New Parameter Value",
            "Mevcut bir türe yeni parametre değeri ekleyin.": "Add a new parameter value to an existing type.",
            "Parametre Adı": "Parameter Name",
            "Yeni Tür": "New Type",
            "Parametre grupları için yeni tür tanımlayın.": "Define a new type for parameter groups.",
            "Yeni Tür Ekle": "Add New Type",
            "Tür Ekle": "Add Type",
            "Durum Yönetimi": "Status Management",
            "İş Takip ekranındaki kolon sırasını ve durum görünümünü buradan yönetin.": "Manage the Work Tracking column order and status visibility from here.",
            "Yukarı / aşağı butonları kolon sırasını belirler.": "Up/down buttons define the column order.",
            "İş Takip kolonu olarak görünür": "Visible as a Work Tracking column",
            "Yukarı": "Up",
            "Aşağı": "Down",
            "Yukarı taşı": "Move up",
            "Aşağı taşı": "Move down",
            "Henüz": "No",
            "türünde parametre tanımlı değil.": "type parameter has been defined yet.",
            "Tanımlı türler ve parametre değerleri": "Defined types and parameter values",
            "değerleri parametrelerden çekilir.": "values are loaded from parameters.",
            "Arşiv": "Archive",
            "Arşiv - Diğer İşler": "Archive - Other Work Items",
            "Durum filtresi Parametreler > Durum listesindeki tüm değerleri çeker; Excel çıktısı tüm ayları ve tüm durumları indirir.": "The status filter loads every value from Parameters > Status; the Excel export downloads all months and all statuses.",
            "Excel İndir (Tüm Aylar)": "Download Excel (All Months)",
            "Oluşturma / Arşiv Tarihi": "Created / Archive Date",
            "İş Detayı": "Work Detail",
            "Müşteri, Jira No, konu, durum...": "Customer, Jira No, subject, status...",
            "Detay tıklandı. ID:": "Detail clicked. ID:",
            "Modal bulunamadı: arsivDetailModal": "Modal not found: arsivDetailModal",
            "Modal body bulunamadı: arsivDetailBody": "Modal body not found: arsivDetailBody",
            "İstek atılan URL:": "Requested URL:",
            "Bootstrap JS yüklenmemiş. _Layout.cshtml içinde bootstrap.bundle.min.js eksik.": "Bootstrap JS is not loaded. bootstrap.bundle.min.js is missing in _Layout.cshtml.",
            "Arşivlendi": "Archived",
            "İş takip kaydı bulunamadı.": "Work tracking record was not found.",
            "Müşteri bilgisi bulunamadı.": "Customer information was not found.",
            "Tamamlanma/Arşiv Tarihi": "Completion/Archive Date",
            "Geliştirme ve Eğitim İşleri": "Development and Training Work Items",
            "Geliştirme": "Development",
            "Eğitim": "Training",
            "Yeni Ticket Oluştur": "Create New Ticket",
            "Yeni Ticket": "New Ticket",
            "Müşteri, ödeme ve teknik bilgileri tek form üzerinden eksiksiz girin.": "Enter customer, payment, and technical information completely through a single form.",
            "Süreç başlangıcı: Operasyon 1": "Process starts: Operation 1",
            "Müşteri tipi zorunlu": "Customer type is required",
            "Ticket Bilgileri": "Ticket Information",
            "Zorunlu alanları doldurup kaydı oluşturun.": "Fill in the required fields and create the record.",
            "Genel Bilgiler": "General Information",
            "Müşteri Ne Kullanacak?": "What Will the Customer Use?",
            "Linkli Ödeme": "Payment Link",
            "Web Sitesi Kim Tarafından Yazıldı?": "Who Built the Website?",
            "Kendi Yazdı": "Built In-House",
            "Hizmet Aldığı Firma": "Service Provider Company",
            "Hangi Ödeme Yöntemleri Kullanılacak?": "Which Payment Methods Will Be Used?",
            "Normal Çekim": "Standard Charge",
            "Previzyonlu Çekim": "Pre-Authorization Charge",
            "Müşteri Web Sitesi": "Customer Website",
            "Müşteri Yetkilisi": "Customer Representative",
            "Teknik Bilgiler": "Technical Information",
            "Ödeme Bilgileri": "Payment Information",
            "Mevcut liste ve süreç adımları tek ekranda izlenir.": "The current list and process steps are tracked on a single screen.",
            "Durum ara...": "Search status...",
            "Talep eden ara...": "Search requester...",
            "Oluşturan seçiniz": "Select creator",
            "Operasyon, oluşturan veya durum seçmelisiniz.": "You must select operation, creator, or status.",
            "Bu firma adı ile açık bir ticket zaten var.": "An open ticket already exists with this company name.",
            "Bu web sitesi ile açık bir ticket zaten var.": "An open ticket already exists with this website.",
            "Bu mail adresi ile açık bir ticket zaten var.": "An open ticket already exists with this email address.",
            "Müşteri tipi 'Kurumsal' veya 'Bireysel' olmalıdır.": "Customer type must be 'Corporate' or 'Individual'.",
            "Kurumsal": "Corporate",
            "Bireysel": "Individual",
            "Ticket bu aşamada Operasyon 1 kararına uygun değil.": "The ticket is not eligible for an Operation 1 decision at this stage.",
            "Ticket bu aşamada Operasyon 2 kararına uygun değil.": "The ticket is not eligible for an Operation 2 decision at this stage.",
            "Ticket bu aşamada entegrasyon tamamlama işlemine uygun değil.": "The ticket is not eligible for integration completion at this stage.",
            "Canlı ortam ID girmek zorunludur.": "Live environment ID is required.",
            "Sadece ticket'ı açan saha kullanıcısı bu işlemi yapabilir.": "Only the field user who created the ticket can perform this action.",
            "Ticket bu aşamada canlı açılışa uygun değil.": "The ticket is not eligible for go-live at this stage.",
            "Açıklama zorunlu.": "Description is required.",
            "Ticket bu aşamada eksik evrak tamamlama işlemine uygun değil.": "The ticket is not eligible for missing-document completion at this stage.",
            "Geçersiz Ticket ID.": "Invalid Ticket ID.",
            "Seçilen oluşturan kullanıcı Saha/KurumsalSaha rolünde değil veya bulunamadı.": "The selected creator is not in the Field/Corporate Field role or could not be found.",
            "Kişi, durum veya oluşturan değişikliği yapmadınız.": "No person, status, or creator change was made.",
            "Operasyon ataması güncellendi.": "Operation assignment updated.",
            "Güncelleme tamamlandı.": "Update completed.",
            "Uyum": "Compliance",
            "Uyum Açıklama": "Compliance Description",
            "Uyum Onayı Bekleniyor": "Compliance Approval Pending",
            "Açıklama (opsiyonel)": "Description (optional)",
            "Ticket bu aşamada uyum kararına uygun değil.": "The ticket is not eligible for a compliance decision at this stage.",
            "Eksik evrak seçildiğinde açıklama girmek zorunludur.": "A description is required when missing documents is selected.",
            "Geçersiz karar. (Onay/EksikEvrak/Red)": "Invalid decision. (Approve/MissingDocuments/Reject)",
            "Uyum onayladı. Ticket Operasyon 2 onayına gönderildi.": "Compliance approved. Ticket was sent to Operation 2 approval.",
            "Ticket eksik evrak nedeniyle sahaya geri gönderildi.": "Ticket was sent back to field due to missing documents.",
            "Ticket uyum tarafından reddedildi.": "Ticket was rejected by compliance.",
            "Eksik Evrak Bekleniyor": "Missing Documents Pending",
            "Musteri Kaydedildi": "Customer Recorded",
            "Müşteri Kaydedildi": "Customer Recorded",
            "Saha Canli Bekleniyor": "Field Go-Live Pending",
            "Saha Canlı Bekleniyor": "Field Go-Live Pending",
            "Operasyon 1 Onay Bekleniyor": "Operation 1 Approval Pending",
            "Operasyon 2 Onay Bekleniyor": "Operation 2 Approval Pending",
            "Müşteri Toplantı Notları": "Customer Meeting Notes",
            "Toplantı kayıtlarını oluşturun, inceleyin ve dışa aktarın.": "Create, review, and export meeting records.",
            "Yeni Toplantı Kaydı": "New Meeting Record",
            "Toplantı bilgilerini ve konu/hedef tarihlerini tek formdan kaydedin.": "Save meeting information and subject/target dates from a single form.",
            "Toplantı Başlığı *": "Meeting Title *",
            "Hazırlayan *": "Prepared By *",
            "Katılımcılar *": "Participants *",
            "Toplantı Notu": "Meeting Note",
            "Toplantı Tutanağı": "Meeting Minutes",
            "Toplantı Başlığı:": "Meeting Title:",
            "Hazırlayan:": "Prepared By:",
            "Katılımcılar:": "Participants:",
            "Hazırlayan": "Prepared By",
            "Katılımcılar": "Participants",
            "Toplantı Başlığı": "Meeting Title",
            "Toplantı Türü": "Meeting Type",
            "Aksiyon Sahibi": "Action Owner",
            "Hedef Tarihi": "Target Date",
            "Katılımcı": "Participant",
            "Notlar": "Notes",
            "Onaylayan": "Approved By",
            "Onay Tarihi": "Approval Date",
            "Oluşturan": "Created By",
            "Kayıt Ekleyen": "Record Creator",
            "ASP.NET Core ile web uygulamaları geliştirme": "ASP.NET Core web app development",
            "hakkında bilgi edinin.": "learn more.",
            "ortamına geçmek, oluşan hata hakkında daha ayrıntılı bilgi gösterir.": "environment displays more detailed information about the error that occurred.",
            "Development ortamı yayındaki uygulamalarda etkinleştirilmemelidir.": "The Development environment should not be enabled in deployed applications.",
            "Bu durum istisnalardaki hassas bilgilerin son kullanıcılara gösterilmesine neden olabilir. Yerel hata ayıklama için": "This may display sensitive information from exceptions to end users. For local debugging,",
            "ortam değişkenini": "environment variable",
            "yapıp uygulamayı yeniden başlatın.": "and restart the application.",
            "Operasyon Takip ana sayfasına git": "Go to the Operations Tracking home page",
            "Gezinmeyi aç/kapat": "Toggle navigation",
            "Profil menüsünü aç": "Open profile menu",
            "Ana gezinme": "Main navigation",
            "Ana içeriğe geç": "Skip to main content",
            "Firma Ara:": "Search Company:",
            "Arama:": "Search:",
            "Göster": "Show",
            "Kayıt": "Record",
            "Kayıtlar": "Records",
            "kayıt": "records",
            "0 kayıt": "0 records",
            "Kayıt yok": "No records",
            "Tabloda herhangi bir veri mevcut değil": "No data available in table",
            "Herhangi bir kayıt bulunamadı": "No matching records found",
            "Son": "Last",
            "İlk": "First",
            "Yükleniyor": "Loading",
            "İşleniyor...": "Processing...",
            "Sonuç yok": "No results"
        }
    };

    Object.entries(fullPageTranslations.en).forEach(([source, target]) => {
        exactTranslations.en[source] = target;
        if (!Object.prototype.hasOwnProperty.call(exactTranslations.tr, target)) {
            exactTranslations.tr[target] = source;
        }
    });


    const finalPageTranslations = {
        "en": {
            "Kullanıcı adı veya şifre hatalı!": "Username or password is incorrect!",
            "Bu kullanıcı adı zaten mevcut.": "This username already exists.",
            "Bu e-mail adı zaten mevcut.": "This email already exists.",
            "OK. Kullanıcı": "OK. User",
            "Dokuman Gönderildi": "Document Sent",
            "Satışa Gönderildi": "Sent to Sales",
            "Okunamadı": "Could not be read",
            "Veritabanı yedeği oluşturuldu": "Database backup created",
            "SQL Server backup klasör izni hatası.": "SQL Server backup folder permission error.",
            "Yedek alınamadı: SQL Server bu klasöre yazamıyor.": "Backup failed: SQL Server cannot write to this folder.",
            "Çözüm: Bu klasöre SQL Server servis hesabına Modify/Yazma izni ver.": "Solution: Grant Modify/Write permission to the SQL Server service account on this folder.",
            "Veritabanı yedeği oluşturulurken hata oluştu.": "An error occurred while creating the database backup.",
            "Veritabanı yedeği silinirken hata oluştu.": "An error occurred while deleting the database backup.",
            "Geçersiz ay formatı. Örn: 2026-02": "Invalid month format. Example: 2026-02",
            "Müşteri ID": "Customer ID",
            "Operasyon Kullanıcı": "Operation User",
            "Kimden Geldi / Talep Açan": "Source / Requester",
            "iş takip yorumu": "work tracking comment",
            "Başlangıç tarihi zorunludur.": "Start date is required.",
            "Bitiş tarihi zorunludur.": "End date is required.",
            "Kurumsal ticket ataması için 'test' kullanıcısı bulunamadı. Kullanıcı Operasyon rolünde olmalı ve UserName değeri 'test' olmalıdır.": "The 'test' user required for corporate ticket assignment was not found. The user must be in the Operation role and the UserName value must be 'test'.",
            "✅ Uyum onayladı. Ticket Operasyon 2 onayına gönderildi.": "✅ Compliance approved. Ticket was sent to Operation 2 approval.",
            "⚠️ Ticket eksik evrak nedeniyle sahaya geri gönderildi.": "⚠️ Ticket was sent back to field due to missing documents.",
            "❌ Ticket uyum tarafından reddedildi.": "❌ Ticket was rejected by compliance.",
            "örn: musteri.com": "e.g. customer.com",
            "↑ Yukarı": "↑ Up",
            "↓ Aşağı": "↓ Down",
            "💾 Ekle": "💾 Add",
            "💾 Kaydet": "💾 Save",
            "Sayfada": "Show",
            "kayıt göster": "records per page",
            "Ara:": "Search:",
            "Eşleşen kayıt bulunamadı": "No matching records found",
            "kayıt içerisinden bulunan": "found from records",
            "artan sütun sıralamasını aktifleştir": "activate ascending column sorting",
            "azalan sütun sıralamasını aktifleştir": "activate descending column sorting",
            "İşleniyor...": "Processing...",
            "Yükleniyor...": "Loading...",
            "İlk": "First",
            "Son": "Last",
            "Önceki": "Previous",
            "Sonraki": "Next",
            "Operasyon, oluşturan veya durum seçmelisiniz.": "You must select operation, creator, or status.",
            "CanlıOrtamId": "LiveEnvironmentId",
            "Klasör": "Folder",
            "Çözüm": "Solution",
            "Şifre": "Password",
            "OK. Kullanıcı:": "OK. User:"
        }
    };

    Object.entries(finalPageTranslations.en).forEach(([source, target]) => {
        exactTranslations.en[source] = target;
        if (!Object.prototype.hasOwnProperty.call(exactTranslations.tr, target)) {
            exactTranslations.tr[target] = source;
        }
    });


    const supplementalFullEnglishTranslations = {
        "Admin Menü": "Admin Menu",
        "Yönetim": "Management",
        "Sistem": "System",
        "Entegrasyonun neden tamamlanmadığını yazın...": "Write why the integration was not completed...",
        "Entegrasyon Tamamlanmadı seçildiğinde açıklama zorunludur. Bu açıklama Excelde Yorumlar alanında görünür.": "Explanation is required when Integration Not Completed is selected. This explanation appears in the Comments field in Excel.",
        "Entegrasyon Tamamlanmadı seçildiğinde açıklama girmek zorunludur.": "Explanation is required when Integration Not Completed is selected.",
        "Entegrasyon Tamamlanmadı Açıklaması:": "Integration Not Completed Explanation:",
        "Bu ekranda ana takip kolonları yan yana gösterilir. Uyum Onayında olan kayıtlar Beklemede kolonunda listelenir. Entegrasyon Tamamlanmadı seçilen kayıtlar açıklamasıyla birlikte arşive alınır ve Excelde Durum filtresinde kendi durumuyla görünür.": "The main tracking columns are shown side by side on this screen. Records in Compliance Approval are listed in the Pending column. Records marked Integration Not Completed are archived with their explanation and appear under their own status in the Excel Status filter.",
        "Boyut": "Size",
        "Entegrasyon Tamamlanmadı": "Integration Not Completed",
        "Entegrasyonu tamamlanmayan iş": "Work items with incomplete integration",
        "Entegrasyonu tamamlanmayan işler": "Work items with incomplete integration",
        "Neden": "Reason",
        "Not": "Note",
        "Aktivite Ekle": "Add Activity",
        "Ara...": "Search...",
        "Detay Durumu": "Detail Status",
        "Detaylar sayfalama": "Details pagination",
        "Kaynak: Detaylar": "Source: Details",
        "Onay": "Approve",
        "Saha": "Field",
        "Takip": "Tracking",
        "Tarih / Saat": "Date / Time",
        "Uyum Tarihi": "Compliance Date",
        "Yeni Hata": "New Issue",
        "Yorum": "Comment",
        "Yorum Ekle": "Add Comment",
        "Yorumlar": "Comments",
        "➕ Ekle": "➕ Add",
        "➕ Yeni Hata": "➕ New Issue",
        "Hoşgeldiniz": "Welcome",
        "Hoşgeldiniz!": "Welcome!",
        "Hoşgeldiniz.": "Welcome.",
        "Tüm İzin Talepleri": "All Leave Requests",
        "İzin Taleplerim": "My Leave Requests",
        "Sıfırla": "Reset",
        "Kişi:": "Person:",
        "Dökümanı iletilen iş": "Work items with documents sent",
        "Dökümanı iletilen işler": "Work items with documents sent",
        "Satışa aktarılan iş": "Work items sent to sales",
        "Satışa aktarılan işler": "Work items sent to sales",
        "Satış ekibine bilgi verilen işler": "Work items shared with the sales team",
        "Entegrasyonu tamamlanan iş": "Work items with completed integration",
        "Entegrasyonu tamamlanan işler": "Work items with completed integration",
        "Varsayılan durum: Aktif": "Default status: Active",
        "Kişi ve arama filtrelerini tek panelden yönetin": "Manage person and search filters from a single panel",
        "Bu kolonda gösterilecek kayıt yok.": "No records to display in this column.",
        "Durum Değ. Tarihi": "Status Change Date",
        "İşlem": "Action",
        "İndir": "Download",
        "Oluşturma Tarihi": "Created Date",
        "DB Yedeği Al": "Create DB Backup",
        "Alınan Yedekler": "Created Backups",
        "Henüz alınmış veritabanı yedeği yok.": "No database backup has been created yet.",
        "Son alınan .bak dosyaları buradan indirilebilir veya silinebilir.": "The latest .bak files can be downloaded or deleted here.",
        "SQL Server yedeğini sadece Admin kullanıcılar alabilir ve indirebilir.": "Only Admin users can create and download SQL Server backups.",
        "BACKUP DATABASE komutunda dosyayı ASP.NET değil, SQL Server servis hesabı oluşturur. Bu yüzden Desktop/proje klasörü yerine aşağıdaki gibi SQL Server'ın yazabileceği sade bir klasör kullanılmalıdır.": "The SQL Server service account, not ASP.NET, creates the file during the BACKUP DATABASE command. Therefore, use a simple folder SQL Server can write to instead of Desktop or the project folder.",
        "Hata.": "Error.",
        "Arşivde Göster": "Show in Archive",
        "Detay Düzenle": "Edit Detail",
        "Yeni Görüşme Detayı": "New Conversation Detail",
        "Yeni Görüşme Detayı Ekle": "Add New Conversation Detail",
        "Görüşülen": "Contacted Person",
        "Seçiniz...": "Select...",
        "Yeni Hata Oluştur": "Create New Issue",
        "Saha - Yeni Hata": "Field - New Issue",
        "Atanan Kullanıcı *": "Assigned User *",
        "Müşteri *": "Customer *",
        "Hata Adı *": "Issue Name *",
        "Kategori *": "Category *",
        "Kayıt bulunamadı.": "Record not found.",
        "Sonuç bulunamadı": "No results found",
        "Atama yapılmadı": "Not assigned",
        "Gelişme, not veya işlem bilgisini yaz...": "Write progress, note, or operation information...",
        "Talep Türü": "Request Type",
        "Açıklama (opsiyonel)": "Description (optional)",
        "Eksik Evrak": "Missing Documents",
        "Eksik Evrak Bekleniyor": "Missing Documents Pending",
        "Uyum Onayı Bekleniyor": "Compliance Approval Pending",
        "Operasyon 2 Onay Bekleniyor": "Operation 2 Approval Pending",
        "Saha Canli Bekleniyor": "Field Go-Live Pending",
        "Saha Canlı Bekleniyor": "Field Go-Live Pending",
        "Musteri Kaydedildi": "Customer Recorded",
        "Müşteri Kaydedildi": "Customer Recorded",
        "Canlıda": "Live",
        "Canlıda Entegrasyon Tamamlandı": "Live Integration Completed",
        "Döküman Gönderildi": "Document Sent",
        "Doküman Gönderildi": "Document Sent",
        "Dokuman Gönderildi": "Document Sent",
        "Gönderildi": "Sent",
        "Gönderilmedi": "Not Sent",
        "Onaylandı.": "Approved.",
        "Onaylandı": "Approved",
        "Onaylanan": "Approved",
        "Bekleyen": "Pending",
        "Reddedilen": "Rejected",
        "Kullanılan": "Used",
        "Karar": "Decision",
        "Admin Açıklaması": "Admin Description",
        "Karar Tarihi": "Decision Date",
        "İzin Hakkı Güncelle": "Update Leave Entitlement",
        "İzin hakkını güncelle": "Update leave entitlement",
        "Kalan gün": "Remaining days",
        "Gün Sayısı": "Number of Days",
        "Gün": "Day",
        "gün": "day",
        "Yükleniyor...": "Loading...",
        "İş Takip'e Dön": "Back to Work Tracking",
        "Arşiv - Diğer İşler": "Archive - Other Work Items",
        "Arşiv Detayı": "Archive Detail",
        "Kaynak": "Source",
        "Talep Açan": "Requester",
        "Tamamlanma/Arşiv Tarihi": "Completion/Archive Date",
        "İş Takip Yorumu": "Work Tracking Comment",
        "Detay Kaydı": "Detail Record",
        "Tüm Zamanlar": "All Time",
        "Hata Çözüm": "Issue Resolution",
        "KurumsalSaha": "Corporate Field",
        "Kurumsal Saha": "Corporate Field",
        "Operasyon": "Operation",
        "Admin": "Admin",
        "Uyum": "Compliance",
        "Bireysel": "Individual",
        "Kurumsal": "Corporate",
        "Sanal Pos": "Virtual POS",
        "Sanal POS": "Virtual POS",
        "Fiziksel Pos": "Physical POS",
        "Fiziksel POS": "Physical POS",
        "Kredi Kartı": "Credit Card",
        "Banka Kartı": "Debit Card",
        "Havale/EFT": "Bank Transfer/EFT",
        "Para Transferi": "Money Transfer",
        "Altyapı": "Infrastructure",
        "Web sitesi": "Website",
        "Web Sitesi": "Website",
        "Mobil Uygulama": "Mobile App",
        "E-Ticaret": "E-Commerce",
        "En az bir konu girmelisiniz.": "You must enter at least one topic.",
        "Bu kayıt silinsin mi?": "Delete this record?",
        "Bu kaydı silmek istiyor musunuz?": "Do you want to delete this record?",
        "Bu taskı silmek istediğinizden emin misiniz?": "Are you sure you want to delete this task?",
        "Silinsin mi?": "Delete it?",
        "Bu müşteriyi ve tüm detaylarını silmek istediğinizden emin misiniz?": "Are you sure you want to delete this customer and all details?",
        "Müşteri bilgileri alınamadı.": "Customer information could not be retrieved.",
        "Müşteri bilgileri yüklenemedi. Lütfen tekrar deneyin.": "Customer information could not be loaded. Please try again.",
        "Beklenmeyen sunucu yanıtı alındı.": "An unexpected server response was received.",
        "Silme işlemi başarısız oldu.": "Delete operation failed.",
        "Silme işlemi sırasında bir hata oluştu.": "An error occurred during delete operation.",
        "Lütfen bir ay seçin veya Tüm Aylar butonunu kullanın.": "Please select a month or use the All Months button.",
        "Yeni veritabanı yedeği alınsın mı? İşlem veritabanı boyutuna göre biraz sürebilir.": "Create a new database backup? The operation may take some time depending on the database size.",
        "Bu yedek dosyası silinsin mi?": "Delete this backup file?",
        "Kayıt id bulunamadı.": "Record ID could not be found.",
        "Modal bulunamadı: arsivDetailModal": "Modal not found: arsivDetailModal",
        "Modal body bulunamadı: arsivDetailBody": "Modal body not found: arsivDetailBody",
        "Bootstrap JS yüklenmemiş. _Layout.cshtml içinde bootstrap.bundle.min.js eksik.": "Bootstrap JS is not loaded. bootstrap.bundle.min.js is missing in _Layout.cshtml.",
        "Detay yüklenirken hata oluştu.": "An error occurred while loading details.",
        "Ticket oluşturuldu.": "Ticket created.",
        "Bu firma adı ile açık bir ticket zaten var.": "There is already an open ticket with this company name.",
        "Bu web sitesi ile açık bir ticket zaten var.": "There is already an open ticket with this website.",
        "Bu mail adresi ile açık bir ticket zaten var.": "There is already an open ticket with this email address.",
        "Müşteri tipi 'Kurumsal' veya 'Bireysel' olmalıdır.": "Customer type must be 'Corporate' or 'Individual'.",
        "Eksik evrak seçildiğinde açıklama girmek zorunludur.": "Description is required when missing documents are selected.",
        "Geçersiz karar. (Onay/EksikEvrak/Red)": "Invalid decision. (Approve/MissingDocuments/Reject)",
        "Operasyon kullanıcısı bulunamadı.": "Operation user not found.",
        "Kayıt doğrulanamadı.": "Record could not be validated.",
        "Toplantı kaydı oluşturuldu.": "Meeting record created.",
        "Kayıt bulunamadı": "Record not found",
        "Kullanıcı başarıyla silindi.": "User deleted successfully.",
        "Kullanıcı bulunamadı.": "User not found.",
        "Telefon numarası 20 karakterden uzun olamaz.": "Phone number cannot be longer than 20 characters.",
        "Geçersiz durum seçildi. İş Takip ekranında sadece ana takip durumları kullanılabilir.": "Invalid status selected. Only main tracking statuses can be used on the Work Tracking page.",
        "Geçersiz iş tipi seçildi.": "Invalid work type selected.",
        "Seçilen müşteri bulunamadı.": "Selected customer not found.",
        "Görev eklendi.": "Task added.",
        "Yorum boş olamaz.": "Comment cannot be empty.",
        "Görev bulunamadı.": "Task not found.",
        "Geçersiz kayıt.": "Invalid record.",
        "Takip eden güncellendi.": "Assignee updated.",
        "Geçersiz durum güncellemesi.": "Invalid status update.",
        "Bu durum İş Takip ekranında kullanılamaz. Diğer durumlar sadece Excel tarafında tutulur.": "This status cannot be used on the Work Tracking page. Other statuses are kept only on the Excel side.",
        "İş Takip durum güncellemesi": "Work Tracking status update",
        "Canlıda Entegrasyon Tamamlandı seçildi. Kayıt otomatik arşive alındı.": "Live Integration Completed was selected. The record was automatically archived.",
        "Durum güncellendi. Detay/Müşteri durumu da güncellendi.": "Status updated. Detail/Customer status was also updated.",
        "Detay durumu boş olamaz.": "Detail status cannot be empty.",
        "Bu durum İş Takip ekranında kullanılamaz.": "This status cannot be used on the Work Tracking page."
        , "Sayfalama": "Pagination"
        , "Excel aktarım sayfalama": "Excel import pagination"
        , "Operasyon Takip ana sayfasına git": "Go to Operations Tracking home page"
        , "Gezinmeyi aç/kapat": "Toggle navigation"
        , "Profil menüsünü aç": "Open profile menu"
        , "İzin nedeni veya açıklamasını yazın...": "Write the leave reason or description..."
        , "Örnek: Öncelik": "Example: Priority"
        , "Yukarı taşı": "Move up"
        , "Aşağı taşı": "Move down"
        , "Örn: ABC toplantı...": "Example: ABC meeting..."
        , "Firma adı": "Company name"
        , "Adı": "First name"
        , "Soyadı": "Last name"
        , "Müşteri, Jira No, konu, durum...": "Customer, Jira No, subject, status..."
        , "Talep konusunu detaylı yazın...": "Write the request subject in detail..."
        , "Hata adı, açıklama veya müşteri ara...": "Search issue name, description, or customer..."
        , "Talep Açan": "Requester"
        , "Excel'e Aktar": "Export to Excel"
        , "Excel'e İndir": "Download to Excel"

        , "Aksiyon bekleyen iş": "Work item awaiting action"
        , "Aktif takipteki iş": "Active tracking item"
        , "Bana Atanan İşler": "My Assigned Work"
        , "Bana atanan / açtığım işler": "Assigned to me / opened by me"
        , "Saha Kullanıcı": "Field User"
        , "İş takip hızlı işlemler": "Work tracking quick actions"
        , "Saha kullanıcısı kendisine atanan işleri ve kendi açtığı işleri görür. Eşleşme Takip Eden veya Talep Açan alanına göre yapılır.": "Field users see work items assigned to them and work items they opened. Matching is based on the Assigned To or Requester field."
        , "Not:": "Note:"
        , "Bu ekranda 6 aktif takip kolonu yan yana gösterilir. Diğer durumlar Excel ve arşiv tarafında eksiksiz kalır.": "This page shows 6 active tracking columns side by side. Other statuses remain complete in Excel and archive."
        , "Detayı aç": "Open details"
        , "İşin yanında açılır. Bu panelde detay durumu ve yorumlar yönetilir.": "Opens next to the work item. Detail status and comments are managed in this panel."
        , "İşin yanında açılır. Bu panelde detay durumu ve yorumlar yönetilir": "Opens next to the work item. Detail status and comments are managed in this panel"
        , "Toplam (DB):": "Total (DB):"
        , "kayıt · Sayfa": "records · Page"
        , "İş bulunamadı.": "No work item found."
        , "İş Takip ekranında gördüğün işler burada da görünmelidir. Eşleşme Takip Eden veya Talep Açan alanındaki kullanıcı adına göre yapılır.": "The work items you see on the Work Tracking page should also appear here. Matching is based on the username in the Assigned To or Requester field."
        , "Kontrol edilen kullanıcı değerleri:": "Checked user values:"
        , "Detay sağda sabit açılır; liste yerinden oynamaz.": "Details open as a fixed panel on the right; the list does not move."
        , "İş takip kaydı": "Work tracking record"
        , "İş": "Work"
        , "İş Detayı": "Work Detail"
        , "Firma adı yazın...": "Enter company name..."
        , "Firma adı": "Company name"
        , "Hesabın yok mu? Kayıt ol": "Don't have an account? Register"
        , "Yeni Hesap Oluştur": "Create New Account"
        , "Zaten hesabın var mı? Giriş yap": "Already have an account? Sign in"
        , "Veritabanı Yedeği": "Database Backup"
        , "SQL Server yedeğini sadece Admin kullanıcılar alabilir ve indirebilir.": "Only Admin users can create and download SQL Server backups."
        , "Yeni veritabanı yedeği alınsın mı? İşlem veritabanı boyutuna göre biraz sürebilir.": "Create a new database backup? This may take some time depending on the database size."
        , "DB Yedeği Al": "Create DB Backup"
        , "DB Yedeği": "DB Backup"
        , "Veritabanı:": "Database:"
        , "Bağlantı:": "Connection:"
        , "SQL Server servis hesabı:": "SQL Server service account:"
        , "Önemli:": "Important:"
        , "BACKUP DATABASE komutunda dosyayı ASP.NET değil, SQL Server servis hesabı oluşturur.": "The BACKUP DATABASE command creates the file through the SQL Server service account, not ASP.NET."
        , "Bu yüzden Desktop/proje klasörü yerine aşağıdaki gibi SQL Server'ın yazabileceği sade bir klasör kullanılmalıdır.": "Therefore, use a simple folder that SQL Server can write to, like the one below, instead of the Desktop/project folder."
        , "Alınan Yedekler": "Created Backups"
        , "Son alınan .bak dosyaları buradan indirilebilir veya silinebilir.": "The latest .bak files can be downloaded or deleted here."
        , "Henüz alınmış veritabanı yedeği yok.": "No database backup has been created yet."
        , "Oluşturma Tarihi": "Created Date"
        , "İndir": "Download"
        , "Bu yedek dosyası silinsin mi?": "Delete this backup file?"
        , "Yeni Görüşme Detayı": "New Conversation Detail"
        , "Yeni Görüşme Detayı Ekle": "Add New Conversation Detail"
        , "Görüşülen": "Contacted / Discussed With"
        , "Seçiniz...": "Select..."
        , "Seçiniz": "Select"
        , "Vazgeç": "Cancel"
        , "Detaylar -": "Details -"
        , "Arşivde Göster": "Show in Archive"
        , "Detay Düzenle": "Edit Detail"
        , "Bu kayıt silinsin mi?": "Delete this record?"
        , "Excel aktarım sayfalama": "Excel import pagination"
        , "Eşleşti": "Matched"
        , "Eşleşmedi": "Not Matched"
        , "Yeni operasyon yanıtı kaydedildi.": "New operation response saved."
        , "Atanan Kişiyi Değiştir": "Change Assigned Person"
        , "Yeni Atanan Kullanıcı": "New Assigned User"
        , "Atamayı Güncelle": "Update Assignment"
        , "Operasyon Yanıtı": "Operation Response"
        , "Henüz operasyon tarafından cevap verilmemiş.": "No response has been provided by operation yet."
        , "Bu kayda sadece atanmış kullanıcı cevap verebilir.": "Only the assigned user can respond to this record."
        , "Gönder": "Submit"
        , "Saha Hataları": "Field Issues"
        , "Tüm Durumlar": "All Statuses"
        , "Tüm Kategoriler": "All Categories"
        , "Yeni Hata Oluştur": "Create New Issue"
        , "Müşteri *": "Customer *"
        , "Hata Adı *": "Issue Name *"
        , "Atanan Kullanıcı *": "Assigned User *"
        , "Hata Adı": "Issue Name"
        , "Hoş geldiniz": "Welcome"
        , "ASP.NET Core ile web uygulamaları geliştirme": "Learn about building web apps with ASP.NET Core"
        , "hakkında bilgi edinin.": "Learn more."
        , "Uyum": "Compliance"
        , "Uyum Açıklama": "Compliance Description"
        , "örn: musteri.com": "e.g. customer.com"
        , "Açıklama (opsiyonel)": "Description (optional)"
        , "İş Takip'e Dön": "Back to Work Tracking"
        , "Excel'e dahil edilmeyen geliştirme ve eğitim işleri burada listelenir.": "Development and training work items excluded from Excel are listed here."
        , "Geliştirme ve Eğitim İşleri": "Development and Training Work Items"
        , "Talep Türü": "Request Type"
        , "Oluşturma Tarihi": "Created Date"
        , "🧩 Jira Kanban Görünüm": "🧩 Jira Kanban View"
        , "🧾 Jira Tarzı İş Takip Sistemi": "🧾 Jira-Style Work Tracking System"
        , "Talep konusu": "Request subject"
        , "Bu taskı silmek istediğinizden emin misiniz?": "Are you sure you want to delete this task?"
        , "Durumu Güncelle": "Update Status"
        , "Gelişme, not veya işlem bilgisini yaz...": "Write progress, note, or action information..."
        , "Firma Adı *": "Company Name *"
        , "Durum Değişiklik Tarihi": "Status Change Date"
        , "Durum Değ. Tarihi": "Status Chg. Date"
        , "Tüm Excel": "Full Excel"
        , "Yeni Müşteriler Excel": "New Customers Excel"
        , "Gönderildi": "Sent"
        , "Gönderilmedi": "Not Sent"
        , "Silinsin mi?": "Delete it?"
        , "Karşılama Sayfası": "Welcome Page"
        , "Hoşgeldiniz": "Welcome"
        , "Hoş geldin,": "Welcome,"
        , "Sistemi başlatıyor...": "Starting the system..."
        , "Veritabanı bağlantısı kuruluyor...": "Establishing the database connection..."
        , "Modüller yükleniyor...": "Loading modules..."
        , "Dashboard hazırlanıyor...": "Preparing the dashboard..."
        , "Operasyon · İş Takip": "Operation · Work Tracking"
        , "İş akışını daha hızlı yönetin": "Manage the workflow faster"
        , "Görünüm:": "View:"
        , "Aksiyon bekleyen kayıtlar": "Records awaiting action"
        , "Aktif takipteki işler": "Active tracking work"
        , "Entegrasyonu tamamlanmayan işler": "Work items with incomplete integration"
        , "Entegrasyonu tamamlanmayan iş": "Work item with incomplete integration"
        , "Bu kolonda gösterilecek kayıt yok.": "No records to display in this column."
        , "Oluşturan seçiniz": "Select creator"
        , "Operasyon, oluşturan veya durum seçmelisiniz.": "You must select an operation, creator, or status."
        , "Kendi Yazdı": "Developed In-House"
        , "Hizmet Aldığı Firma": "Vendor Company"
        , "Linkli Ödeme": "Payment Link"
        , "Normal Çekim": "Standard Payment"
        , "Previzyonlu Çekim": "Pre-Authorized Payment"
        , "Yazılımcı Adı": "Developer First Name"
        , "Yazılımcı Soyadı": "Developer Last Name"
        , "Aşağıdaki Gönder Butonuna Git": "Go to the submit button below"
        , "Listeye Dön": "Back to List"
        , "Ticket Gönder": "Submit Ticket"
        , "Atanan Operasyon": "Assigned Operation"
        , "Talep Eden": "Requester"
        , "Duruma göre filtrele": "Filter by status"
        , "Talep edene göre filtrele": "Filter by requester"
        , "Ticket Listesi": "Ticket List"
        , "Detay, durum ve süreç bilgileri tek tabloda gösterilir.": "Details, status, and process information are shown in one table."
        , "Ticket Detayı": "Ticket Details"

        , "İş adı, müşteri, talep açan, takip eden ara...": "Search work name, customer, requester, or assignee..."
        , "Bu sayfada İş Takip ekranında sana görünen işler listelenir. Takip Eden veya Talep Açan alanı seninle eşleşirse iş burada görünür.": "This page lists the work items visible to you on the Work Tracking page. Items appear here when the Assigned To or Requester field matches you."
        , "Kontrol edilen kullanıcı değerleri": "Checked user values"
    };

    Object.entries(supplementalFullEnglishTranslations).forEach(([source, target]) => {
        exactTranslations.en[source] = target;
        if (!Object.prototype.hasOwnProperty.call(exactTranslations.tr, target)) {
            exactTranslations.tr[target] = source;
        }
    });

    const patternTranslations = {
        tr: [
            {
                regex: /^Welcome,\s*(.+)!$/,
                replace: (_, name) => `Hoş geldin, ${name}!`
            },
            {
                regex: /^System Tickets \((\d+)\)$/,
                replace: (_, count) => `Sistem Ticketları (${count})`
            },
            {
                regex: /^Person:\s*(.+)$/,
                replace: (_, value) => `Kişi: ${value === 'All' ? 'Tümü' : value}`
            },
            {
                regex: /^Total:\s*(\d+)$/,
                replace: (_, count) => `Toplam: ${count}`
            },
            {
                regex: /^(\d+) records$/,
                replace: (_, count) => `${count} kayıt`
            },
            {
                regex: /^(\d+)\-(\d+) \/ (\d+) records$/,
                replace: (_, from, to, total) => `${from}-${to} / ${total} kayıt`
            },
            {
                regex: /^Page:\s*(\d+)\/(\d+)$/,
                replace: (_, current, total) => `Sayfa: ${current}/${total}`
            },
            {
                regex: /^Total Records:\s*(\d+)$/,
                replace: (_, count) => `Toplam Kayıt: ${count}`
            },
            {
                regex: /^Matched:\s*(\d+)$/,
                replace: (_, count) => `Eşleşen: ${count}`
            },
            {
                regex: /^Unmatched:\s*(\d+)$/,
                replace: (_, count) => `Eşleşmeyen: ${count}`
            },
            {
                regex: /^Record No:\s*#(\d+)$/,
                replace: (_, id) => `Kayıt No: #${id}`
            },
            {
                regex: /^Matched Customers:\s*(\d+)$/,
                replace: (_, count) => `Eşleşen Müşteriler: ${count}`
            },
            {
                regex: /^Unmatched Customers:\s*(\d+)$/,
                replace: (_, count) => `Eşleşmeyen Müşteriler: ${count}`
            },
            {
                regex: /^Matched:\s*(\d+)$/,
                replace: (_, count) => `Eşleşen: ${count}`
            },
            {
                regex: /^Unmatched:\s*(\d+)$/,
                replace: (_, count) => `Eşleşmeyen: ${count}`
            }
        ],
        en: [
            {
                regex: /^Hoş geldin,\s*(.+)!$/,
                replace: (_, name) => `Welcome, ${name}!`
            },
            {
                regex: /^Sistem Ticketları \((\d+)\)$/,
                replace: (_, count) => `System Tickets (${count})`
            },
            {
                regex: /^Kişi:\s*(.+)$/,
                replace: (_, value) => `Person: ${value === 'Tümü' ? 'All' : value}`
            },
            {
                regex: /^Toplam:\s*(\d+)$/,
                replace: (_, count) => `Total: ${count}`
            },
            {
                regex: /^(\d+) kayıt$/,
                replace: (_, count) => `${count} records`
            },
            {
                regex: /^(\d+)\-(\d+) \/ (\d+) kayıt$/,
                replace: (_, from, to, total) => `${from}-${to} / ${total} records`
            },
            {
                regex: /^Sayfa:\s*(\d+)\/(\d+)$/,
                replace: (_, current, total) => `Page: ${current}/${total}`
            },
            {
                regex: /^Toplam Kayıt:\s*(\d+)$/,
                replace: (_, count) => `Total Records: ${count}`
            },
            {
                regex: /^Eşleşen:\s*(\d+)$/,
                replace: (_, count) => `Matched: ${count}`
            },
            {
                regex: /^Eşleşmeyen:\s*(\d+)$/,
                replace: (_, count) => `Unmatched: ${count}`
            },
            {
                regex: /^Kayıt No:\s*#(\d+)$/,
                replace: (_, id) => `Record No: #${id}`
            },
            {
                regex: /^Eşleşen Müşteriler:\s*(\d+)$/,
                replace: (_, count) => `Matched Customers: ${count}`
            },
            {
                regex: /^Eşleşmeyen Müşteriler:\s*(\d+)$/,
                replace: (_, count) => `Unmatched Customers: ${count}`
            },
            {
                regex: /^Eşleşen:\s*(\d+)$/,
                replace: (_, count) => `Matched: ${count}`
            },
            {
                regex: /^Eşleşmeyen:\s*(\d+)$/,
                replace: (_, count) => `Unmatched: ${count}`
            },
            {
                regex: /^Müşteri ID\s+(\d+)\s+bulunamadı$/,
                replace: (_, id) => `Customer ID ${id} was not found`
            },
            {
                regex: /^Customer ID\s+(\d+)\s+was not found$/,
                replace: (_, id) => `Müşteri ID ${id} bulunamadı`
            }
        ]
    };


    const fullPagePatternTranslations = {
        en: [
            {
                regex: /^Hoş geldin,\s*(.+)!$/,
                replace: (_, name) => `Welcome, ${name}!`
            },
            {
                regex: /^(.+)\s+kayıt\s+·\s+Sayfa\s+(\d+)\s*\/\s*(\d+)$/,
                replace: (_, count, page, total) => `${count} records · Page ${page}/${total}`
            },
            {
                regex: /^(\d+)\s+kayıt$/,
                replace: (_, count) => `${count} records`
            },
            {
                regex: /^(\d+)\s*-\s*(\d+)\s*\/\s*(\d+)\s+kayıt$/,
                replace: (_, start, end, total) => `${start}-${end} / ${total} records`
            },
            {
                regex: /^([\d.,]+)\s*kayıttan\s+([\d.,]+)\s*-\s*([\d.,]+)\s+arasındaki\s+kayıtlar\s+gösteriliyor$/,
                replace: (_, total, start, end) => `Showing ${start} to ${end} of ${total} records`
            },
            {
                regex: /^([\d.,]+)\s+kayıttan\s+([\d.,]+)\s+kayıt\s+gösteriliyor$/,
                replace: (_, total, shown) => `Showing ${shown} of ${total} records`
            },
            {
                regex: /^Toplam\s+([\d.,]+)\s+kayıttan\s+([\d.,]+)\s+kayıt\s+gösteriliyor$/,
                replace: (_, total, shown) => `Showing ${shown} of ${total} total records`
            },
            {
                regex: /^Kayıt\s+No:\s*#?(\d+)$/,
                replace: (_, id) => `Record No: #${id}`
            },
            {
                regex: /^Sıra\s+(\d+)$/,
                replace: (_, order) => `Order ${order}`
            },
            {
                regex: /^Müşteri\s*:\s*(.+)$/,
                replace: (_, customer) => `Customer: ${customer}`
            },
            {
                regex: /^Tür\s*:\s*(.+)$/,
                replace: (_, type) => `Type: ${type}`
            },
            {
                regex: /^Talep Açan\s*:\s*(.+)$/,
                replace: (_, requester) => `Requester: ${requester}`
            },
            {
                regex: /^Oluşturma\s*:\s*(.+)$/,
                replace: (_, date) => `Created: ${date}`
            },
            {
                regex: /^Atanan Kullanıcı\s*:\s*(.+)$/,
                replace: (_, user) => `Assigned User: ${user}`
            },
            {
                regex: /^Kalan gün:\s*([\d.,]+)$/,
                replace: (_, days) => `Remaining days: ${days}`
            },
            {
                regex: /^Yetersiz izin hakkı\. Kalan gün:\s*([\d.,]+)\.?$/,
                replace: (_, days) => `Insufficient leave entitlement. Remaining days: ${days}.`
            },
            {
                regex: /^(.+)\s+için izin hakkı güncellendi\.?$/,
                replace: (_, user) => `Leave entitlement updated for ${user}.`
            },
            {
                regex: /^Durum:\s*(.+)\s*→\s*Canlıda Entegrasyon Tamamlandı\. Kayıt otomatik arşive alındı\.$/,
                replace: (_, oldStatus) => `Status: ${oldStatus} → Live Integration Completed. The record was automatically archived.`
            },
            {
                regex: /^Durum güncellendi\. \((.+)\s*→\s*(.+)\)$/,
                replace: (_, oldStatus, newStatus) => `Status updated. (${oldStatus} → ${newStatus})`
            },
            {
                regex: /^Oluşturan güncellendi\. \((.+)\s*→\s*(.+)\)$/,
                replace: (_, oldCreator, newCreator) => `Creator updated. (${oldCreator} → ${newCreator})`
            },
            {
                regex: /^Ticket bu aşamada (.+) uygun değil\. Durum:\s*(.+)$/,
                replace: (_, action, status) => `The ticket is not eligible for ${action} at this stage. Status: ${status}`
            },
            {
                regex: /^Müşteri ID\s+(\d+)\s+bulunamadı$/,
                replace: (_, id) => `Customer ID ${id} was not found`
            },
            {
                regex: /^Müşteri #(\d+)$/,
                replace: (_, id) => `Customer #${id}`
            },
            {
                regex: /^📋 Detaylar\s*-\s*(.+)$/,
                replace: (_, name) => `📋 Details - ${name}`
            }
        ],
        tr: []
    };

    patternTranslations.en.push(...fullPagePatternTranslations.en);


    const finalPagePatternTranslations = {
        en: [
            {
                regex: /^OK\. Kullanıcı:\s*(.+)\s*\/\s*Şifre:\s*(.+)$/,
                replace: (_, username, password) => `OK. User: ${username} / Password: ${password}`
            },
            {
                regex: /^Veritabanı yedeği oluşturuldu:\s*(.+)$/,
                replace: (_, fileName) => `Database backup created: ${fileName}`
            },
            {
                regex: /^Yedek başarıyla alındı:\s*(.+)$/,
                replace: (_, fileName) => `Backup created successfully: ${fileName}`
            },
            {
                regex: /^Yedek alınamadı:\s*(.+)$/,
                replace: (_, reason) => `Backup could not be created: ${reason}`
            },
            {
                regex: /^Klasör:\s*(.+)\s*\|?$/,
                replace: (_, folder) => `Folder: ${folder}`
            },
            {
                regex: /^SQL Server servis hesabı:\s*(.+)\s*\|?$/,
                replace: (_, account) => `SQL Server service account: ${account}`
            },
            {
                regex: /^Veritabanı yedeği silinirken hata oluştu\. Dosya:\s*(.+)$/,
                replace: (_, fileName) => `An error occurred while deleting the database backup. File: ${fileName}`
            },
            {
                regex: /^Kayıt sırasında hata:\s*(.+)$/,
                replace: (_, reason) => `Error during save: ${reason}`
            },
            {
                regex: /^Güncelleme sırasında hata:\s*(.+)$/,
                replace: (_, reason) => `Error during update: ${reason}`
            },
            {
                regex: /^Silme sırasında hata:\s*(.+)$/,
                replace: (_, reason) => `Error during delete: ${reason}`
            },
            {
                regex: /^Excel okunamadı:\s*(.+)$/,
                replace: (_, reason) => `Excel could not be read: ${reason}`
            },
            {
                regex: /^(\d+)\s+kayıt içe aktarıldı\.\s*(\d+)\s+kayıt detaylara eklendi\.$/,
                replace: (_, imported, details) => `${imported} records imported. ${details} records added to details.`
            },
            {
                regex: /^Müşteri ID\s+(.+)\s+bulunamadı$/,
                replace: (_, id) => `Customer ID ${id} was not found`
            },
            {
                regex: /^Ticket bu aşamada Operasyon 1 kararına uygun değil\. Durum:\s*(.+)$/,
                replace: (_, status) => `The ticket is not eligible for an Operation 1 decision at this stage. Status: ${status}`
            },
            {
                regex: /^Ticket bu aşamada Operasyon 2 kararına uygun değil\. Durum:\s*(.+)$/,
                replace: (_, status) => `The ticket is not eligible for an Operation 2 decision at this stage. Status: ${status}`
            },
            {
                regex: /^Ticket bu aşamada entegrasyon tamamlama işlemine uygun değil\. Durum:\s*(.+)$/,
                replace: (_, status) => `The ticket is not eligible for integration completion at this stage. Status: ${status}`
            },
            {
                regex: /^Ticket bu aşamada canlı açılışa uygun değil\. Durum:\s*(.+)$/,
                replace: (_, status) => `The ticket is not eligible for go-live at this stage. Status: ${status}`
            },
            {
                regex: /^Ticket bu aşamada eksik evrak tamamlama işlemine uygun değil\. Durum:\s*(.+)$/,
                replace: (_, status) => `The ticket is not eligible for missing-document completion at this stage. Status: ${status}`
            },
            {
                regex: /^Ticket bu aşamada uyum kararına uygun değil\. Durum:\s*(.+)$/,
                replace: (_, status) => `The ticket is not eligible for a compliance decision at this stage. Status: ${status}`
            },
            {
                regex: /^Durum güncellendi\. \((.+)\s*→\s*(.+)\)$/,
                replace: (_, oldStatus, newStatus) => `Status updated. (${oldStatus} → ${newStatus})`
            },
            {
                regex: /^Oluşturan güncellendi\. \((.+)\s*→\s*(.+)\)$/,
                replace: (_, oldCreator, newCreator) => `Creator updated. (${oldCreator} → ${newCreator})`
            },
            {
                regex: /^(.+)\s+kayıt içerisinden bulunan$/,
                replace: (_, count) => `filtered from ${count} records`
            },
            {
                regex: /^Sayfada\s*(\d+)\s*kayıt göster$/,
                replace: (_, count) => `Show ${count} records per page`
            },
            {
                regex: /^([\d.,]+)\s+kayıt seçildi$/,
                replace: (_, count) => `${count} records selected`
            }
        ],
        tr: []
    };

    patternTranslations.en.push(...finalPagePatternTranslations.en);


    const dynamicSupplementalPatternTranslations = {
        en: [
            {
                regex: /^Sayfa\s+([\d.,]+)\s*\/\s*([\d.,]+)\s*\(Toplam:\s*([\d.,]+)\)$/,
                replace: (_, current, totalPages, totalCount) => `Page ${current} / ${totalPages} (Total: ${totalCount})`
            },
            {
                regex: /^([\d.,]+)\s+gün$/,
                replace: (_, days) => `${days} days`
            },
            {
                regex: /^Kalan gün:\s*([\d.,]+)$/,
                replace: (_, days) => `Remaining days: ${days}`
            },
            {
                regex: /^Toplam:\s*@?([\d.,]+)$/,
                replace: (_, count) => `Total: ${count}`
            },
            {
                regex: /^Bekleyen:\s*([\d.,]+)$/,
                replace: (_, count) => `Pending: ${count}`
            },
            {
                regex: /^Onaylanan:\s*([\d.,]+)$/,
                replace: (_, count) => `Approved: ${count}`
            },
            {
                regex: /^Reddedilen:\s*([\d.,]+)$/,
                replace: (_, count) => `Rejected: ${count}`
            },
            {
                regex: /^([\d.,]+)\s+kayıt\s+·\s+Sayfa\s+([\d.,]+)\s*\/\s*([\d.,]+)$/,
                replace: (_, count, page, totalPages) => `${count} records · Page ${page}/${totalPages}`
            },
            {
                regex: /^Kayıt:\s*(.+)$/,
                replace: (_, value) => `Record: ${value}`
            },
            {
                regex: /^Müşteri:\s*(.+)$/,
                replace: (_, value) => `Customer: ${translateValue(value, 'en')}`
            },
            {
                regex: /^👤\s*(.+)$/,
                replace: (_, value) => `👤 ${translateValue(value, 'en')}`
            },
            {
                regex: /^Kontrol edilen kullanıcı değerleri:\s*(.+)$/,
                replace: (_, value) => `Checked user values: ${translateValue(value, 'en')}`
            },
            {
                regex: /^Kaynak:\s*(.+)$/,
                replace: (_, value) => `Source: ${translateValue(value, 'en')}`
            },
            {
                regex: /^Detaylar\s*-\s*(.+)$/,
                replace: (_, value) => `Details - ${value}`
            },
            {
                regex: /^📋\s*Detaylar\s*-\s*(.+)$/,
                replace: (_, value) => `📋 Details - ${value}`
            },
            {
                regex: /^Sıra\s+([\d.,]+)$/,
                replace: (_, order) => `Order ${order}`
            },
            {
                regex: /^(.+)\s+için izin hakkı güncellendi\.?$/,
                replace: (_, user) => `Leave entitlement updated for ${user}.`
            },
            {
                regex: /^Yetersiz izin hakkı\.\s*Kalan gün:\s*([\d.,]+)\.?$/,
                replace: (_, days) => `Insufficient leave entitlement. Remaining days: ${days}.`
            }
        ],
        tr: []
    };

    patternTranslations.en.push(...dynamicSupplementalPatternTranslations.en);

    const finalTurkishOnlyTranslations = {
        "Archive - Other Work": "Arşiv - Diğer İşler",
        "Archive - Other Work Items": "Arşiv - Diğer İşler",
        "The status filter loads all values from Parameters > Status; the Excel export downloads all months and all statuses.": "Durum filtresi Parametreler > Durum içindeki tüm değerleri çeker; Excel çıktısı tüm ayları ve tüm durumları indirir.",
        "Development and training work items excluded from Excel are listed here.": "Excel'e dahil edilmeyen geliştirme ve eğitim işleri burada listelenir.",
        "Work / Contact": "İş / Görüşülen",
        "Customer:": "Müşteri:",
        "Reporter": "Bildiren",
        "Use this page to detail your site's privacy policy.": "Bu sayfayı sitenizin gizlilik politikasını açıklamak için kullanın.",
        "Learn about": "Hakkında bilgi edinin:",
        "building Web apps with ASP.NET Core": "ASP.NET Core ile web uygulamaları geliştirme",
        "New operation response saved.": "Yeni operasyon yanıtı kaydedildi.",
        "Issue Name": "Hata Adı",
        "Software": "Yazılım",
        "Hardware": "Donanım",
        "Network": "Ağ",
        "Database": "Veritabanı",
        "Other": "Diğer",
        "Open": "Açık",
        "Closed": "Kapalı",
        "Select": "Seçiniz",
        "Select...": "Seçiniz...",
        "Add New Conversation Detail": "Yeni Görüşme Detayı Ekle",
        "Firma First name *": "Firma Adı *",
        "Firma First name": "Firma Adı",
        "Parametre First name": "Parametre Adı"
    };

    Object.entries(finalTurkishOnlyTranslations).forEach(([source, target]) => {
        exactTranslations.tr[source] = target;
    });

    const finalEnglishOnlyTranslations = {
        "Firma First name *": "Company Name *",
        "Firma First name": "Company Name",
        "Kategori:": "Category:",
        "Bildiren": "Reporter",
        "Detay durumu ve yorumlar": "Detail status and comments",
        "Yeni Detay Durumu": "New Detail Status",
        "Parametre First name": "Parameter Name"
    };

    Object.entries(finalEnglishOnlyTranslations).forEach(([source, target]) => {
        exactTranslations.en[source] = target;
    });

    Object.entries(exactTranslations.tr).forEach(([englishText, turkishText]) => {
        if (!Object.prototype.hasOwnProperty.call(exactTranslations.en, turkishText)) {
            exactTranslations.en[turkishText] = englishText;
        }
    });

    const fullEnglishTranslations = {
        "Entegrasyon Tamamlanmadı": "Integration Not Completed",
        "Entegrasyon Tamamlandı": "Integration Completed",
        "Canlıda Entegrasyon Tamamlandı": "Production Integration Completed",
        "Satışa Bilgi Verildi": "Sales Informed",
        "Satışa Gönderildi": "Sent to Sales",
        "Satışa Bilgi": "Sales Notification",
        "Döküman İletildi": "Document Sent",
        "Doküman İletildi": "Document Sent",
        "Dokuman İletildi": "Document Sent",
        "Döküman Gönderildi": "Document Sent",
        "Doküman Gönderildi": "Document Sent",
        "Dokuman Gönderildi": "Document Sent",
        "Arşiv": "Archive",
        "Arşivlendi": "Archived",
        "Firma": "Company",
        "Saha": "Field",
        "Kurumsal Saha": "Corporate Field",
        "Operasyon": "Operations",
        "Operasyon Super Admin": "Operations Super Admin",
        "Operasyon Süper Admin": "Operations Super Admin",
        "Saha Super Admin": "Field Super Admin",
        "Saha Süper Admin": "Field Super Admin",
        "VPOS Kullanıcısı": "VPOS User",
        "VPOS Kullanıcı": "VPOS User",
        "Cüzdan": "Wallet",
        "PF İş Takip": "PF Work Tracking",
        "Cüzdan İş Takip": "Wallet Work Tracking",
        "VPOS İş Takip": "VPOS Work Tracking",
        "İş Takip Yorumu": "Work Tracking Comment",
        "Müşteri ID": "Customer ID",
        "Oluşturma Tarihi": "Created Date",
        "Saha Sorumlusu": "Field Assignee",
        "Uyum Onayı Bekleniyor": "Compliance Approval Pending",
        "Atanmamış": "Unassigned",
        "Atanmadı": "Not Assigned",
        "Bana Atanan İşler": "My Assigned Work",
        "Bana atanan / açtığım işler": "Assigned to Me / Work I Opened",
        "Açtığım VPOS İşleri": "My VPOS Work Items",
        "Ekle": "Add",
        "Kayıt Yok": "No Records",
        "Kayıt yok": "No records",
        "Onaylandı": "Approved",
        "Talep Türü": "Request Type",
        "Türü": "Type",
        "Tek Harf / Güçlü Benzerlik": "Single-Letter / Strong Match",
        "Yakın Firma Adı": "Similar Company Name",
        "Önemli": "Important",
        "Admin Menü": "Admin Menu",
        "Aksiyon bekleyen iş": "Work Awaiting Action",
        "Aksiyon bekleyen kayıtlar": "Records Awaiting Action",
        "Aktif takipteki iş": "Actively Tracked Work",
        "Aktif takipteki işler": "Actively Tracked Work Items",
        "Aktif İş": "Active Work",
        "Alınan Yedekler": "Available Backups",
        "Arşivde göster": "Show in Archive",
        "Ay Toplamı": "Monthly Total",
        "Ay-Kişi Dağılımı": "Monthly Person Distribution",
        "Açıklama girilmedi": "No description provided",
        "Açıklama girilmemiş.": "No description provided.",
        "Aşağı taşı": "Move Down",
        "Bildirimleri aç": "Enable Notifications",
        "Bilgiler zaten kayıtlı.": "Information is already saved.",
        "Bulunan Müşteri ID": "Matched Customer ID",
        "Canlı ortama alınan işler": "Work Moved to Production",
        "Canlıda": "In Production",
        "DB Yedeği": "DB Backup",
        "DB Yedeği Al": "Create DB Backup",
        "Detay Kaydı": "Detail Record",
        "Detayı aç": "Open Detail",
        "Doküman": "Document",
        "Durum / Sebep": "Status / Reason",
        "Durum Belirtilmemiş": "Status Not Specified",
        "Durum Değişikliği": "Status Change",
        "Durum Yok": "No Status",
        "Dökümanı iletilen iş": "Work with Document Sent",
        "Dökümanı iletilen işler": "Work Items with Documents Sent",
        "Dönem seçimi": "Period Selection",
        "Entegrasyon Başarısız": "Integration Failed",
        "Entegrasyonu tamamlanan işler": "Completed Integrations",
        "Entegrasyonu tamamlanmayan işler": "Incomplete Integrations",
        "Entegre Olunamama Oranı": "Integration Failure Rate",
        "Erişim engellendi": "Access Denied",
        "Excel aktarım sayfalama": "Excel import pagination",
        "Excel'e İndir": "Download Excel",
        "Excel Üye İşyeri": "Excel Merchant",
        "Excel Üye İşyeri ID": "Excel Merchant ID",
        "Eşleşen VKN": "Matched Tax ID",
        "Eşleşen Üye İşyeri": "Matched Merchant",
        "Eşleşme Tipi": "Match Type",
        "Firma Adi": "Company Name",
        "Gün Sayısı": "Number of Days",
        "Güncel Aktif Yük": "Current Active Workload",
        "Güncel Yük Payı": "Current Workload Share",
        "Harici Müşteri ID": "External Customer ID",
        "Harici müşteri ID / kodu": "External customer ID / code",
        "Hata Arşivi": "Issue Archive",
        "Hata Detayı": "Issue Detail",
        "Hizmet Aldığı Firma": "Service Provider",
        "Hoşgeldiniz!": "Welcome!",
        "Katılımcılar": "Participants",
        "Kaynak Firma": "Source Company",
        "Kayıt": "Record",
        "Kayıt Ay": "Record Month",
        "Kayıt Ay No": "Record Month No",
        "Kayıt Yılı": "Record Year",
        "Kendi Yazdı": "Developed In-House",
        "Kişi ve arama filtrelerini tek panelden yönetin": "Manage person and search filters from one panel",
        "Kişi:": "Person:",
        "Kişideki İş": "Work per Person",
        "Kısa operasyon notu...": "Short operations note...",
        "Linkli Ödeme": "Payment Link",
        "Mevcut Firma": "Current Company",
        "Mevcut Müşteri ID": "Current Customer ID",
        "Musteri Firma": "Customer Company",
        "Müşteri Firma": "Customer Company",
        "Müşteri Detayları": "Customer Details",
        "Müşteri Sayısı": "Customer Count",
        "Normal Çekim": "Standard Payment",
        "Operasyon Kullanıcı": "Operations User",
        "Operasyon Notu": "Operations Note",
        "Operasyon Personeli": "Operations Staff",
        "Operasyon İşleri": "Operations Work",
        "Operasyona Açılan": "Opened for Operations",
        "Previzyonlu Çekim": "Preauthorization Payment",
        "Profil menüsünü aç": "Open profile menu",
        "Rapor ayı": "Report Month",
        "Rapor yılı": "Report Year",
        "Saha - Hata Listesi": "Field - Issue List",
        "Saha - Yeni Hata": "Field - New Issue",
        "Saha Ekibinin İşleri": "Field Team Work",
        "Saha Hataları - Operasyon": "Field Issues - Operations",
        "Saha ekibi kişi filtresi": "Field team person filter",
        "Satış ekibine bilgi verilen işler": "Work Items Reported to Sales",
        "Satışa aktarılan iş": "Work Sent to Sales",
        "Sistem Müşteri ID": "System Customer ID",
        "Sıfırla": "Reset",
        "Tamamlanma/Arşiv Tarihi": "Completion/Archive Date",
        "Tüm Açılan Ticketlar": "All Opened Tickets",
        "VKN Eşleştirme": "Tax ID Matching",
        "VKN Numarası": "Tax ID Number",
        "Vergi Kimlik Numarası": "Tax Identification Number",
        "Vergi Numarası": "Tax Number",
        "Veritabanı Yedeği": "Database Backup",
        "Yapılacak İşlem": "Action to Perform",
        "Yeni Müşteri": "New Customer",
        "Yeni VPOS Kaydı": "New VPOS Record",
        "Yeni VPOS Müşterisi": "New VPOS Customer",
        "VPOS Müşterileri": "VPOS Customers",
        "VPOS İş Detayı": "VPOS Work Detail",
        "Varsayılan durum: Aktif": "Default status: Active",
        "İndir": "Download",
        "İptal Et": "Cancel",
        "İş": "Work",
        "İş Konusu": "Work Subject",
        "İş No": "Work No",
        "İş Tipi": "Work Type",
        "İş Yükü Payı": "Workload Share",
        "İş detayı": "Work detail",
        "İş durumu değişti": "Work status changed",
        "İş takip hızlı işlemler": "Work tracking quick actions",
        "İşlemler": "Actions",
        "İşyeri": "Merchant",
        "Yukarı taşı": "Move Up",
        "Yönetim": "Management",
        "Yükleme": "Upload",
        "Yüklenen Excel": "Uploaded Excel",
        "Yükleyen": "Uploaded By",
        "Yıl": "Year",
        "Ödeme Türleri:": "Payment Types:",
        "Ödeme Yöntemleri:": "Payment Methods:",
        "Önerilen VKN": "Suggested Tax ID",
        "Üye İşyeri": "Merchant",
        "Üye İşyeri ID": "Merchant ID",
        "Üye İşyeri No": "Merchant No",
        "Üyeİşyeri": "Merchant",
        "ÜyeİşyeriId": "Merchant ID",
        "Ana Sayfa | BT Operasyon Takip": "Home | IT Operations Tracking",
        "Raporlar | BT Operasyon Takip": "Reports | IT Operations Tracking",
        "Geçersiz kayıt.": "Invalid record.",
        "Geçersiz durum.": "Invalid status.",
        "Geçersiz ürün seçimi.": "Invalid product selection.",
        "Geçersiz kullanıcı rolü.": "Invalid user role.",
        "Geçersiz giriş. Lütfen tüm alanları doğru doldurun.": "Invalid input. Please complete all fields correctly.",
        "İşlem sırasında beklenmeyen bir hata oluştu.": "An unexpected error occurred while processing the request.",
        "Kayıt sırasında beklenmeyen bir hata oluştu.": "An unexpected error occurred while saving the record.",
        "Güncelleme sırasında beklenmeyen bir hata oluştu.": "An unexpected error occurred while updating the record.",
        "Silme sırasında beklenmeyen bir hata oluştu.": "An unexpected error occurred while deleting the record.",
        "Silme işlemi sırasında hata oluştu.": "An error occurred while deleting the record.",
        "Silme işlemi başarısız.": "Delete operation failed.",
        "Detay eklenemedi. Lütfen tekrar deneyin.": "The detail could not be added. Please try again.",
        "Kullanıcı adı veya şifre hatalı.": "Invalid username or password.",
        "Kullanıcı başarıyla eklendi.": "User added successfully.",
        "Kullanıcı bulunamadı.": "User not found.",
        "Bu kullanıcı adı zaten kullanılıyor.": "This username is already in use.",
        "Bu e-posta adresi zaten kullanılıyor.": "This email address is already in use.",
        "Kullanıcı adı 3-50 karakter olmalıdır.": "Username must be 3-50 characters.",
        "E-posta adresi çok uzun.": "Email address is too long.",
        "Şifre en az 10 karakter olmalı ve en az bir harf ile bir rakam içermelidir.": "Password must be at least 10 characters and contain at least one letter and one number.",
        "En az bir ürün tipi seçmelisiniz: PF, VPOS veya Cüzdan.": "You must select at least one product type: PF, VPOS, or Wallet.",
        "Müşteride en az bir ürün tipi seçili kalmalıdır.": "At least one product type must remain selected for the customer.",
        "Müşteri bulunamadı.": "Customer not found.",
        "Müşteri bilgileri alınamadı.": "Customer information could not be retrieved.",
        "Müşteri bilgileri yüklenemedi.": "Customer information could not be loaded.",
        "Müşteri ve entegrasyon işi oluşturulamadı. Lütfen tekrar deneyin.": "The customer and integration work item could not be created. Please try again.",
        "Müşteri veya entegrasyon için önemli not...": "Important note for the customer or integration...",
        "Müşteri ID 100 karakterden uzun olamaz.": "Customer ID cannot exceed 100 characters.",
        "Harici müşteri ID 100 karakterden uzun olamaz.": "External customer ID cannot exceed 100 characters.",
        "Hata adı zorunludur.": "Issue name is required.",
        "Hata kategorisi zorunludur.": "Issue category is required.",
        "Hata kaydı silindi.": "Issue record deleted.",
        "Kayıt tipi seçiniz.": "Select a record type.",
        "Lütfen .xlsx formatında bir Excel dosyası seçin.": "Please select an Excel file in .xlsx format.",
        "Lütfen ay seçin.": "Please select a month.",
        "Yalnızca .xlsx dosyaları destekleniyor.": "Only .xlsx files are supported.",
        "Excel dosyası 20 MB sınırını aşamaz.": "The Excel file cannot exceed the 20 MB limit.",
        "Excel dosyası okunamadı. Dosya biçimini ve içeriğini kontrol edin.": "The Excel file could not be read. Check the file format and content.",
        "Excel okunamadı. Dosya biçimini ve içeriğini kontrol edin.": "The Excel file could not be read. Check the file format and content.",
        "Excel okunurken hata oluştu.": "An error occurred while reading the Excel file.",
        "Excel içinde çalışma sayfası bulunamadı.": "No worksheet was found in the Excel file.",
        "Excel çalışma kitabı okunamadı.": "The Excel workbook could not be read.",
        "Excel kolonları bulundu fakat firma/üye işyeri kaydı okunamadı.": "Excel columns were found, but no company/merchant record could be read.",
        "Eşleştirme dosyası bulunamadı veya süresi doldu.": "The matching file was not found or has expired.",
        "Eşleştirme dosyası bulunamadı veya süresi doldu. Excel'i tekrar yükleyin.": "The matching file was not found or has expired. Upload the Excel file again.",
        "Kaydedilecek yeni ve güvenli eşleşme bulunamadı.": "No new safe matches were found to save.",
        "Mevcut VKN doğru kabul edilerek korundu.": "The existing Tax ID was accepted as correct and preserved.",
        "Mevcut VKN korundu; güvenli bulunan Müşteri ID kaydedilecek.": "The existing Tax ID was preserved; the safely matched Customer ID will be saved.",
        "VPOS iş atamasını yalnızca Operasyon Süper Admin veya Admin değiştirebilir.": "Only an Operations Super Admin or Admin can change a VPOS work assignment.",
        "VPOS işleri yalnızca Operasyon grubundaki kullanıcılara atanabilir.": "VPOS work can only be assigned to users in the Operations group.",
        "VPOS kullanıcıları bu ekranda operasyon yorumu ekleyemez.": "VPOS users cannot add operations comments on this screen.",
        "VPOS kullanıcıları İş Takip ekranını salt okunur görüntüler.": "VPOS users view the Work Tracking screen in read-only mode.",
        "VPOS kullanıcıları İş Takip ekranını salt okunur görüntüler. Durumu operasyon ekibi günceller.": "VPOS users view the Work Tracking screen in read-only mode. The Operations team updates the status.",
        "VPOS kullanıcısı yeni işi VPOS Yeni İş ekranından açmalıdır. Atama sistem tarafından iş yoğunluğuna göre yapılır.": "VPOS users must open new work from the New VPOS Work screen. Assignment is made automatically based on workload.",
        "VPOS müşterisi seçiniz.": "Select a VPOS customer.",
        "İş konusu zorunludur.": "Work subject is required.",
        "İş kaydı bulunamadı.": "Work record not found.",
        "İş yoğunluğuna göre atama yapılamadı. Operasyon rolünde en az bir kullanıcı olmalı.": "Workload-based assignment could not be made. At least one Operations user is required.",
        "Operasyon kullanıcısı bulunamadı.": "Operations user not found.",
        "Operasyon seçiniz": "Select Operations user",
        "Oluşturan seçiniz": "Select creator",
        "Operasyon, oluşturan veya durum seçmelisiniz.": "Select an operations user, creator, or status.",
        "Saha yorumu boş olamaz.": "Field comment cannot be empty.",
        "Saha yorumu eklendi.": "Field comment added.",
        "Operasyon yorumu eklendi.": "Operations comment added.",
        "Yorum boş olamaz.": "Comment cannot be empty.",
        "Açıklama 4000 karakteri aşamaz.": "Description cannot exceed 4000 characters.",
        "Başlık zorunludur ve 200 karakteri aşamaz.": "Title is required and cannot exceed 200 characters.",
        "Bu kayıt silinsin mi? Bu işlem geri alınamaz.": "Delete this record? This action cannot be undone.",
        "Bu iş takip kaydı silinsin mi? Bu işlem geri alınamaz.": "Delete this work tracking record? This action cannot be undone.",
        "Bu müşteriyi ve tüm detaylarını silmek istediğinizden emin misiniz?": "Are you sure you want to delete this customer and all related details?",
        "Bu detay kaydı silinsin mi?": "Delete this detail record?",
        "Bu ticket kaydı kalıcı olarak silinecek. Devam edilsin mi?": "This ticket record will be permanently deleted. Continue?",
        "Henüz alınmış veritabanı yedeği yok.": "No database backup has been created yet.",
        "Son alınan .bak dosyaları buradan indirilebilir veya silinebilir.": "Recent .bak files can be downloaded or deleted here.",
        "SQL Server yedeğini sadece Admin kullanıcılar alabilir ve indirebilir.": "Only Admin users can create and download SQL Server backups.",
        "Backup oluşturulamadı. Ayrıntılar sunucu günlüğüne kaydedildi.": "Backup could not be created. Details were written to the server log.",
        "Backup silinemedi. Ayrıntılar sunucu günlüğüne kaydedildi.": "Backup could not be deleted. Details were written to the server log.",
        "Geçersiz ay formatı. Örn: 2026-02": "Invalid month format. Example: 2026-02",
        "Entegrasyon Tamamlanmadı seçildiğinde açıklama girmek zorunludur.": "A description is required when Integration Not Completed is selected.",
        "Entegrasyonun neden tamamlanmadığını yazın...": "Describe why the integration was not completed...",
        "Entegrasyon Tamamlandı seçildi. Kayıt otomatik olarak arşive alındı.": "Integration Completed was selected. The record was archived automatically.",
        "Entegrasyon Tamamlanmadı seçildi. Kayıt otomatik olarak arşive alındı.": "Integration Not Completed was selected. The record was archived automatically.",
        "Canlıda Entegrasyon Tamamlandı seçildi. Kayıt otomatik olarak arşive alındı.": "Production Integration Completed was selected. The record was archived automatically.",
        "PF, VPOS ve Cüzdan dahil size atanmış aktif işleri tek ekrandan takip edebilirsiniz.": "Track active work assigned to you across PF, VPOS, and Wallet on a single screen.",
        "Size atanmış aktif işleri görüntüleyebilir, operasyon ve saha yorumlarını takip edebilirsiniz.": "View active work assigned to you and follow operations and field comments.",
        "Saha ekibine atanmış işleri görüntüleyebilir, kişi bazında filtreleyebilir ve operasyon/saha yorumlarını takip edebilirsiniz.": "View work assigned to the Field team, filter by person, and follow operations/field comments.",
        "Hesabın yok mu? Kayıt ol": "No account? Register",
        "Gelişme, not veya işlem bilgisini yaz...": "Enter an update, note, or action...",
        "Hata adı, açıklama, atanan veya müşteri...": "Issue name, description, assignee, or customer...",
        "Hata, açıklama veya atanan kişi ara...": "Search issue, description, or assignee...",
        "Firma, VKN veya müşteri ID...": "Company, Tax ID, or customer ID...",
        "Firma, site veya yetkili ara...": "Search company, website, or contact...",
        "Firma, yetkili, telefon...": "Company, contact, phone...",
        "Saha yorumu girin...": "Enter field comment...",
        "Müşteri ara...": "Search customer...",
        "İş veya müşteri ara...": "Search work or customer...",
        "İş, müşteri veya talep açıklaması ara...": "Search work, customer, or request description...",
        "Geçerli bir müşteri durumu seçiniz.": "Select a valid customer status.",
        "Entegrasyon işi atanamadı. Operasyon rolünde en az bir aktif kullanıcı bulunmalıdır.": "The integration work item could not be assigned. At least one active Operations user is required."
};

    Object.entries(fullEnglishTranslations).forEach(([source, target]) => {
        exactTranslations.en[source] = target;
    });

    const extendedEnglishTranslations = {
        "Açtığım İşler": "My Work Items",
        "Durum Dağılımı": "Status Distribution",
        "Güncel": "Current",
        "Hata Raporu": "Issue Report",
        "Müşteri Operasyonları": "Customer Operations",
        "Operasyon Analitiği": "Operations Analytics",
        "Operasyon Yorumu": "Operations Comment",
        "Saha Yorumu": "Field Comment",
        "Toplam İş": "Total Work",
        "Tüm durumlar": "All statuses",
        "VPOS Müşterisi": "VPOS Customer",
        "Yeni İş Aç": "Open New Work",
        "Ürünler": "Products",
        "1. Detay Durumu": "1. Detail Status",
        "2. Operasyon Yorumları": "2. Operations Comments",
        "3. Saha Yorumları": "3. Field Comments",
        "4. Operasyon Yorumu Ekle": "4. Add Operations Comment",
        "4. Saha Yorumu Ekle": "4. Add Field Comment",
        "Admin buradan kullanıcıları yönetebilir; yeni kullanıcı oluştururken VPOS Kullanıcı rolünü de seçebilir.": "Admin can manage users here and can also select the VPOS User role when creating a new user.",
        "Aktif işleri listelemek yerine sistemin genel performansını ve eğilimlerini tek ekranda izleyin.": "Monitor overall system performance and trends on one screen instead of only listing active work.",
        "Aktif İşim": "My Active Work",
        "Anlık": "Real Time",
        "App_Data işyeri/VKN referansı": "App_Data merchant/Tax ID reference",
        "Atamayı Değiştir": "Change Assignment",
        "Atanan Operasyon Kullanıcısı": "Assigned Operations User",
        "Ay kırılımı, entegrasyon sonuçları ve operasyon personeli iş yükü dağılımı.": "Monthly breakdown, integration results, and Operations staff workload distribution.",
        "Aylık Müşteri Trendi": "Monthly Customer Trend",
        "Aylık Özet": "Monthly Summary",
        "Açan": "Opened By",
        "Açan VPOS Kullanıcısı": "Opening VPOS User",
        "Açtığım İş": "Work I Opened",
        "Açtığın entegrasyon işinin güncel durumu ve operasyon notları.": "Current status and Operations notes for the integration work you opened.",
        "Açık + bekleyen kayıt sayısı kapananlardan fazla. Önceliği en sık tekrarlanan hatalara vermek backlog'u daha hızlı düşürür.": "Open and pending records outnumber closed records. Prioritizing the most frequent issues will reduce the backlog faster.",
        "Açık / bekleyen / kapanan hata dengesi": "Balance of open, pending, and closed issues",
        "Açık iş yükü yüksek": "Open workload is high",
        "Açık İş": "Open Work",
        "Açıklama / Entegrasyon Notu": "Description / Integration Note",
        "Açılan işleri durum bazlı yönetin, detayları inceleyin ve yorumlarla süreç takibini tek ekrandan yürütün.": "Manage opened work by status, review details, and track the process with comments from one screen.",
        "Açılış": "Opening",
        "Açılış Tarihi": "Opening Date",
        "Bekleme → aktif çalışma → doküman → satış akışı": "Pending → active work → document → sales flow",
        "Bekleyen İş": "Pending Work",
        "Belirsiz / Çakışan": "Ambiguous / Conflicting",
        "Belirsiz eşleşme yok.": "No ambiguous matches.",
        "Belirsizleri Excel İndir": "Download Ambiguous as Excel",
        "Bir aya tıklayarak o ayın kişi bazlı iş dağılımına geçebilirsiniz.": "Click a month to view the person-based work distribution for that month.",
        "Bir müşteri seçin": "Select a customer",
        "Board üzerindeki toplam iş": "Total work on the board",
        "Bu ekran ortak VPOS entegrasyon iş takibidir. VPOS kullanıcıları kayıtları salt okunur görür; durum ve atama operasyon/admin tarafından yönetilir.": "This is the shared VPOS integration work tracking screen. VPOS users have read-only access; status and assignment are managed by Operations/Admin.",
        "Bu işin durumunu, atanan operasyon kullanıcısını ve operasyon notlarını görüntüleyebilirsin. Değişiklikleri operasyon/admin yapar.": "You can view this work item’s status, assigned Operations user, and Operations notes. Changes are made by Operations/Admin.",
        "Bu müşteri yalnızca": "This customer is only",
        "Detay Ekle": "Add Detail",
        "Detay ›": "Detail ›",
        "Detayı Düzenle": "Edit Detail",
        "Detayını açmak için seçin": "Select to open its details",
        "Durum Değişimi": "Status Change",
        "Durum güncellemesi operasyon ekibi tarafından yapılır.": "Status updates are performed by the Operations team.",
        "Durumu “Entegrasyon Tamamlanmadı” olan kayıtların açıldıkları aya göre dağılımı.": "Distribution of records with the “Integration Not Completed” status by opening month.",
        "Ekleyen: giriş yapan operasyon kullanıcısı otomatik yazılır.": "Added By: the signed-in Operations user is filled automatically.",
        "Ekleyen: giriş yapan saha kullanıcısı otomatik yazılır.": "Added By: the signed-in Field user is filled automatically.",
        "En Yoğun Ay": "Busiest Month",
        "En az 2 kez görülen hata tipi": "Issue type seen at least twice",
        "En az bir ürün seçin. Aynı müşteri PF, VPOS ve Cüzdan ürünlerinden birden fazlasında bulunabilir.": "Select at least one product. The same customer may belong to more than one of PF, VPOS, and Wallet.",
        "En yoğun teknoloji / entegrasyon tipleri": "Most common technology / integration types",
        "Entegrasyon Tamamlanmadı durumundaki işler": "Work items with Integration Not Completed status",
        "Entegrasyon taleplerini aç, süreci takip et ve hata arşivine tek yerden ulaş.": "Open integration requests, track the process, and access the issue archive from one place.",
        "Entegrasyon İş Raporu": "Integration Work Report",
        "Excel Ayı": "Excel Month",
        "Excel Kaydı": "Excel Record",
        "Excel analiz hatası:": "Excel analysis error:",
        "Excel yüklediğinizde eşleşen, eşleşmeyen ve belirsiz müşteriler burada ayrı ayrı gösterilecek.": "After uploading Excel, matched, unmatched, and ambiguous customers will be shown separately here.",
        "Excel'i yükleyin. Sistem": "Upload the Excel file. The system",
        "Eşleşen Bilgileri Kaydet": "Save Matched Information",
        "Eşleşenler": "Matched",
        "Eşleşenleri Excel İndir": "Download Matched as Excel",
        "Eşleşme": "Match",
        "Eşleşmeyen müşteri yok.": "No unmatched customers.",
        "Eşleşmeyenler": "Unmatched",
        "Eşleşmeyenleri Excel İndir": "Download Unmatched as Excel",
        "Filtrelenen kayıtlarda en çok tekrarlanan ilk 7 hata": "Top 7 most frequent issues in the filtered records",
        "Filtrelenen kayıtların kapanma seviyesini takip edin. Aynı dönemleri karşılaştırmak operasyon kalitesindeki değişimi gösterir.": "Track the closure rate of filtered records. Comparing the same periods shows changes in Operations quality.",
        "Filtreleri değiştirerek tekrar deneyebilirsiniz.": "Try again by changing the filters.",
        "Filtreye uygun müşteri kaydı bulunamadı.": "No customer record matches the filter.",
        "Firma / VKN / Müşteri ID": "Company / Tax ID / Customer ID",
        "Firma adı değiştirilmez": "Company name is not changed",
        "Gösterilecek bildirim yok.": "No notifications to display.",
        "Güncel Aktif İş Yükü": "Current Active Workload",
        "Güncel durumda aktif olanlar": "Currently active",
        "Güvenli karşılık bulunamadı": "No safe match found",
        "Hata Aç": "Open Issue",
        "Hata Açıklaması": "Issue Description",
        "Hata Kategorisi": "Issue Category",
        "Hata Kaydı": "Issue Record",
        "Hata Kaydını Sil": "Delete Issue Record",
        "Hata Kayıtları": "Issue Records",
        "Hata Sağlığı": "Issue Health",
        "Hata arşivi detayı": "Issue archive detail",
        "Hata kaydı bulunamadı.": "Issue record not found.",
        "Hataların teknik alanlara göre dağılımı": "Distribution of issues by technical area",
        "Henüz VPOS işi yok.": "No VPOS work yet.",
        "Henüz açtığın VPOS işi yok.": "You have not opened any VPOS work yet.",
        "Henüz bildirimin yok.": "You have no notifications yet.",
        "Henüz bu işe eklenmiş bir not yok.": "No notes have been added to this work item yet.",
        "Henüz detay kaydı yok. İlk operasyon notunu yukarıdan ekleyebilirsiniz.": "No detail record yet. You can add the first Operations note above.",
        "Henüz hata kaydı yok.": "No issue records yet.",
        "Henüz operasyon cevabı yok.": "No Operations response yet.",
        "Henüz operasyon yorumu yok.": "No Operations comments yet.",
        "Henüz saha yorumu yok.": "No Field comments yet.",
        "Her ay operasyona açılan Jira işlerinin sayısı. Oluşturma tarihine göre 12 aylık kırılım.": "Number of Jira work items opened for Operations each month, shown as a 12-month breakdown by creation date.",
        "Hızlı Bakış": "Quick View",
        "Kalıcı çözüm adayı": "Permanent solution candidate",
        "Kapanma Oranı": "Closure Rate",
        "Kategori Yoğunluğu": "Category Distribution",
        "Kategori seçin": "Select category",
        "Kaydı Aç": "Open Record",
        "Kayıt Ekleyen *": "Record Creator *",
        "Kayıt Tipi": "Record Type",
        "Kayıt kaydedildiğinde aktif operasyon ekibinde": "When the record is saved, among the active Operations team",
        "Kayıt tarihi en yeni → en eski sıralıdır.": "Records are ordered by date from newest to oldest.",
        "Kesin veya güvenli yakın eşleşme bulunamadı.": "No exact or safe close match was found.",
        "Kişi Bazlı İş Dağılımı": "Work Distribution by Person",
        "Kolonların A-B-C sırasında olması gerekmez. Sistem başlıklardan otomatik bulur. Desteklenen örnekler:": "Columns do not need to be in A-B-C order. The system detects them automatically from the headers. Supported examples:",
        "Mevcut VKN / Excel / referans / güçlü benzerlik": "Existing Tax ID / Excel / reference / strong similarity",
        "Mevcut filtre sonucuna göre otomatik operasyon aksiyonları": "Automatic Operations actions based on the current filter result",
        "Mevcut müşteri bilgilerini güncelleyin.": "Update existing customer information.",
        "Mevcut müşteri tablosu": "Existing customer table",
        "Müşteri Durumları": "Customer Statuses",
        "Müşteri Geçmişi": "Customer History",
        "Müşteri Listesi": "Customer List",
        "Müşteri bilgileri, görüşme geçmişi ve operasyon notlarını tek ekranda yönetin.": "Manage customer information, conversation history, and Operations notes from one screen.",
        "Müşteri dağılımı": "Customer Distribution",
        "Müşteri kartındaki bilgileri güncelleyin.": "Update the information on the customer card.",
        "Müşteri kartını oluşturun.": "Create the customer card.",
        "Müşteri kaydedilince entegrasyon işi otomatik açılır ve operasyon ekibinde iş yoğunluğu en düşük kişiye atanır.": "When the customer is saved, an integration work item is opened automatically and assigned to the Operations user with the lowest workload.",
        "Müşteri portföyünü, süreç durumlarını ve kayıt hareketini tek ekrandan yönetin.": "Manage the customer portfolio, process statuses, and record activity from one screen.",
        "Müşteri seçin": "Select customer",
        "Müşteri yoğunluğu": "Customer Concentration",
        "Müşterilere Dön": "Back to Customers",
        "Müşteriyi Kaydet ve İşi Aç": "Save Customer and Open Work",
        "Normal Entegrasyon İşi": "Standard Integration Work",
        "Normal iş entegrasyon sürecine, hata kaydı hata arşivine gider. Atama otomatik yapılır.": "Standard work goes to the integration process; issue records go to the issue archive. Assignment is automatic.",
        "Okunmamış": "Unread",
        "Operasyon (Operasyon Personeli)": "Operations (Operations Staff)",
        "Operasyon Akışı": "Operations Flow",
        "Operasyon Cevabı": "Operations Response",
        "Operasyon Kalitesi": "Operations Quality",
        "Operasyon Tamamlama Skoru": "Operations Completion Score",
        "Operasyon yorumları salt okunur. Bu ekrandan yalnızca saha yorumu ekleyebilirsin.": "Operations comments are read-only. You can only add a Field comment from this screen.",
        "Operasyon Üzerindeki İşler — Ay Ay": "Workload on Operations — Month by Month",
        "Operasyona Açılan İş": "Work Opened for Operations",
        "Otomatik entegrasyon akışı": "Automatic Integration Flow",
        "Portföyün ana süreç durumları": "Main process statuses of the portfolio",
        "Sadece VPOS ürünüyle eşleştirilmiş müşteriler gösterilir.": "Only customers associated with the VPOS product are shown.",
        "Saha Index": "Field Index",
        "Saha erişimi:": "Field access:",
        "Saha kullanıcısı kendisine atanan işleri ve kendi açtığı işleri görür. Eşleşme Takip Eden veya Talep Açan alanına göre yapılır.": "A Field user sees work assigned to them and work they opened. Matching is based on Assigned To or Requested By.",
        "Seçilen ay hata kapanma görünümü": "Issue closure view for the selected month",
        "Seçilen dönemde operasyon akışı": "Operations flow for the selected period",
        "Seçili ayda açılan müşterilerin dağılımı": "Distribution of customers opened in the selected month",
        "Seçili dönem için iş bulunamadı.": "No work was found for the selected period.",
        "Seçili filtre kapsamı": "Selected Filter Scope",
        "Seçili filtrede 3 veya daha fazla tekrarlayan tek bir hata görünmüyor. Dağılım şu an dengeli.": "No single issue repeats three or more times in the selected filter. The distribution is currently balanced.",
        "Sistemde kayıtlı toplam müşteri": "Total customers registered in the system",
        "Skora Giren İş": "Work Included in Score",
        "Sol listeden müşteriyi seçtiğinizde iletişim bilgileri ve tüm görüşme geçmişi burada açılır.": "When you select a customer from the left list, contact information and full conversation history open here.",
        "Son 6 ay sisteme eklenen müşteri sayısı": "Number of customers added to the system in the last 6 months",
        "Son 6 ay yeni müşteri hareketi": "New customer activity over the last 6 months",
        "Son Açtığım İşler": "My Recently Opened Work",
        "Sonuçlandırılmış kayıt": "Resolved record",
        "Sık Gelen Hatalar": "Frequent Issues",
        "Takip ekranına gitmeden yoğunluğu görün": "View workload without opening the tracking screen",
        "Takip gerektiren kayıt": "Record requiring follow-up",
        "Tamamlanan İş": "Completed Work",
        "Tek bir müşteride belirgin hata yığılması oluşmamış. Müşteri bazlı risk seviyesi normal görünüyor.": "No significant issue concentration exists for a single customer. Customer-level risk appears normal.",
        "Teknoloji Dağılımı": "Technology Distribution",
        "Tekrarlayan Hata": "Recurring Issue",
        "Tekrarlayan sorunları, açık iş yükünü ve müşteri bazlı hata yoğunluğunu tek ekrandan takip edin.": "Track recurring issues, open workload, and customer-level issue concentration from one screen.",
        "Toplam Açtığım İş": "Total Work I Opened",
        "Toplam Detay": "Total Details",
        "Toplam operasyona açılan işe göre": "Based on total work opened for Operations",
        "Tüm Ayları Excel'e İndir": "Download All Months to Excel",
        "Tüm Bildirimleri Gör": "View All Notifications",
        "Tüm Saha Ekibi": "Entire Field Team",
        "Tüm hata kayıtlarını ekip arşivi gibi görüntüleyebilirsin.": "You can view all issue records as a shared team archive.",
        "Tüm kategoriler": "All categories",
        "Tüm Ürünler": "All Products",
        "Tümünü Okundu Yap": "Mark All as Read",
        "Tümünü okundu yap": "Mark all as read",
        "VKN Eşleştirme Merkezi": "Tax ID Matching Center",
        "VKN boş olsa da okunan yükleme satırı": "Uploaded row read even if Tax ID is empty",
        "VPOS Ana Sayfa / İş Takip": "VPOS Home / Work Tracking",
        "VPOS MÜŞTERİ KAYDI": "VPOS CUSTOMER RECORD",
        "VPOS erişimi:": "VPOS access:",
        "VPOS görünümü:": "VPOS view:",
        "VPOS müşterisi": "VPOS customer",
        "VPOS müşterisi bulunamadı.": "VPOS customer not found.",
        "VPOS müşterisi tanımlı değil. Önce müşteriyi VPOS ürünüyle eşleştirin.": "No VPOS customer is defined. Associate the customer with the VPOS product first.",
        "Yalnızca senin açtığın VPOS entegrasyon işleri.": "Only VPOS integration work items opened by you.",
        "Yapılacak": "To Do",
        "Yeni Atanan": "Newly Assigned",
        "Yeni İş": "New Work",
        "Yeni İş / Hata": "New Work / Issue",
        "Yeni İş / Hata Aç": "Open New Work / Issue",
        "Zaten Güncel": "Already Up to Date",
        "Çakışma veya birden fazla aday": "Conflict or multiple candidates",
        "Ürün Tipi": "Product Type",
        "İade / İptal": "Refund / Cancellation",
        "İçgörü ve Öneriler": "Insights and Recommendations",
        "İş / Görüşme": "Work / Conversation",
        "İş / Görüşme Geçmişi": "Work / Conversation History",
        "İş Durumu Dağılımı": "Work Status Distribution",
        "İş Notları / Operasyon Yorumları": "Work Notes / Operations Comments",
        "İş Raporu": "Work Report",
        "İş Takip Tipi": "Work Tracking Type",
        "İşyeri Excel Dosyası": "Merchant Excel File",
        "Şu anda Aktif durumda iş bulunmuyor.": "There is currently no work in Active status.",
        "← Arşive Dön": "← Back to Archive",
        "← Açtığım İşler": "← My Work Items",
        "← VPOS Müşterileri": "← VPOS Customers",
        "↻  Durumu Güncelle": "↻  Update Status",
        "▢  Operasyon Yorumu Ekle": "▢  Add Operations Comment",
        "▢  Saha Yorumu Ekle": "▢  Add Field Comment"
};

    Object.entries(extendedEnglishTranslations).forEach(([source, target]) => {
        exactTranslations.en[source] = target;
    });

    patternTranslations.en.push(
        { regex: /^Sayfa\s+(\d+)\s*\/\s*(\d+)\s*·\s*Toplam\s+(\d+)\s+kayıt$/, replace: (_, page, pages, total) => `Page ${page}/${pages} · Total ${total} records` },
        { regex: /^Bu filtrede\s+(\d+)\s+kez görüldü$/, replace: (_, count) => `Seen ${count} times in this filter` },
        { regex: /^En sık:\s*(\d+)\s+kez$/, replace: (_, count) => `Most frequent: ${count} times` },
        { regex: /^Kapanma oranı %([\d.,]+)$/, replace: (_, rate) => `Closure rate ${rate}%` },
        { regex: /^Operasyon Yorumu:\s*(\d+)$/, replace: (_, count) => `Operations Comments: ${count}` },
        { regex: /^Saha Yorumu:\s*(\d+)$/, replace: (_, count) => `Field Comments: ${count}` },
        { regex: /^Şu anda “Aktif” durumdaki\s+(\d+)\s+işin kişiler üzerindeki gerçek zamanlı dağılımı\.$/, replace: (_, count) => `Real-time distribution of ${count} work items currently in Active status across users.` },
        { regex: /^(.+) hatası\s+(\d+)\s+kez görülmüş\. Kök neden analizi, standart çözüm adımı ve bilgi bankası kaydı oluşturmak mantıklı\.$/, replace: (_, issue, count) => `${issue} has occurred ${count} times. Consider root-cause analysis, a standard resolution procedure, and a knowledge-base entry.` },
        { regex: /^(.+) üzerinde\s+(\d+)\s+hata var\. Entegrasyon konfigürasyonu ve müşteri özelindeki ortak bağımlılıklar incelenebilir\.$/, replace: (_, customer, count) => `${customer} has ${count} issues. Review integration configuration and customer-specific shared dependencies.` },
        { regex: /^Mevcut:\s*(.+)$/, replace: (_, value) => `Current: ${value === 'Atanmamış' ? 'Unassigned' : value}` },
        { regex: /^Müşteri #(\d+)$/, replace: (_, id) => `Customer #${id}` },
        { regex: /^Kullanıcı #(\d+)$/, replace: (_, id) => `User #${id}` }
    );

    function normalizeLanguage(language) {
        return supportedLanguages.has(language) ? language : defaultLanguage;
    }

    function getLanguage() {
        return normalizeLanguage(localStorage.getItem(storageKey) || defaultLanguage);
    }

    function setLanguage(language) {
        localStorage.setItem(storageKey, normalizeLanguage(language));
    }

    function translateValue(value, language) {
        if (!value) {
            return value;
        }

        const exact = exactTranslations[language] || {};
        const patterns = patternTranslations[language] || [];
        const collapsed = value.replace(/\s+/g, ' ').trim();

        if (!collapsed) {
            return value;
        }

        if (Object.prototype.hasOwnProperty.call(exact, collapsed)) {
            const leading = value.match(/^\s*/)?.[0] ?? '';
            const trailing = value.match(/\s*$/)?.[0] ?? '';
            return `${leading}${exact[collapsed]}${trailing}`;
        }

        for (const rule of patterns) {
            if (rule.regex.test(collapsed)) {
                const leading = value.match(/^\s*/)?.[0] ?? '';
                const trailing = value.match(/\s*$/)?.[0] ?? '';
                return `${leading}${collapsed.replace(rule.regex, rule.replace)}${trailing}`;
            }
        }

        return value;
    }

    function processTextNode(node, language) {
        if (!node || !node.parentElement || skipTags.has(node.parentElement.tagName)) {
            return;
        }

        const currentValue = node.nodeValue;
        if (!currentValue || !currentValue.trim()) {
            return;
        }

        if (node.parentElement.closest('[data-no-translate]')) {
            return;
        }

        let original = node.__i18nOriginalText || currentValue;
        if (node.__i18nOriginalText) {
            const previousTranslatedValue = translateValue(node.__i18nOriginalText, language);
            if (currentValue !== node.__i18nOriginalText && currentValue !== previousTranslatedValue) {
                original = currentValue;
            }
        }

        node.__i18nOriginalText = original;
        const translatedValue = translateValue(original, language);
        if (node.nodeValue !== translatedValue) {
            node.nodeValue = translatedValue;
        }
    }

    function processAttribute(element, attributeName, storageName, language) {
        if (!element.hasAttribute(attributeName)) {
            return;
        }

        const currentValue = element.getAttribute(attributeName);
        let original = element.dataset[storageName] || currentValue;
        if (element.dataset[storageName]) {
            const previousTranslatedValue = translateValue(element.dataset[storageName], language);
            if (currentValue !== element.dataset[storageName] && currentValue !== previousTranslatedValue) {
                original = currentValue;
            }
        }

        element.dataset[storageName] = original;
        const translatedValue = translateValue(original, language);
        if (element.getAttribute(attributeName) !== translatedValue) {
            element.setAttribute(attributeName, translatedValue);
        }
    }

    function processElement(element, language) {
        if (!element || element.hasAttribute('data-no-translate')) {
            return;
        }

        processAttribute(element, 'placeholder', 'i18nPlaceholderOriginal', language);
        processAttribute(element, 'title', 'i18nTitleOriginal', language);
        processAttribute(element, 'aria-label', 'i18nAriaLabelOriginal', language);
        processAttribute(element, 'alt', 'i18nAltOriginal', language);
        processAttribute(element, 'data-bs-title', 'i18nBsTitleOriginal', language);
        processAttribute(element, 'data-bs-original-title', 'i18nBsOriginalTitleOriginal', language);

        const explicitKey = element.getAttribute('data-i18n');
        if (explicitKey && !explicitKey.includes('@(') && !explicitKey.includes('@{') && element.children.length === 0) {
            const translatedText = translateValue(explicitKey, language);
            if (element.textContent !== translatedText) {
                element.textContent = translatedText;
            }
        }

        if (element instanceof HTMLInputElement) {
            const type = (element.type || '').toLowerCase();
            if (['button', 'submit', 'reset'].includes(type)) {
                const originalValue = element.dataset.i18nValueOriginal || element.value;
                element.dataset.i18nValueOriginal = originalValue;
                const translatedValue = translateValue(originalValue, language);
                if (element.value !== translatedValue) {
                    element.value = translatedValue;
                }
            }
        }
    }

    function translateRoot(root, language) {
        if (!root) {
            return;
        }

        if (root.nodeType === Node.TEXT_NODE) {
            processTextNode(root, language);
            return;
        }

        if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) {
            return;
        }

        if (root.nodeType === Node.ELEMENT_NODE) {
            processElement(root, language);
        }

        const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, null);
        let current = walker.currentNode;
        while (current) {
            if (current.nodeType === Node.TEXT_NODE) {
                processTextNode(current, language);
            } else if (current.nodeType === Node.ELEMENT_NODE) {
                processElement(current, language);
            }
            current = walker.nextNode();
        }
    }

    function translateDocumentTitle(language) {
        if (!document.title) {
            return;
        }

        const originalTitle = document.documentElement.dataset.i18nTitleOriginal || document.title;
        document.documentElement.dataset.i18nTitleOriginal = originalTitle;
        document.title = translateValue(originalTitle, language);
    }

    function updateSwitcherState(language) {
        document.querySelectorAll('[data-language-switch][data-language-value]').forEach(button => {
            const selected = button.getAttribute('data-language-value') === language;
            button.classList.toggle('active', selected);
            button.setAttribute('aria-pressed', selected ? 'true' : 'false');
        });
    }

    function updateServerLanguageTargets(language) {
        if (!document.body) {
            return;
        }

        document.querySelectorAll('a[href]').forEach(link => {
            const rawHref = link.getAttribute('href') || '';
            if (!rawHref || rawHref.startsWith('#') || rawHref.startsWith('javascript:') || rawHref.startsWith('mailto:') || rawHref.startsWith('tel:')) {
                return;
            }

            if (!/(Export|Download)/i.test(rawHref)) {
                return;
            }

            try {
                const url = new URL(rawHref, window.location.origin);
                if (url.origin !== window.location.origin) {
                    return;
                }

                url.searchParams.set('lang', language);
                link.setAttribute('href', url.pathname + url.search + url.hash);
            } catch (_) {
                
            }
        });

        document.querySelectorAll('form').forEach(form => {
            const method = (form.getAttribute('method') || 'get').toLowerCase();
            if (method !== 'get') {
                return;
            }

            let input = form.querySelector('input[name="lang"]');
            if (!input) {
                input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'lang';
                form.appendChild(input);
            }

            input.value = language;
        });
    }

    function applyLanguage(language) {
        const normalized = normalizeLanguage(language);
        setLanguage(normalized);
        document.documentElement.lang = normalized === 'en' ? 'en' : 'tr';
        document.body?.setAttribute('data-ui-language', normalized);
        window.__uiLocalizationApplying = true;

        try {
            translateDocumentTitle(normalized);
            translateRoot(document.body, normalized);
            updateSwitcherState(normalized);
            updateServerLanguageTargets(normalized);
            document.dispatchEvent(new CustomEvent('ui-language-changed', { detail: { language: normalized } }));
        } finally {
            window.__uiLocalizationApplying = false;
        }
    }

    function initializeSwitcher() {
        if (window.__uiLocalizationSwitcherInitialized) {
            return;
        }

        window.__uiLocalizationSwitcherInitialized = true;

        document.addEventListener('click', function (event) {
            const button = event.target instanceof Element
                ? event.target.closest('[data-language-switch][data-language-value]')
                : null;

            if (!button) {
                return;
            }

            const language = button.getAttribute('data-language-value');
            applyLanguage(language);
        });
    }

    function initializeObserver() {
        if (!document.body || window.__uiLocalizationObserverInitialized) {
            return;
        }

        window.__uiLocalizationObserverInitialized = true;
        const observer = new MutationObserver(mutations => {
            if (window.__uiLocalizationApplying) {
                return;
            }

            const language = getLanguage();
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => translateRoot(node, language));
                if (mutation.type === 'characterData') {
                    processTextNode(mutation.target, language);
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
            characterData: true
        });
    }

    function patchBrowserDialogs() {
        if (window.__uiLocalizationDialogsPatched) {
            return;
        }

        window.__uiLocalizationDialogsPatched = true;

        const originalAlert = window.alert.bind(window);
        const originalConfirm = window.confirm.bind(window);
        const originalPrompt = window.prompt.bind(window);

        window.alert = function (message) {
            originalAlert(typeof message === 'string' ? translateValue(message, getLanguage()) : message);
        };

        window.confirm = function (message) {
            return originalConfirm(typeof message === 'string' ? translateValue(message, getLanguage()) : message);
        };

        window.prompt = function (message, defaultValue) {
            return originalPrompt(typeof message === 'string' ? translateValue(message, getLanguage()) : message, defaultValue);
        };
    }

    function bootLocalization() {
        patchBrowserDialogs();
        initializeSwitcher();
        applyLanguage(getLanguage());
        initializeObserver();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootLocalization);
    } else {
        bootLocalization();
    }

    window.UiLocalization = {
        applyLanguage,
        getLanguage,
        translate: value => translateValue(value, getLanguage())
    };
})();
