/*
  Müşteriler tablosuna opsiyonel VKN ve harici Müşteri ID alanlarını ekler.
  EF migration oluşturmaz/değiştirmez. Script tekrar çalıştırılabilir.
*/

IF COL_LENGTH('dbo.Musteriler', 'VKN') IS NULL
BEGIN
    ALTER TABLE dbo.Musteriler ADD VKN nvarchar(10) NULL;
END;
GO

IF COL_LENGTH('dbo.Musteriler', 'HariciMusteriID') IS NULL
BEGIN
    ALTER TABLE dbo.Musteriler ADD HariciMusteriID nvarchar(100) NULL;
END;
GO
