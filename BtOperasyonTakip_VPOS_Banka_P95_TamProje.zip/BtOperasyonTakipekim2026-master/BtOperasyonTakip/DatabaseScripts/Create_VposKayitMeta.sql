IF OBJECT_ID(N'[dbo].[VposKayitMeta]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[VposKayitMeta]
    (
        [Id] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_VposKayitMeta] PRIMARY KEY,
        [KayitTipi] NVARCHAR(10) NOT NULL,
        [KayitId] INT NOT NULL,
        [AcanUserId] INT NULL,
        [AcanKullanici] NVARCHAR(150) NOT NULL,
        [AtananUserId] INT NULL,
        [AtananKullanici] NVARCHAR(150) NULL,
        [OlusturmaTarihi] DATETIME2 NOT NULL CONSTRAINT [DF_VposKayitMeta_OlusturmaTarihi] DEFAULT (SYSDATETIME())
    );

    CREATE UNIQUE INDEX [UX_VposKayitMeta_Tip_Kayit]
        ON [dbo].[VposKayitMeta] ([KayitTipi], [KayitId]);
END;
