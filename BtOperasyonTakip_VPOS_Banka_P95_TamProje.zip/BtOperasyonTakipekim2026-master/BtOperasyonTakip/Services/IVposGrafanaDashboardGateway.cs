using BtOperasyonTakip.Dtos;

namespace BtOperasyonTakip.Services;

public interface IVposGrafanaDashboardGateway
{
    Task<VposGrafanaConnectionInfo> TestAsync(VposMonitoringCredential credential, CancellationToken cancellationToken = default);
    Task<VposMonitoringResult> QueryAsync(VposMonitoringCredential credential, VposMonitoringFilter filter, string purpose, CancellationToken cancellationToken = default);
}
