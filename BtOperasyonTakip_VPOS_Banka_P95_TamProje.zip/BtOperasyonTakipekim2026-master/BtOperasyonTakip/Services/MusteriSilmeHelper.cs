using BtOperasyonTakip.Data;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace BtOperasyonTakip.Services;

public static class MusteriSilmeHelper
{
    public static async Task<(bool Success, string Message)> TamamenSilAsync(
        AppDbContext context,
        int musteriId)
    {
        if (musteriId <= 0)
            return (false, "Geçersiz müşteri ID.");

        var musteri = await context.Musteriler
            .Include(x => x.Detaylar)
            .Include(x => x.DurumGecmisi)
            .FirstOrDefaultAsync(x => x.MusteriID == musteriId);

        if (musteri == null)
            return (false, "Müşteri bulunamadı.");

        await using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            // Geçmiş iş/ticket/hata kayıtlarını silmiyoruz; yalnızca müşteri bağını kaldırıyoruz.
            // Böylece operasyon geçmişi korunurken müşteri ana kaydı tamamen silinebiliyor.
            var ticketlar = await context.Tickets
                .Where(x => x.MusteriID == musteriId)
                .ToListAsync();
            foreach (var item in ticketlar)
                item.MusteriID = null;

            var jiraKayitlari = await context.JiraTasks
                .Where(x => x.MusteriID == musteriId)
                .ToListAsync();
            foreach (var item in jiraKayitlari)
                item.MusteriID = null;

            var hatalar = await context.Hatalar
                .Where(x => x.MusteriID == musteriId)
                .ToListAsync();
            foreach (var item in hatalar)
                item.MusteriID = null;

            var excelKayitlari = await context.ExcelAktarimKayitlari
                .Where(x => x.EslesenMusteriID == musteriId)
                .ToListAsync();
            foreach (var item in excelKayitlari)
                item.EslesenMusteriID = null;

            if (musteri.DurumGecmisi != null && musteri.DurumGecmisi.Count > 0)
                context.MusteriDurumGecmisleri.RemoveRange(musteri.DurumGecmisi);

            if (musteri.Detaylar != null && musteri.Detaylar.Count > 0)
                context.Detaylar.RemoveRange(musteri.Detaylar);

            var idText = musteriId.ToString(CultureInfo.InvariantCulture);
            var prefix = idText + "|";

            // PF / VPOS / Cüzdan ürün eşleşmeleri + VKN/Harici ID gibi müşteri ek alanları.
            var parametreler = await context.Parametreler
                .Where(x => x.Tur != null && x.ParAdi != null)
                .Where(x =>
                    (x.Tur!.StartsWith("UrunMusteri:") && x.ParAdi == idText) ||
                    (x.Tur.StartsWith("MusteriEk:") && x.ParAdi!.StartsWith(prefix)))
                .ToListAsync();

            if (parametreler.Count > 0)
                context.Parametreler.RemoveRange(parametreler);

            context.Musteriler.Remove(musteri);
            await context.SaveChangesAsync();
            await transaction.CommitAsync();

            return (true, "Müşteri tüm ürün listelerinden tamamen silindi. Bağlı operasyon geçmişi korunarak müşteri bağlantıları kaldırıldı.");
        }
        catch (DbUpdateException)
        {
            await transaction.RollbackAsync();
            return (false, "Müşteri silinemedi. Veritabanında bu müşteriye bağlı başka bir kayıt bulunuyor olabilir.");
        }
        catch
        {
            await transaction.RollbackAsync();
            return (false, "Müşteri silinirken beklenmeyen bir hata oluştu.");
        }
    }
}
