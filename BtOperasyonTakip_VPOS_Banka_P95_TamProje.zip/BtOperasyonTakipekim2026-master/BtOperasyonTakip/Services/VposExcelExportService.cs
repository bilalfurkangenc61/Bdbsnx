using System.Globalization;
using BtOperasyonTakip.Dtos;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace BtOperasyonTakip.Services;

public static class VposExcelExportService
{
    public static byte[] BuildErrors(IEnumerable<VposMonitoringRow> source)
    {
        var rows = source.ToList();
        using var stream = new MemoryStream();
        using (var document = SpreadsheetDocument.Create(stream, SpreadsheetDocumentType.Workbook, true))
        {
            var workbookPart = document.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();
            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var sheetData = new SheetData();
            worksheetPart.Worksheet = new Worksheet(sheetData);

            var sheets = workbookPart.Workbook.AppendChild(new Sheets());
            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = "VPOS Hatalar"
            });

            Append(sheetData,
                "Tarih", "Müşteri", "Kaynak", "Hata Kodu", "ISO8583", "Kaynak Açıklaması",
                "Genel Açıklama", "Bağlam", "İşlem No", "Tutar", "Durum", "Log Mesajı", "Adet", "Panel");

            foreach (var x in rows)
            {
                Append(sheetData,
                    x.Timestamp?.ToString("dd.MM.yyyy HH:mm:ss", CultureInfo.GetCultureInfo("tr-TR")) ?? "",
                    x.Customer,
                    x.Source,
                    x.RawCode,
                    x.NormalizedCode,
                    x.Description,
                    x.GeneralDescription,
                    x.Context,
                    x.TransactionId,
                    x.Amount,
                    x.Status,
                    x.Message,
                    x.Count.ToString(CultureInfo.InvariantCulture),
                    x.PanelTitle);
            }

            workbookPart.Workbook.Save();
        }
        return stream.ToArray();
    }

    private static void Append(SheetData sheetData, params string[] values)
    {
        var row = new Row();
        foreach (var value in values)
        {
            row.Append(new Cell
            {
                DataType = CellValues.InlineString,
                InlineString = new InlineString(new Text(value ?? string.Empty))
            });
        }
        sheetData.Append(row);
    }
}
