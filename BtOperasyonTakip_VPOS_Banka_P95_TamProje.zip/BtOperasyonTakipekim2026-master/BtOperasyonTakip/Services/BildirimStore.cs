﻿using System.Data;
using System.Data.Common;
using BtOperasyonTakip.Data;
using Microsoft.EntityFrameworkCore;

namespace BtOperasyonTakip.Services;



public sealed class BildirimStore
{
    private readonly AppDbContext _context;
    private const string TableName = "[dbo].[AppBildirimler]";

    public BildirimStore(AppDbContext context)
    {
        _context = context;
    }

    public void EnsureCreated()
    {
        ExecuteNonQuery(@"
IF OBJECT_ID(N'[dbo].[AppBildirimler]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[AppBildirimler]
    (
        [Id] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_AppBildirimler] PRIMARY KEY,
        [UserId] INT NOT NULL,
        [Baslik] NVARCHAR(180) NOT NULL,
        [Mesaj] NVARCHAR(700) NOT NULL,
        [Tur] NVARCHAR(50) NOT NULL,
        [Onem] NVARCHAR(20) NOT NULL,
        [IlgiliVarlikTuru] NVARCHAR(50) NULL,
        [IlgiliVarlikId] INT NULL,
        [IslemiYapanUserId] INT NULL,
        [IslemiYapan] NVARCHAR(120) NULL,
        [OkunduMu] BIT NOT NULL CONSTRAINT [DF_AppBildirimler_OkunduMu] DEFAULT(0),
        [OlusturmaTarihi] DATETIME2 NOT NULL CONSTRAINT [DF_AppBildirimler_OlusturmaTarihi] DEFAULT(SYSDATETIME())
    );

    CREATE INDEX [IX_AppBildirimler_User_Okunmamis_Tarih]
        ON [dbo].[AppBildirimler] ([UserId], [OkunduMu], [OlusturmaTarihi] DESC);
END;
");
    }

    public void Ekle(BildirimYeniKayit kayit)
    {
        EnsureCreated();

        ExecuteNonQuery($@"
INSERT INTO {TableName}
    ([UserId], [Baslik], [Mesaj], [Tur], [Onem], [IlgiliVarlikTuru], [IlgiliVarlikId],
     [IslemiYapanUserId], [IslemiYapan], [OkunduMu], [OlusturmaTarihi])
VALUES
    (@UserId, @Baslik, @Mesaj, @Tur, @Onem, @IlgiliVarlikTuru, @IlgiliVarlikId,
     @IslemiYapanUserId, @IslemiYapan, 0, @OlusturmaTarihi);",
            ("@UserId", kayit.UserId),
            ("@Baslik", Limit(kayit.Baslik, 180)),
            ("@Mesaj", Limit(kayit.Mesaj, 700)),
            ("@Tur", Limit(kayit.Tur, 50)),
            ("@Onem", Limit(kayit.Onem, 20)),
            ("@IlgiliVarlikTuru", DbValue(LimitNullable(kayit.IlgiliVarlikTuru, 50))),
            ("@IlgiliVarlikId", DbValue(kayit.IlgiliVarlikId)),
            ("@IslemiYapanUserId", DbValue(kayit.IslemiYapanUserId)),
            ("@IslemiYapan", DbValue(LimitNullable(kayit.IslemiYapan, 120))),
            ("@OlusturmaTarihi", kayit.OlusturmaTarihi));
    }

    public IReadOnlyList<BildirimKaydi> Listele(int userId, bool sadeceOkunmamis, int limit)
    {
        EnsureCreated();
        limit = Math.Clamp(limit, 1, 500);

        var sql = $@"
SELECT TOP ({limit})
    [Id], [UserId], [Baslik], [Mesaj], [Tur], [Onem], [IlgiliVarlikTuru], [IlgiliVarlikId],
    [IslemiYapanUserId], [IslemiYapan], [OkunduMu], [OlusturmaTarihi]
FROM {TableName}
WHERE [UserId] = @UserId
  {(sadeceOkunmamis ? "AND [OkunduMu] = 0" : string.Empty)}
ORDER BY [OlusturmaTarihi] DESC, [Id] DESC;";

        return Query(sql, ("@UserId", userId));
    }

    public int OkunmamisSayisi(int userId)
    {
        EnsureCreated();
        return Convert.ToInt32(ExecuteScalar($@"
SELECT COUNT(1)
FROM {TableName}
WHERE [UserId] = @UserId AND [OkunduMu] = 0;", ("@UserId", userId)) ?? 0);
    }

    public BildirimKaydi? Getir(int id, int userId)
    {
        EnsureCreated();
        return Query($@"
SELECT TOP (1)
    [Id], [UserId], [Baslik], [Mesaj], [Tur], [Onem], [IlgiliVarlikTuru], [IlgiliVarlikId],
    [IslemiYapanUserId], [IslemiYapan], [OkunduMu], [OlusturmaTarihi]
FROM {TableName}
WHERE [Id] = @Id AND [UserId] = @UserId;",
            ("@Id", id), ("@UserId", userId)).FirstOrDefault();
    }

    public void OkunduYap(int id, int userId)
    {
        EnsureCreated();
        ExecuteNonQuery($@"
UPDATE {TableName}
SET [OkunduMu] = 1
WHERE [Id] = @Id AND [UserId] = @UserId AND [OkunduMu] = 0;",
            ("@Id", id), ("@UserId", userId));
    }

    public void TumunuOkunduYap(int userId)
    {
        EnsureCreated();
        ExecuteNonQuery($@"
UPDATE {TableName}
SET [OkunduMu] = 1
WHERE [UserId] = @UserId AND [OkunduMu] = 0;", ("@UserId", userId));
    }

    private IReadOnlyList<BildirimKaydi> Query(string sql, params (string Name, object? Value)[] parameters)
    {
        var connection = _context.Database.GetDbConnection();
        var closeAfter = connection.State != ConnectionState.Open;

        try
        {
            if (closeAfter)
                connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText = sql;
            AddParameters(command, parameters);

            using var reader = command.ExecuteReader();
            var result = new List<BildirimKaydi>();
            while (reader.Read())
            {
                result.Add(new BildirimKaydi
                {
                    Id = reader.GetInt32(0),
                    UserId = reader.GetInt32(1),
                    Baslik = reader.GetString(2),
                    Mesaj = reader.GetString(3),
                    Tur = reader.GetString(4),
                    Onem = reader.GetString(5),
                    IlgiliVarlikTuru = reader.IsDBNull(6) ? null : reader.GetString(6),
                    IlgiliVarlikId = reader.IsDBNull(7) ? null : reader.GetInt32(7),
                    IslemiYapanUserId = reader.IsDBNull(8) ? null : reader.GetInt32(8),
                    IslemiYapan = reader.IsDBNull(9) ? null : reader.GetString(9),
                    OkunduMu = reader.GetBoolean(10),
                    OlusturmaTarihi = reader.GetDateTime(11)
                });
            }

            return result;
        }
        finally
        {
            if (closeAfter && connection.State == ConnectionState.Open)
                connection.Close();
        }
    }

    private void ExecuteNonQuery(string sql, params (string Name, object? Value)[] parameters)
    {
        var connection = _context.Database.GetDbConnection();
        var closeAfter = connection.State != ConnectionState.Open;

        try
        {
            if (closeAfter)
                connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText = sql;
            AddParameters(command, parameters);
            command.ExecuteNonQuery();
        }
        finally
        {
            if (closeAfter && connection.State == ConnectionState.Open)
                connection.Close();
        }
    }

    private object? ExecuteScalar(string sql, params (string Name, object? Value)[] parameters)
    {
        var connection = _context.Database.GetDbConnection();
        var closeAfter = connection.State != ConnectionState.Open;

        try
        {
            if (closeAfter)
                connection.Open();

            using var command = connection.CreateCommand();
            command.CommandText = sql;
            AddParameters(command, parameters);
            return command.ExecuteScalar();
        }
        finally
        {
            if (closeAfter && connection.State == ConnectionState.Open)
                connection.Close();
        }
    }

    private static void AddParameters(DbCommand command, IEnumerable<(string Name, object? Value)> parameters)
    {
        foreach (var (name, value) in parameters)
        {
            var parameter = command.CreateParameter();
            parameter.ParameterName = name;
            parameter.Value = value ?? DBNull.Value;
            command.Parameters.Add(parameter);
        }
    }

    private static object DbValue(object? value) => value ?? DBNull.Value;
    private static string Limit(string? value, int max)
    {
        var s = (value ?? string.Empty).Trim();
        return s.Length > max ? s[..max] : s;
    }
    private static string? LimitNullable(string? value, int max)
    {
        var s = (value ?? string.Empty).Trim();
        if (s.Length == 0) return null;
        return s.Length > max ? s[..max] : s;
    }
}

public sealed class BildirimKaydi
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string Baslik { get; set; } = string.Empty;
    public string Mesaj { get; set; } = string.Empty;
    public string Tur { get; set; } = "Genel";
    public string Onem { get; set; } = "Normal";
    public string? IlgiliVarlikTuru { get; set; }
    public int? IlgiliVarlikId { get; set; }
    public int? IslemiYapanUserId { get; set; }
    public string? IslemiYapan { get; set; }
    public bool OkunduMu { get; set; }
    public DateTime OlusturmaTarihi { get; set; }
}

public sealed class BildirimYeniKayit
{
    public int UserId { get; set; }
    public string Baslik { get; set; } = string.Empty;
    public string Mesaj { get; set; } = string.Empty;
    public string Tur { get; set; } = "Genel";
    public string Onem { get; set; } = "Normal";
    public string? IlgiliVarlikTuru { get; set; }
    public int? IlgiliVarlikId { get; set; }
    public int? IslemiYapanUserId { get; set; }
    public string? IslemiYapan { get; set; }
    public DateTime OlusturmaTarihi { get; set; } = DateTime.Now;
}
