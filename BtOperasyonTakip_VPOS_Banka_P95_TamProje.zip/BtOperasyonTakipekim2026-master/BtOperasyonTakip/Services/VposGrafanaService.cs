using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using BtOperasyonTakip.ViewModels;
using Microsoft.Extensions.Options;

namespace BtOperasyonTakip.Services;

public sealed class VposGrafanaService : IVposGrafanaService
{
    private readonly HttpClient _httpClient;
    private readonly VposGrafanaOptions _options;
    private readonly ILogger<VposGrafanaService> _logger;

    public VposGrafanaService(
        HttpClient httpClient,
        IOptions<VposGrafanaOptions> options,
        ILogger<VposGrafanaService> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<VposGrafanaConnectionTest> TestConnectionAsync(
        VposMonitoringCredential credential,
        CancellationToken cancellationToken = default)
    {
        try
        {
            ValidateCredential(credential);

            var baseUrl = NormalizeBaseUrl(credential.GrafanaUrl);
            var auth = await AuthenticateAsync(baseUrl, credential, cancellationToken);
            var discovery = await DiscoverAsync(baseUrl, auth, cancellationToken);

            return new VposGrafanaConnectionTest
            {
                Basarili = true,
                Mesaj = BuildDiscoveryMessage(discovery),
                DatasourceAdi = discovery.DataSourceName,
                DatasourceUid = discovery.DataSourceUid,
                Index = discovery.Index,
                TimestampField = discovery.TimestampField,
                CompanyField = discovery.CompanyField,
                ErrorCodeField = discovery.ErrorCodeField
            };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Grafana bağlantı testi başarısız.");
            return new VposGrafanaConnectionTest
            {
                Basarili = false,
                Mesaj = ToFriendlyMessage(ex)
            };
        }
    }

    public async Task<VposGrafanaSnapshot> GetSnapshotAsync(
        VposMonitoringCredential credential,
        int lookbackMinutes,
        CancellationToken cancellationToken = default)
    {
        lookbackMinutes = Math.Clamp(lookbackMinutes, 15, 1440);

        var snapshot = new VposGrafanaSnapshot
        {
            // Mevcut ViewModel değişmiyor. Aylar alanı artık kısa zaman
            // aralığındaki saat/dakika etiketlerini taşır.
            LookbackMonths = _options.LookbackMonths,
            Aylar = new List<string>(),
            AlinmaZamani = DateTime.Now
        };

        try
        {
            ValidateCredential(credential);

            var baseUrl = NormalizeBaseUrl(credential.GrafanaUrl);
            var auth = await AuthenticateAsync(baseUrl, credential, cancellationToken);
            var discovery = await DiscoverAsync(baseUrl, auth, cancellationToken);

            snapshot.DatasourceAdi = discovery.DataSourceName;
            snapshot.DatasourceUid = discovery.DataSourceUid;
            snapshot.Index = discovery.Index;
            snapshot.TimestampField = discovery.TimestampField;
            snapshot.CompanyField = discovery.CompanyField;
            snapshot.ErrorCodeField = discovery.ErrorCodeField;

            if (string.IsNullOrWhiteSpace(discovery.TimestampField))
                throw new InvalidOperationException("Elasticsearch tarih alanı otomatik bulunamadı.");

            if (string.IsNullOrWhiteSpace(discovery.CompanyField))
                throw new InvalidOperationException("Firma/üye işyeri alanı otomatik bulunamadı.");

            if (string.IsNullOrWhiteSpace(discovery.ErrorCodeField))
                throw new InvalidOperationException("Hata kodu alanı otomatik bulunamadı.");

            var companyTask = GetTopCompaniesAsync(
                baseUrl,
                auth,
                discovery,
                lookbackMinutes,
                cancellationToken);

            var errorsTask = GetTopErrorsAsync(
                baseUrl,
                auth,
                discovery,
                credential.ElasticUrl,
                lookbackMinutes,
                cancellationToken);

            var errorCompaniesTask = GetTopErrorCompaniesAsync(baseUrl, auth, discovery, lookbackMinutes, cancellationToken);
            await Task.WhenAll(companyTask, errorsTask, errorCompaniesTask);

            var companyResult = await companyTask;
            snapshot.Aylar = companyResult.Labels;
            snapshot.FirmaSerileri = companyResult.Series;
            snapshot.HataKodlari = await errorsTask;
            snapshot.HataAlanFirmalar = await errorCompaniesTask;
            try { snapshot.BankaPerformansi = await GetBankPerformanceAsync(baseUrl, auth, discovery, lookbackMinutes, cancellationToken); }
            catch (Exception ex) { _logger.LogWarning(ex, "Banka / P95 analizi alınamadı"); }
            try { snapshot.Insights = await GetInsightsAsync(baseUrl, auth, discovery, lookbackMinutes, cancellationToken); }
            catch (Exception ex) { _logger.LogWarning(ex, "VPOS ek analiz alınamadı"); }
            snapshot.Basarili = true;
            snapshot.Mesaj = $"Grafana / Elasticsearch verisi son {FormatPeriod(lookbackMinutes)} için alındı.";
            snapshot.AlinmaZamani = DateTime.Now;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "VPOS dashboard Grafana verisi alınamadı.");
            snapshot.Basarili = false;
            snapshot.Mesaj = ToFriendlyMessage(ex);
        }

        return snapshot;
    }

    private async Task<(List<string> Labels, List<VposFirmaIslemSerisiViewModel> Series)> GetTopCompaniesAsync(
        string baseUrl,
        GrafanaAuthContext auth,
        GrafanaDiscovery discovery,
        int lookbackMinutes,
        CancellationToken cancellationToken)
    {
        var intervalMinutes = ResolveBucketMinutes(lookbackMinutes);
        var fixedInterval = $"{intervalMinutes}m";
        var labelFormat = lookbackMinutes <= 360 ? "HH:mm" : "dd.MM HH:mm";
        var gte = $"now-{lookbackMinutes}m";

        var payload = new
        {
            size = 0,
            query = new
            {
                range = new Dictionary<string, object>
                {
                    [discovery.TimestampField!] = new
                    {
                        gte,
                        lte = "now",
                        time_zone = _options.TimeZone
                    }
                }
            },
            aggs = new
            {
                top_companies = new
                {
                    terms = new
                    {
                        field = discovery.CompanyField,
                        size = 5,
                        order = new Dictionary<string, string> { ["_count"] = "desc" }
                    },
                    aggs = new
                    {
                        per_period = new
                        {
                            date_histogram = new
                            {
                                field = discovery.TimestampField,
                                fixed_interval = fixedInterval,
                                format = labelFormat,
                                min_doc_count = 0,
                                time_zone = _options.TimeZone,
                                extended_bounds = new
                                {
                                    min = gte,
                                    max = "now"
                                }
                            }
                        }
                    }
                }
            }
        };

        using var doc = await PostElasticAsync(
            baseUrl,
            auth,
            discovery.DataSourceUid,
            discovery.Index,
            payload,
            cancellationToken);

        var result = new List<VposFirmaIslemSerisiViewModel>();
        var labels = new List<string>();

        if (!TryGetBuckets(doc.RootElement, "top_companies", out var buckets))
            return (labels, result);

        foreach (var companyBucket in buckets.EnumerateArray())
        {
            if (!companyBucket.TryGetProperty("per_period", out var perPeriod) ||
                !perPeriod.TryGetProperty("buckets", out var periodBuckets) ||
                periodBuckets.ValueKind != JsonValueKind.Array)
            {
                continue;
            }

            foreach (var periodBucket in periodBuckets.EnumerateArray())
            {
                var label = periodBucket.TryGetProperty("key_as_string", out var keyEl)
                    ? keyEl.GetString()
                    : null;

                if (!string.IsNullOrWhiteSpace(label) &&
                    !labels.Contains(label, StringComparer.OrdinalIgnoreCase))
                {
                    labels.Add(label);
                }
            }

            if (labels.Count > 0)
                break;
        }

        foreach (var bucket in buckets.EnumerateArray())
        {
            var company = bucket.TryGetProperty("key", out var keyEl)
                ? keyEl.ToString()
                : "Bilinmeyen";

            var values = labels.ToDictionary(
                x => x,
                _ => 0L,
                StringComparer.OrdinalIgnoreCase);

            if (bucket.TryGetProperty("per_period", out var perPeriod) &&
                perPeriod.TryGetProperty("buckets", out var periodBuckets) &&
                periodBuckets.ValueKind == JsonValueKind.Array)
            {
                foreach (var periodBucket in periodBuckets.EnumerateArray())
                {
                    var key = periodBucket.TryGetProperty("key_as_string", out var keyAsString)
                        ? keyAsString.GetString()
                        : null;

                    if (string.IsNullOrWhiteSpace(key) || !values.ContainsKey(key))
                        continue;

                    values[key] = ReadLong(periodBucket, "doc_count");
                }
            }

            var orderedValues = labels.Select(x => values[x]).ToList();

            result.Add(new VposFirmaIslemSerisiViewModel
            {
                Firma = company,
                Degerler = orderedValues,
                Toplam = orderedValues.Sum()
            });
        }

        return (
            labels,
            result
                .OrderByDescending(x => x.Toplam)
                .Take(5)
                .ToList()
        );
    }

    private async Task<VposInsightsViewModel> GetInsightsAsync(
        string baseUrl, GrafanaAuthContext auth, GrafanaDiscovery discovery,
        int minutes, CancellationToken ct)
    {
        // Tek aggregation: iki eşit pencere; belge çekilmez.
        var timeField = discovery.TimestampField!;
        var errorField = discovery.ErrorCodeField!;
        var payload = new
        {
            size = 0, track_total_hits = false,
            query = new { range = new Dictionary<string, object> {
                [timeField] = new { gte = $"now-{minutes * 2}m", lte = "now" } } },
            aggs = new Dictionary<string, object>
            {
                ["current"] = new { filter = new { range = new Dictionary<string, object> {
                    [timeField] = new { gte = $"now-{minutes}m", lte = "now" } } },
                    aggs = new { errors = new { filter = new { exists = new { field = errorField } } } } },
                ["previous"] = new { filter = new { range = new Dictionary<string, object> {
                    [timeField] = new { gte = $"now-{minutes * 2}m", lt = $"now-{minutes}m" } } },
                    aggs = new { errors = new { filter = new { exists = new { field = errorField } } } } }
            }
        };
        using var doc = await PostElasticAsync(baseUrl, auth, discovery.DataSourceUid, discovery.Index, payload, ct);
        var aggs = doc.RootElement.GetProperty("aggregations");
        var current = aggs.GetProperty("current");
        var previous = aggs.GetProperty("previous");
        var insight = new VposInsightsViewModel
        {
            SimdikiIslem = ReadLong(current, "doc_count"),
            OncekiIslem = ReadLong(previous, "doc_count"),
            SimdikiHataKoduKaydi = ReadLong(current.GetProperty("errors"), "doc_count"),
            OncekiHataKoduKaydi = ReadLong(previous.GetProperty("errors"), "doc_count")
        };
        if (insight.OncekiHataKoduKaydi >= 10 &&
            insight.SimdikiHataKoduKaydi >= insight.OncekiHataKoduKaydi * 1.5)
            insight.Uyari = "Hata kodu bulunan kayıtlar önceki eşit zaman dilimine göre en az %50 arttı. Başarısız işlem sayısı olarak yorumlamadan önce durum alanını doğrulayın.";
        return insight;
    }

    public async Task<List<VposMonthlySummary>> GetMonthlySummaryAsync(
        VposMonitoringCredential credential, int year, CancellationToken ct = default)
    {
        if (year < 2020 || year > DateTime.UtcNow.Year) throw new ArgumentOutOfRangeException(nameof(year));
        ValidateCredential(credential);
        var baseUrl = NormalizeBaseUrl(credential.GrafanaUrl);
        var auth = await AuthenticateAsync(baseUrl, credential, ct);
        var discovery = await DiscoverAsync(baseUrl, auth, ct);
        var field = discovery.TimestampField ?? throw new InvalidOperationException("Tarih alanı bulunamadı");
        var errorField = discovery.ErrorCodeField ?? throw new InvalidOperationException("Hata alanı bulunamadı");
        var start = $"{year}-01-01T00:00:00Z";
        var end = $"{year + 1}-01-01T00:00:00Z";
        var payload = new
        {
            size = 0, track_total_hits = false,
            query = new { range = new Dictionary<string, object> { [field] = new { gte = start, lt = end } } },
            aggs = new { months = new { date_histogram = new {
                field, calendar_interval = "month", format = "yyyy-MM", min_doc_count = 0,
                extended_bounds = new { min = start, max = $"{year}-12-01T00:00:00Z" } },
                aggs = new { errors = new { filter = new { exists = new { field = errorField } } } } } }
        };
        using var doc = await PostElasticAsync(baseUrl, auth, discovery.DataSourceUid, discovery.Index, payload, ct);
        var result = new List<VposMonthlySummary>();
        if (TryGetBuckets(doc.RootElement, "months", out var buckets))
            foreach (var bucket in buckets.EnumerateArray())
                result.Add(new VposMonthlySummary {
                    Ay = bucket.GetProperty("key_as_string").GetString() ?? "",
                    Islem = ReadLong(bucket, "doc_count"),
                    HataKoduKaydi = ReadLong(bucket.GetProperty("errors"), "doc_count") });
        return result;
    }

    private async Task<List<VposFirmaHataViewModel>> GetTopErrorCompaniesAsync(
        string baseUrl, GrafanaAuthContext auth, GrafanaDiscovery discovery,
        int lookbackMinutes, CancellationToken cancellationToken)
    {
        // Hata alanı bulunmayan kayıtlar başarısız işlem kabul edilmez.
        var payload = new
        {
            size = 0,
            track_total_hits = false,
            query = new
            {
                @bool = new
                {
                    filter = new object[]
                    {
                        new { range = new Dictionary<string, object> { [discovery.TimestampField!] = new { gte = $"now-{lookbackMinutes}m", lte = "now" } } },
                        new { exists = new { field = discovery.ErrorCodeField } },
                        new { exists = new { field = discovery.CompanyField } }
                    }
                }
            },
            aggs = new
            {
                companies = new
                {
                    terms = new { field = discovery.CompanyField, size = 5, order = new Dictionary<string, string> { ["_count"] = "desc" } }
                }
            }
        };
        using var doc = await PostElasticAsync(baseUrl, auth, discovery.DataSourceUid, discovery.Index, payload, cancellationToken);
        var result = new List<VposFirmaHataViewModel>();
        if (!TryGetBuckets(doc.RootElement, "companies", out var buckets)) return result;
        foreach (var bucket in buckets.EnumerateArray())
            result.Add(new VposFirmaHataViewModel
            {
                Firma = bucket.TryGetProperty("key", out var key) ? key.ToString() : "Bilinmeyen",
                HataAdedi = ReadLong(bucket, "doc_count")
            });
        return result;
    }

    private async Task<List<VposHataKodViewModel>> GetTopErrorsAsync(
        string baseUrl,
        GrafanaAuthContext auth,
        GrafanaDiscovery discovery,
        string elasticUrl,
        int lookbackMinutes,
        CancellationToken cancellationToken)
    {
        var gte = $"now-{Math.Clamp(lookbackMinutes, 15, 1440)}m";

        var payload = new
        {
            size = 0,
            query = new
            {
                range = new Dictionary<string, object>
                {
                    [discovery.TimestampField!] = new
                    {
                        gte,
                        lte = "now",
                        time_zone = _options.TimeZone
                    }
                }
            },
            aggs = new
            {
                top_errors = new
                {
                    terms = new
                    {
                        field = discovery.ErrorCodeField,
                        size = 10000,
                        order = new Dictionary<string, string> { ["_count"] = "desc" }
                    }
                }
            }
        };

        using var doc = await PostElasticAsync(
            baseUrl,
            auth,
            discovery.DataSourceUid,
            discovery.Index,
            payload,
            cancellationToken);

        var result = new List<VposHataKodViewModel>();

        if (!TryGetBuckets(doc.RootElement, "top_errors", out var buckets))
            return result;

        foreach (var bucket in buckets.EnumerateArray())
        {
            var code = bucket.TryGetProperty("key", out var keyEl)
                ? keyEl.ToString()
                : "Bilinmeyen";

            result.Add(new VposHataKodViewModel
            {
                HataKodu = code,
                Adet = ReadLong(bucket, "doc_count"),
                ElasticUrl = BuildElasticUrl(elasticUrl, discovery.ErrorCodeField!, code)
            });
        }

        return result
            .OrderByDescending(x => x.Adet)
            .ToList();
    }

    private async Task<GrafanaAuthContext> AuthenticateAsync(
        string baseUrl,
        VposMonitoringCredential credential,
        CancellationToken cancellationToken)
    {
        var basicValue = Convert.ToBase64String(
            Encoding.UTF8.GetBytes($"{credential.Username}:{credential.Password}"));

        using (var request = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/api/user"))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", basicValue);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            using var response = await _httpClient.SendAsync(request, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                return new GrafanaAuthContext
                {
                    BasicToken = basicValue
                };
            }
        }

        // Basic Auth kapalıysa Grafana'nın normal kullanıcı/parola login endpoint'ini dener.
        using var loginRequest = new HttpRequestMessage(HttpMethod.Post, $"{baseUrl}/login");
        loginRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        loginRequest.Content = new StringContent(
            JsonSerializer.Serialize(new
            {
                user = credential.Username,
                password = credential.Password
            }),
            Encoding.UTF8,
            "application/json");

        using var loginResponse = await _httpClient.SendAsync(loginRequest, cancellationToken);
        var loginBody = await loginResponse.Content.ReadAsStringAsync(cancellationToken);

        if (!loginResponse.IsSuccessStatusCode)
        {
            throw new GrafanaAuthenticationException(
                $"Grafana kullanıcı adı/şifre kabul edilmedi. HTTP {(int)loginResponse.StatusCode}.");
        }

        if (!loginResponse.Headers.TryGetValues("Set-Cookie", out var setCookies))
        {
            // Bazı Grafana kurulumları 200 döndürüp login'i yine de reddedebilir.
            if (loginBody.Contains("error", StringComparison.OrdinalIgnoreCase) ||
                loginBody.Contains("invalid", StringComparison.OrdinalIgnoreCase))
            {
                throw new GrafanaAuthenticationException(
                    "Grafana kullanıcı adı/şifre kabul edilmedi.");
            }

            throw new GrafanaAuthenticationException(
                "Grafana giriş yaptı ancak oturum cookie'si üretmedi. Kurulum SSO/LDAP ile çalışıyor olabilir.");
        }

        var cookieHeader = string.Join(
            "; ",
            setCookies
                .Select(x => x.Split(';', 2)[0].Trim())
                .Where(x => !string.IsNullOrWhiteSpace(x)));

        if (string.IsNullOrWhiteSpace(cookieHeader))
        {
            throw new GrafanaAuthenticationException(
                "Grafana oturumu oluşturulamadı.");
        }

        // Oluşan cookie gerçekten API erişimi sağlıyor mu kontrol et.
        using var verifyRequest = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/api/user");
        verifyRequest.Headers.TryAddWithoutValidation("Cookie", cookieHeader);
        verifyRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        using var verifyResponse = await _httpClient.SendAsync(verifyRequest, cancellationToken);
        if (!verifyResponse.IsSuccessStatusCode)
        {
            throw new GrafanaAuthenticationException(
                "Grafana oturumu açıldı ancak API erişimine izin verilmedi.");
        }

        return new GrafanaAuthContext
        {
            CookieHeader = cookieHeader
        };
    }

    private async Task<GrafanaDiscovery> DiscoverAsync(
        string baseUrl,
        GrafanaAuthContext auth,
        CancellationToken cancellationToken)
    {
        var dataSources = await GetDataSourcesAsync(baseUrl, auth, cancellationToken);

        if (dataSources.Count == 0)
        {
            throw new InvalidOperationException(
                "Grafana hesabında erişilebilir Elasticsearch datasource bulunamadı.");
        }

        GrafanaDataSource selected;

        if (!string.IsNullOrWhiteSpace(_options.DataSourceUid))
        {
            selected = dataSources.FirstOrDefault(x =>
                           string.Equals(
                               x.Uid,
                               _options.DataSourceUid,
                               StringComparison.OrdinalIgnoreCase))
                       ?? throw new InvalidOperationException(
                           $"Ayarlanan datasource UID bulunamadı: {_options.DataSourceUid}");
        }
        else
        {
            selected = dataSources
                .OrderByDescending(x => ScoreDataSourceName(x.Name))
                .First();
        }

        var index = !string.IsNullOrWhiteSpace(_options.Index)
            ? _options.Index.Trim()
            : NormalizeGrafanaIndex(selected.Database);

        var fields = await GetFieldCapabilitiesAsync(
            baseUrl,
            auth,
            selected.Uid,
            index,
            cancellationToken);

        var timestampField = !string.IsNullOrWhiteSpace(_options.TimestampField)
            ? _options.TimestampField.Trim()
            : ChooseTimestampField(fields);

        var companyField = !string.IsNullOrWhiteSpace(_options.CompanyField)
            ? _options.CompanyField.Trim()
            : ChooseCompanyField(fields);

        var errorCodeField = !string.IsNullOrWhiteSpace(_options.ErrorCodeField)
            ? _options.ErrorCodeField.Trim()
            : ChooseErrorCodeField(fields);

        return new GrafanaDiscovery
        {
            DataSourceUid = selected.Uid,
            DataSourceName = selected.Name,
            Index = index,
            TimestampField = timestampField,
            CompanyField = companyField,
            ErrorCodeField = errorCodeField,
            BankField = ChooseBankField(fields),
            DurationField = ChooseDurationField(fields)
        };
    }

    private async Task<List<GrafanaDataSource>> GetDataSourcesAsync(
        string baseUrl,
        GrafanaAuthContext auth,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/api/datasources");
        ApplyAuth(request, auth);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);

        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            throw new GrafanaAuthenticationException("Grafana datasource listesine erişim yetkiniz yok.");

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(
                $"Grafana datasource listesi alınamadı. HTTP {(int)response.StatusCode}: {TrimForLog(body)}");

        using var doc = JsonDocument.Parse(body);
        var result = new List<GrafanaDataSource>();

        if (doc.RootElement.ValueKind != JsonValueKind.Array)
            return result;

        foreach (var item in doc.RootElement.EnumerateArray())
        {
            var type = GetString(item, "type");
            var typeName = GetString(item, "typeName");

            var isElastic = type.Contains("elasticsearch", StringComparison.OrdinalIgnoreCase) ||
                            typeName.Contains("elasticsearch", StringComparison.OrdinalIgnoreCase);

            if (!isElastic)
                continue;

            var uid = GetString(item, "uid");
            if (string.IsNullOrWhiteSpace(uid))
                continue;

            result.Add(new GrafanaDataSource
            {
                Uid = uid,
                Name = GetString(item, "name"),
                Database = GetString(item, "database")
            });
        }

        return result;
    }

    private async Task<List<ElasticFieldInfo>> GetFieldCapabilitiesAsync(
        string baseUrl,
        GrafanaAuthContext auth,
        string dataSourceUid,
        string index,
        CancellationToken cancellationToken)
    {
        var paths = new List<string>();

        if (!string.IsNullOrWhiteSpace(index))
        {
            paths.Add(
                $"{EncodePathSegment(index)}/_field_caps?fields={Uri.EscapeDataString("*")}");
        }

        paths.Add($"_field_caps?fields={Uri.EscapeDataString("*")}");

        Exception? lastError = null;

        foreach (var path in paths.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                using var doc = await GetElasticJsonAsync(
                    baseUrl,
                    auth,
                    dataSourceUid,
                    path,
                    cancellationToken);

                if (!doc.RootElement.TryGetProperty("fields", out var fieldsElement) ||
                    fieldsElement.ValueKind != JsonValueKind.Object)
                {
                    continue;
                }

                var result = new List<ElasticFieldInfo>();

                foreach (var fieldProperty in fieldsElement.EnumerateObject())
                {
                    var fieldInfo = new ElasticFieldInfo
                    {
                        Name = fieldProperty.Name
                    };

                    if (fieldProperty.Value.ValueKind == JsonValueKind.Object)
                    {
                        foreach (var typeProperty in fieldProperty.Value.EnumerateObject())
                        {
                            fieldInfo.Types.Add(typeProperty.Name);

                            if (typeProperty.Value.ValueKind == JsonValueKind.Object &&
                                typeProperty.Value.TryGetProperty("aggregatable", out var agg) &&
                                agg.ValueKind == JsonValueKind.True)
                            {
                                fieldInfo.Aggregatable = true;
                            }
                        }
                    }

                    result.Add(fieldInfo);
                }

                if (result.Count > 0)
                    return result;
            }
            catch (Exception ex)
            {
                lastError = ex;
            }
        }

        throw new InvalidOperationException(
            "Elasticsearch alan listesi alınamadı.",
            lastError);
    }

    private async Task<JsonDocument> GetElasticJsonAsync(
        string baseUrl,
        GrafanaAuthContext auth,
        string dataSourceUid,
        string relativePath,
        CancellationToken cancellationToken)
    {
        var uid = Uri.EscapeDataString(dataSourceUid.Trim());
        var cleanPath = relativePath.TrimStart('/');
        var url = $"{baseUrl}/api/datasources/proxy/uid/{uid}/{cleanPath}";

        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        ApplyAuth(request, auth);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);

        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            throw new GrafanaAuthenticationException("Grafana/Elasticsearch sorgu yetkiniz yok.");

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(
                $"Elasticsearch HTTP {(int)response.StatusCode}: {TrimForLog(body)}");

        return JsonDocument.Parse(body);
    }

    private async Task<JsonDocument> PostElasticAsync(
        string baseUrl,
        GrafanaAuthContext auth,
        string dataSourceUid,
        string index,
        object payload,
        CancellationToken cancellationToken)
    {
        var uid = Uri.EscapeDataString(dataSourceUid.Trim());
        var searchPath = string.IsNullOrWhiteSpace(index)
            ? "_search"
            : $"{EncodePathSegment(index)}/_search";

        var url = $"{baseUrl}/api/datasources/proxy/uid/{uid}/{searchPath}";

        using var request = new HttpRequestMessage(HttpMethod.Post, url);
        ApplyAuth(request, auth);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        request.Content = new StringContent(
            JsonSerializer.Serialize(payload),
            Encoding.UTF8,
            "application/json");

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);

        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            throw new GrafanaAuthenticationException("Grafana/Elasticsearch sorgu yetkiniz yok.");

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(
                $"Grafana datasource proxy HTTP {(int)response.StatusCode}: {TrimForLog(body)}");
        }

        return JsonDocument.Parse(body);
    }

    private static void ApplyAuth(HttpRequestMessage request, GrafanaAuthContext auth)
    {
        if (!string.IsNullOrWhiteSpace(auth.BasicToken))
        {
            request.Headers.Authorization =
                new AuthenticationHeaderValue("Basic", auth.BasicToken);
            return;
        }

        if (!string.IsNullOrWhiteSpace(auth.CookieHeader))
        {
            request.Headers.TryAddWithoutValidation("Cookie", auth.CookieHeader);
        }
    }

    private static string? ChooseBankField(IEnumerable<ElasticFieldInfo> fields) =>
        fields.Where(IsAggregationCandidate)
            .Select(f => new { f.Name, Score = ScoreName(f.Name, new[] {
                ("bank_name", 180), ("bankname", 180), ("bank_code", 170),
                ("bankcode", 170), ("bank", 90), ("banka", 90), ("acquirer", 80)
            }) })
            .Where(x => x.Score >= 80 && !x.Name.Contains("banksoft", StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(x => x.Score).Select(x => x.Name).FirstOrDefault();

    private static string? ChooseDurationField(IEnumerable<ElasticFieldInfo> fields) =>
        fields.Where(f => f.Aggregatable && f.Types.Any(t =>
            t is "integer" or "long" or "short" or "float" or "double" or "half_float" or "scaled_float"))
            .Select(f => new { f.Name, Score = ScoreName(f.Name, new[] {
                ("duration_ms", 200), ("elapsed_ms", 200), ("response_time_ms", 200),
                ("latency_ms", 200), ("duration", 90), ("elapsed", 90), ("latency", 90)
            }) })
            .Where(x => x.Score >= 90).OrderByDescending(x => x.Score)
            .Select(x => x.Name).FirstOrDefault();

    private async Task<VposBankPerformanceViewModel> GetBankPerformanceAsync(
        string baseUrl, GrafanaAuthContext auth, GrafanaDiscovery discovery, int minutes, CancellationToken ct)
    {
        var result = new VposBankPerformanceViewModel {
            BankField = discovery.BankField, DurationField = discovery.DurationField
        };
        if (discovery.BankField == null && discovery.DurationField == null) return result;
        var aggs = new Dictionary<string, object>();
        if (discovery.BankField != null)
            aggs["banks"] = new { terms = new { field = discovery.BankField, size = 20,
                order = new Dictionary<string, string> { ["_count"] = "desc" } },
                aggs = new { error_records = new { filter = new { exists = new { field = discovery.ErrorCodeField } } } } };
        if (discovery.DurationField != null)
            aggs["latency"] = new { percentiles = new { field = discovery.DurationField,
                percents = new[] { 50, 95, 99 }, keyed = true } };
        var payload = new { size = 0, track_total_hits = false,
            query = new { range = new Dictionary<string, object> {
                [discovery.TimestampField!] = new { gte = $"now-{minutes}m", lte = "now" } } },
            aggs };
        using var doc = await PostElasticAsync(baseUrl, auth, discovery.DataSourceUid, discovery.Index, payload, ct);
        var root = doc.RootElement.GetProperty("aggregations");
        if (root.TryGetProperty("banks", out var banks) && banks.TryGetProperty("buckets", out var buckets))
            foreach (var b in buckets.EnumerateArray())
                result.Banks.Add(new VposBankRowViewModel {
                    Bank = b.GetProperty("key").ToString(),
                    TotalRecords = ReadLong(b, "doc_count"),
                    ErrorCodeRecords = ReadLong(b.GetProperty("error_records"), "doc_count")
                });
        if (root.TryGetProperty("latency", out var latency) && latency.TryGetProperty("values", out var values)) {
            if (values.TryGetProperty("50.0", out var p50) && p50.ValueKind == JsonValueKind.Number) result.P50 = p50.GetDouble();
            if (values.TryGetProperty("95.0", out var p95) && p95.ValueKind == JsonValueKind.Number) result.P95 = p95.GetDouble();
            if (values.TryGetProperty("99.0", out var p99) && p99.ValueKind == JsonValueKind.Number) result.P99 = p99.GetDouble();
        }
        return result;
    }

    private static string? ChooseTimestampField(IEnumerable<ElasticFieldInfo> fields)
    {
        var dateFields = fields
            .Where(x => x.Types.Any(t => string.Equals(t, "date", StringComparison.OrdinalIgnoreCase)))
            .ToList();

        string[] exact =
        {
            "@timestamp",
            "timestamp",
            "event.timestamp",
            "created_at",
            "createdAt",
            "date"
        };

        foreach (var candidate in exact)
        {
            var match = dateFields.FirstOrDefault(x =>
                string.Equals(x.Name, candidate, StringComparison.OrdinalIgnoreCase));
            if (match != null)
                return match.Name;
        }

        return dateFields
            .OrderByDescending(x => ScoreName(x.Name, new[]
            {
                ("timestamp", 100), ("time", 70), ("date", 60),
                ("created", 50), ("tarih", 50)
            }))
            .Select(x => x.Name)
            .FirstOrDefault();
    }

    private static string? ChooseCompanyField(IEnumerable<ElasticFieldInfo> fields)
    {
        var candidates = fields
            .Where(IsAggregationCandidate)
            .Select(x => new
            {
                Field = x,
                Score = ScoreName(x.Name, new[]
                {
                    ("merchantname", 150),
                    ("merchant_name", 150),
                    ("merchant", 130),
                    ("uyeisyeri", 130),
                    ("uye_isyeri", 130),
                    ("üyeişyeri", 130),
                    ("firma", 120),
                    ("company", 110),
                    ("customer", 90),
                    ("client", 80),
                    ("business", 70),
                    ("member", 60)
                }) + (x.Name.EndsWith(".keyword", StringComparison.OrdinalIgnoreCase) ? 15 : 0)
            })
            .Where(x => x.Score >= 60)
            .OrderByDescending(x => x.Score)
            .ThenBy(x => x.Field.Name.Length)
            .FirstOrDefault();

        return candidates?.Field.Name;
    }

    private static string? ChooseErrorCodeField(IEnumerable<ElasticFieldInfo> fields)
    {
        var candidates = fields
            .Where(IsAggregationCandidate)
            .Select(x => new
            {
                Field = x,
                Score = ScoreName(x.Name, new[]
                {
                    ("error.code", 170),
                    ("error_code", 170),
                    ("errorcode", 165),
                    ("hata.kodu", 165),
                    ("hata_kodu", 165),
                    ("hatakodu", 160),
                    ("response.code", 130),
                    ("response_code", 130),
                    ("status_code", 120),
                    ("status.code", 120),
                    ("md_status", 110),
                    ("result_code", 105),
                    ("code", 65)
                }) + (x.Name.EndsWith(".keyword", StringComparison.OrdinalIgnoreCase) ? 10 : 0)
            })
            .Where(x => x.Score >= 65)
            .OrderByDescending(x => x.Score)
            .ThenBy(x => x.Field.Name.Length)
            .FirstOrDefault();

        return candidates?.Field.Name;
    }

    private static bool IsAggregationCandidate(ElasticFieldInfo field)
    {
        if (!field.Aggregatable)
            return false;

        return field.Types.Any(t =>
            string.Equals(t, "keyword", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(t, "integer", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(t, "long", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(t, "short", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(t, "byte", StringComparison.OrdinalIgnoreCase));
    }

    private static int ScoreName(
        string name,
        IEnumerable<(string Token, int Score)> rules)
    {
        var normalized = name
            .Replace("-", "_", StringComparison.Ordinal)
            .ToLowerInvariant();

        var score = 0;

        foreach (var rule in rules)
        {
            if (normalized.Contains(rule.Token.ToLowerInvariant(), StringComparison.Ordinal))
                score = Math.Max(score, rule.Score);
        }

        return score;
    }

    private static int ScoreDataSourceName(string name)
    {
        var value = name?.ToLowerInvariant() ?? string.Empty;
        var score = 0;

        if (value.Contains("vpos")) score += 100;
        if (value.Contains("payment")) score += 80;
        if (value.Contains("odeme") || value.Contains("ödeme")) score += 80;
        if (value.Contains("prod")) score += 40;
        if (value.Contains("elastic")) score += 20;

        return score;
    }

    private static string NormalizeGrafanaIndex(string? database)
    {
        if (string.IsNullOrWhiteSpace(database))
            return string.Empty;

        var value = database.Trim().Trim('/');

        // Grafana'nın [log-prefix-]YYYY.MM.DD formatını Elasticsearch wildcard'a çevir.
        var bracketMatch = Regex.Match(value, @"^\[(?<prefix>[^\]]+)\].*$");
        if (bracketMatch.Success)
            return bracketMatch.Groups["prefix"].Value + "*";

        return value;
    }

    private static string EncodePathSegment(string value)
    {
        // '*' ve ',' Elasticsearch index patternlerinde anlamlıdır; diğer karakterleri encode et.
        return Uri.EscapeDataString(value.Trim())
            .Replace("%2A", "*", StringComparison.OrdinalIgnoreCase)
            .Replace("%2C", ",", StringComparison.OrdinalIgnoreCase);
    }

    private static string BuildElasticUrl(
        string elasticUrl,
        string errorField,
        string code)
    {
        if (string.IsNullOrWhiteSpace(elasticUrl))
            return string.Empty;

        var url = elasticUrl.Trim();
        var escapedCode = Uri.EscapeDataString(code);
        var escapedField = Uri.EscapeDataString(errorField);

        if (url.Contains("{code}", StringComparison.OrdinalIgnoreCase) ||
            url.Contains("{field}", StringComparison.OrdinalIgnoreCase))
        {
            return url
                .Replace("{code}", escapedCode, StringComparison.OrdinalIgnoreCase)
                .Replace("{field}", escapedField, StringComparison.OrdinalIgnoreCase);
        }

        // Kullanıcı doğrudan bir Kibana Discover linki girdiyse mevcut linki koru.
        if (url.Contains("/app/discover", StringComparison.OrdinalIgnoreCase))
        {
            var basePart = url.Split('#', 2)[0];
            return $"{basePart}#/?_a=(query:(language:kuery,query:'{errorField}:%22{escapedCode}%22'))";
        }

        // Kibana ana adresi verildiyse Discover ekranına hata kodu filtresiyle git.
        if (!url.Contains(":9200", StringComparison.OrdinalIgnoreCase) &&
            !url.Contains(":9300", StringComparison.OrdinalIgnoreCase))
        {
            return $"{url.TrimEnd('/')}/app/discover#/?_a=(query:(language:kuery,query:'{errorField}:%22{escapedCode}%22'))";
        }

        // Doğrudan Elasticsearch API adresi ise sadece verilen adresi aç.
        return url;
    }

    private static string BuildDiscoveryMessage(GrafanaDiscovery discovery)
    {
        var missing = new List<string>();
        if (string.IsNullOrWhiteSpace(discovery.TimestampField)) missing.Add("tarih alanı");
        if (string.IsNullOrWhiteSpace(discovery.CompanyField)) missing.Add("firma alanı");
        if (string.IsNullOrWhiteSpace(discovery.ErrorCodeField)) missing.Add("hata kodu alanı");

        if (missing.Count == 0)
        {
            return $"Bağlantı başarılı. Datasource: {discovery.DataSourceName}. Alanlar otomatik bulundu.";
        }

        return $"Grafana bağlantısı başarılı; ancak {string.Join(", ", missing)} otomatik bulunamadı.";
    }

    private static string ToFriendlyMessage(Exception ex)
    {
        if (ex is GrafanaAuthenticationException)
            return ex.Message;

        if (ex is TaskCanceledException)
            return "Grafana bağlantısı zaman aşımına uğradı.";

        if (ex is HttpRequestException)
            return "Grafana adresine ulaşılamadı. URL, ağ/VPN ve sertifika erişimini kontrol edin.";

        return ex.Message;
    }

    private static void ValidateCredential(VposMonitoringCredential credential)
    {
        if (credential == null)
            throw new InvalidOperationException("Grafana bağlantı bilgisi bulunamadı.");

        if (string.IsNullOrWhiteSpace(credential.GrafanaUrl))
            throw new InvalidOperationException("Grafana URL zorunludur.");

        if (!Uri.TryCreate(credential.GrafanaUrl, UriKind.Absolute, out var grafanaUri) ||
            (grafanaUri.Scheme != Uri.UriSchemeHttp && grafanaUri.Scheme != Uri.UriSchemeHttps))
        {
            throw new InvalidOperationException("Grafana URL geçerli bir http/https adresi olmalıdır.");
        }

        if (string.IsNullOrWhiteSpace(credential.Username))
            throw new InvalidOperationException("Grafana kullanıcı adı zorunludur.");

        if (string.IsNullOrWhiteSpace(credential.Password))
            throw new InvalidOperationException("Grafana şifresi zorunludur.");

        if (!string.IsNullOrWhiteSpace(credential.ElasticUrl) &&
            (!Uri.TryCreate(credential.ElasticUrl, UriKind.Absolute, out var elasticUri) ||
             (elasticUri.Scheme != Uri.UriSchemeHttp && elasticUri.Scheme != Uri.UriSchemeHttps)))
        {
            throw new InvalidOperationException("Elastic/Kibana URL geçerli bir http/https adresi olmalıdır.");
        }
    }

    private static string NormalizeBaseUrl(string url) => url.Trim().TrimEnd('/');

    private static string GetString(JsonElement element, string property)
    {
        return element.TryGetProperty(property, out var value)
            ? value.ToString()
            : string.Empty;
    }

    private static int ResolveBucketMinutes(int lookbackMinutes)
    {
        if (lookbackMinutes <= 30) return 5;
        if (lookbackMinutes <= 60) return 10;
        if (lookbackMinutes <= 180) return 15;
        if (lookbackMinutes <= 360) return 30;
        if (lookbackMinutes <= 720) return 60;
        return 120;
    }

    private static string FormatPeriod(int minutes)
    {
        return minutes switch
        {
            15 => "15 dakika",
            30 => "30 dakika",
            60 => "1 saat",
            180 => "3 saat",
            360 => "6 saat",
            720 => "12 saat",
            1440 => "24 saat",
            _ => $"{minutes} dakika"
        };
    }

    private static List<string> BuildMonthKeys(int months)
    {
        var currentMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        return Enumerable.Range(0, months)
            .Select(i => currentMonth.AddMonths(-(months - 1) + i).ToString("yyyy-MM"))
            .ToList();
    }

    private static bool TryGetBuckets(
        JsonElement root,
        string aggregationName,
        out JsonElement buckets)
    {
        buckets = default;

        return root.TryGetProperty("aggregations", out var aggs) &&
               aggs.TryGetProperty(aggregationName, out var aggregation) &&
               aggregation.TryGetProperty("buckets", out buckets) &&
               buckets.ValueKind == JsonValueKind.Array;
    }

    private static long ReadLong(JsonElement element, string property)
    {
        if (!element.TryGetProperty(property, out var value))
            return 0;

        if (value.ValueKind == JsonValueKind.Number && value.TryGetInt64(out var number))
            return number;

        return long.TryParse(value.ToString(), out var parsed) ? parsed : 0;
    }

    private static string TrimForLog(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "boş yanıt";

        var normalized = value.ReplaceLineEndings(" ").Trim();
        return normalized.Length <= 500 ? normalized : normalized[..500] + "...";
    }

    private sealed class GrafanaAuthContext
    {
        public string? BasicToken { get; init; }
        public string? CookieHeader { get; init; }
    }

    private sealed class GrafanaDataSource
    {
        public string Uid { get; init; } = string.Empty;
        public string Name { get; init; } = string.Empty;
        public string Database { get; init; } = string.Empty;
    }

    private sealed class GrafanaDiscovery
    {
        public string DataSourceUid { get; init; } = string.Empty;
        public string DataSourceName { get; init; } = string.Empty;
        public string Index { get; init; } = string.Empty;
        public string? TimestampField { get; init; }
        public string? CompanyField { get; init; }
        public string? ErrorCodeField { get; init; }
        public string? BankField { get; init; }
        public string? DurationField { get; init; }
    }

    private sealed class ElasticFieldInfo
    {
        public string Name { get; init; } = string.Empty;
        public bool Aggregatable { get; set; }
        public HashSet<string> Types { get; } = new(StringComparer.OrdinalIgnoreCase);
    }

    private sealed class GrafanaAuthenticationException : Exception
    {
        public GrafanaAuthenticationException(string message) : base(message)
        {
        }
    }
}
