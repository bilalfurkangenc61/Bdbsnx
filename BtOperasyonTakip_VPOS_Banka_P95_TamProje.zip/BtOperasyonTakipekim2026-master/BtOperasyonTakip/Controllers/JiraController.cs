﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace BtOperasyonTakip.Controllers
{
    public class JiraController : Controller
    {
        private readonly AppDbContext _context;
        public JiraController(AppDbContext context) => _context = context;

        [HttpGet]
        public IActionResult Index(int? selectedTaskId = null)
        {
            var tasks = _context.JiraTasks
                                .Include(x => x.Yorumlar)
                                .OrderByDescending(x => x.OlusturmaTarihi)
                                .ToList();

            var kullaniciList = _context.Users
                .AsNoTracking()
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct()
                .OrderBy(x => x)
                .ToList();

            var model = new JiraBoardViewModel
            {
                SelectedTaskId = selectedTaskId,
                Beklemede = tasks.Where(t => (t.Durum ?? "").Trim().Equals("Beklemede", StringComparison.OrdinalIgnoreCase)).ToList(),
                Aktif = tasks.Where(t => (t.Durum ?? "").Trim().Equals("Aktif", StringComparison.OrdinalIgnoreCase)).ToList(),
                Tamamlandi = tasks.Where(t => (t.Durum ?? "").Trim().Equals("Tamamlandı", StringComparison.OrdinalIgnoreCase)).ToList(),
                TakipEdenSecenekleri = kullaniciList,
                TalepAcanSecenekleri = kullaniciList
            };

            if (selectedTaskId.HasValue && selectedTaskId.Value > 0)
            {
                model.SelectedTask = tasks.FirstOrDefault(t => t.Id == selectedTaskId.Value);
            }

            ViewBag.KullaniciSecenekleri = kullaniciList;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(JiraTask model)
        {
            if (model == null) return RedirectToAction(nameof(Index));

            model.JiraId = (model.JiraId ?? "").Trim();
            model.TalepKonusu = (model.TalepKonusu ?? "").Trim();
            model.TalepAcan = (User.Identity?.Name ?? "Sistem").Trim();
            model.Durum = string.IsNullOrWhiteSpace(model.Durum) ? "Beklemede" : model.Durum.Trim();

            if (string.IsNullOrWhiteSpace(model.JiraId) || string.IsNullOrWhiteSpace(model.TalepKonusu))
            {
                TempData["JiraError"] = "Jira ID and Request Subject are required.";
                return RedirectToAction(nameof(Index));
            }

            model.OlusturmaTarihi = DateTime.Now;

            _context.JiraTasks.Add(model);
            _context.SaveChanges();
            TempData["JiraOk"] = "Task added.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddYorum(int jiraTaskId, string yorum, string ekleyen)
        {
            yorum = (yorum ?? "").Trim();
            ekleyen = (User.Identity?.Name ?? "Sistem").Trim();

            if (string.IsNullOrWhiteSpace(yorum))
            {
                TempData["JiraError"] = "Comment cannot be empty.";
                return RedirectToAction(nameof(Index));
            }

            var task = _context.JiraTasks.Find(jiraTaskId);
            if (task == null)
            {
                TempData["JiraError"] = "Task was not found.";
                return RedirectToAction(nameof(Index));
            }

            var now = DateTime.Now;
            _context.JiraYorumlar.Add(new JiraYorum
            {
                JiraTaskId = jiraTaskId,
                YorumMetni = yorum,
                Ekleyen = ekleyen,
                Tarih = now
            });

            
            if (task.MusteriID.HasValue && task.MusteriID.Value > 0)
            {
                _context.Detaylar.Add(new Detay
                {
                    MusteriID = task.MusteriID.Value,
                    Tarih = now,
                    Gorusulen = string.IsNullOrWhiteSpace(task.TalepKonusu) ? "İş Takip Yorumu" : task.TalepKonusu.Trim(),
                    Aciklama = yorum,
                    Kekleyen = ekleyen
                });
            }

            _context.SaveChanges();
            TempData["JiraOk"] = "Comment added.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddYorumForm(int jiraTaskId, string yorum, string ekleyen, string? returnUrl)
        {
            yorum = (yorum ?? "").Trim();
            ekleyen = (User.Identity?.Name ?? "Sistem").Trim();

            if (string.IsNullOrWhiteSpace(yorum))
            {
                TempData["JiraError"] = "Comment cannot be empty.";
                return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                    ? LocalRedirect(returnUrl)
                    : RedirectToAction(nameof(Index));
            }

            var task = _context.JiraTasks.Find(jiraTaskId);
            if (task == null)
            {
                TempData["JiraError"] = "Task was not found.";
                return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                    ? LocalRedirect(returnUrl)
                    : RedirectToAction(nameof(Index));
            }

            var now = DateTime.Now;
            _context.JiraYorumlar.Add(new JiraYorum
            {
                JiraTaskId = jiraTaskId,
                YorumMetni = yorum,
                Ekleyen = ekleyen,
                Tarih = now
            });

            if (task.MusteriID.HasValue && task.MusteriID.Value > 0)
            {
                _context.Detaylar.Add(new Detay
                {
                    MusteriID = task.MusteriID.Value,
                    Tarih = now,
                    Gorusulen = string.IsNullOrWhiteSpace(task.TalepKonusu) ? "İş Takip Yorumu" : task.TalepKonusu.Trim(),
                    Aciklama = yorum,
                    Kekleyen = ekleyen
                });
            }

            _context.SaveChanges();
            TempData["JiraOk"] = "Comment added.";
            return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? LocalRedirect(returnUrl)
                : RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AssignForm(int id, string? takipEden, string? returnUrl)
        {
            var task = _context.JiraTasks.Find(id);
            if (task == null)
            {
                TempData["JiraError"] = "Record was not found.";
                return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                    ? LocalRedirect(returnUrl)
                    : RedirectToAction(nameof(Index));
            }

            task.TakipEden = (takipEden ?? string.Empty).Trim();
            _context.SaveChanges();
            TempData["JiraOk"] = "Assignee updated.";
            return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? LocalRedirect(returnUrl)
                : RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateDurumForm(int id, string? yeniDurum, string? returnUrl)
        {
            if (id <= 0 || string.IsNullOrWhiteSpace(yeniDurum))
            {
                TempData["JiraError"] = "Invalid status update.";
                return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                    ? LocalRedirect(returnUrl)
                    : RedirectToAction(nameof(Index));
            }

            var task = _context.JiraTasks.Find(id);
            if (task == null)
            {
                TempData["JiraError"] = "Task not found";
                return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                    ? LocalRedirect(returnUrl)
                    : RedirectToAction(nameof(Index));
            }

            task.Durum = yeniDurum.Trim();
            _context.SaveChanges();
            TempData["JiraOk"] = "Status updated.";
            return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? LocalRedirect(returnUrl)
                : RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,OperasyonSuperAdmin,Operasyon Süper Admin,Operasyon Super Admin")]
        public IActionResult DeleteForm(int id, string? returnUrl)
        {
            var task = _context.JiraTasks
                               .Include(t => t.Yorumlar)
                               .FirstOrDefault(t => t.Id == id);
            if (task == null)
            {
                TempData["JiraError"] = "Record was not found.";
                return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                    ? LocalRedirect(returnUrl)
                    : RedirectToAction(nameof(Index));
            }

            if (task.Yorumlar != null && task.Yorumlar.Any())
                _context.JiraYorumlar.RemoveRange(task.Yorumlar);

            _context.JiraTasks.Remove(task);
            _context.SaveChanges();

            TempData["JiraOk"] = "Record deleted.";
            return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? LocalRedirect(returnUrl)
                : RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult UpdateDurum([FromBody] UpdateDurumModel model)
        {
            try
            {

                if (model == null)
                {
                    return Json(new { success = false, message = "Model is null" });
                }

                if (model.Id <= 0)
                {
                    return Json(new { success = false, message = "Invalid ID" });
                }

                if (string.IsNullOrWhiteSpace(model.YeniDurum))
                {
                    return Json(new { success = false, message = "Empty status" });
                }

                var task = _context.JiraTasks.Find(model.Id);
                if (task == null)
                {
                    return Json(new { success = false, message = "Task not found" });
                }

                var yeniDurum = model.YeniDurum.Trim();
                if (yeniDurum is not ("Beklemede" or "Aktif" or "Tamamlandı"))
                    return Json(new { success = false, message = "Geçersiz durum." });

                task.Durum = yeniDurum;
                _context.SaveChanges();

                return Json(new { success = true, message = "Status updated" });
            }
            catch (Exception)
            {
                return Json(new { success = false, message = "İşlem sırasında beklenmeyen bir hata oluştu." });
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,OperasyonSuperAdmin,Operasyon Süper Admin,Operasyon Super Admin")]
        public JsonResult Delete([FromBody] DeleteModel model)
        {
            var task = _context.JiraTasks
                               .Include(t => t.Yorumlar)
                               .FirstOrDefault(t => t.Id == model.Id);
            if (task == null)
                return Json(new { success = false, message = "Record was not found." });

            if (task.Yorumlar != null && task.Yorumlar.Any())
                _context.JiraYorumlar.RemoveRange(task.Yorumlar);

            _context.JiraTasks.Remove(task);
            _context.SaveChanges();

            return Json(new { success = true });
        }

        [HttpGet]
        public IActionResult DetailCard(int id)
        {
            var task = _context.JiraTasks
                               .Include(t => t.Yorumlar)
                               .FirstOrDefault(t => t.Id == id);

            if (task == null)
                return Content("<div class='text-danger small'>Record was not found.</div>", "text/html");

            return PartialView("_JiraDetailCard", task);
        }

        public class UpdateDurumModel
        {
            public int Id { get; set; }
            public string YeniDurum { get; set; }
        }

        public class DeleteModel
        {
            public int Id { get; set; }
        }
    }
}