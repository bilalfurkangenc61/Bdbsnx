using BtOperasyonTakip.Data;
using BtOperasyonTakip.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Data.Common;

namespace BtOperasyonTakip.Controllers
{
    [Authorize(Roles = AppRoles.Admin)]
    public class DbTestController : Controller
    {
        private readonly AppDbContext _context;
          
        public DbTestController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("/Admin/DbTest")]
        public async Task<IActionResult> Index()
        {
            try
            {
                var connection = _context.Database.GetDbConnection();

                var canConnect = await _context.Database.CanConnectAsync();
                if (!canConnect)
                {
                    return Content(
                        "❌ VERİTABANI BAĞLANTISI BAŞARISIZ",
                        "text/plain; charset=utf-8");
                }

                var connectionWasClosed = connection.State != ConnectionState.Open;
                if (connectionWasClosed)
                {
                    await connection.OpenAsync();
                }

                try
                {
                    var musteriSayisi = await CountRows(connection, "dbo.Musteriler");
                    var userSayisi = await CountRows(connection, "dbo.Users");
                    var hataSayisi = await CountRows(connection, "dbo.Hatalar");

                    var selectPermission = await HasPermission(connection, "SELECT");
                    var insertPermission = await HasPermission(connection, "INSERT");
                    var updatePermission = await HasPermission(connection, "UPDATE");
                    var deletePermission = await HasPermission(connection, "DELETE");

                    var resultText = $"""
✅ VERİTABANI TESTİ BAŞARILI

SERVER:
{connection.DataSource}

DATABASE:
{connection.Database}

--------------------------------

MÜŞTERİ SAYISI:
{musteriSayisi}

KULLANICI SAYISI:
{userSayisi}

HATA SAYISI:
{hataSayisi}

--------------------------------

SQL YETKİLERİ

SELECT : {(selectPermission ? "✅ VAR" : "❌ YOK")}
INSERT : {(insertPermission ? "✅ VAR" : "❌ YOK")}
UPDATE : {(updatePermission ? "✅ VAR" : "❌ YOK")}
DELETE : {(deletePermission ? "✅ VAR" : "❌ YOK")}

--------------------------------

EF CORE:
✅ ÇALIŞIYOR

MIGRATION:
KULLANILMIYOR

MEVCUT TABLOLARDAN VERİ OKUMA:
✅ ÇALIŞIYOR

KAYIT EKLEME YETKİSİ:
{(insertPermission ? "✅ VAR" : "❌ YOK")}

Bu test hiçbir kayıt oluşturmadı,
değiştirmedi veya silmedi.
""";

                    return Content(
                        resultText,
                        "text/plain; charset=utf-8");
                }
                finally
                {
                    if (connectionWasClosed && connection.State == ConnectionState.Open)
                    {
                        await connection.CloseAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                var error = $"""
❌ VERİTABANI TESTİ BAŞARISIZ

HATA:
{ex.Message}

DETAY:
{ex}
""";

                return Content(
                    error,
                    "text/plain; charset=utf-8");
            }
        }

        private static async Task<long> CountRows(
            DbConnection connection,
            string tableName)
        {
            await using var command = connection.CreateCommand();
            command.CommandText = $"SELECT COUNT_BIG(*) FROM {tableName};";

            var result = await command.ExecuteScalarAsync();

            return result == null || result == DBNull.Value
                ? 0
                : Convert.ToInt64(result);
        }

        private static async Task<bool> HasPermission(
            DbConnection connection,
            string permission)
        {
            await using var command = connection.CreateCommand();

            command.CommandText = @"
SELECT HAS_PERMS_BY_NAME(
    'dbo.Musteriler',
    'OBJECT',
    @Permission
);";

            var parameter = command.CreateParameter();
            parameter.ParameterName = "@Permission";
            parameter.Value = permission;
            command.Parameters.Add(parameter);

            var result = await command.ExecuteScalarAsync();

            return result != null
                   && result != DBNull.Value
                   && Convert.ToInt32(result) == 1;
        }
    }
}
