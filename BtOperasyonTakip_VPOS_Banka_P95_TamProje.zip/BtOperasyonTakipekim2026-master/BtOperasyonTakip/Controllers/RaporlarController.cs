﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.Text;

namespace BtOperasyonTakip.Controllers
{
    [Authorize(Roles = AppRoles.Admin + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin")]
    public class RaporlarController : Controller
    {
        private readonly AppDbContext _context;

        public RaporlarController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index(int? yil, int? ay)
        {
            var culture = CultureInfo.GetCultureInfo("en-US");
            var now = DateTime.Now;

            var tasks = _context.JiraTasks
                .AsNoTracking()
                .ToList();

            var yillar = tasks
                .Select(x => x.OlusturmaTarihi.Year)
                .Distinct()
                .OrderByDescending(x => x)
                .ToList();

            if (!yillar.Contains(now.Year))
                yillar.Insert(0, now.Year);

            var seciliYil = yil.HasValue && yillar.Contains(yil.Value)
                ? yil.Value
                : now.Year;

            var seciliAy = ay.HasValue && ay.Value >= 1 && ay.Value <= 12
                ? ay.Value
                : 0;

            var rapor = BuildYearReport(tasks, seciliYil, culture);

            var seciliDonemIsleri = tasks
                .Where(x => x.OlusturmaTarihi.Year == seciliYil)
                .Where(x => seciliAy == 0 || x.OlusturmaTarihi.Month == seciliAy)
                .ToList();

            var kisiDagilimi = BuildPersonDistribution(seciliDonemIsleri);

            
            var aktifIsler = tasks
                .Where(x => AktifMi(x.Durum))
                .ToList();

            var aktifKisiDagilimi = BuildPersonDistribution(aktifIsler);

            ViewBag.Yillar = yillar;
            ViewBag.SeciliYil = seciliYil;
            ViewBag.SeciliAy = seciliAy;
            ViewBag.AyEtiketleri = rapor.AyEtiketleri;
            ViewBag.OperasyonIsleri = rapor.OperasyonIsleri;
            ViewBag.EntegreOlunamayanlar = rapor.EntegreOlunamayanlar;
            ViewBag.ToplamOperasyonIsi = rapor.ToplamOperasyonIsi;
            ViewBag.ToplamEntegreOlunamayan = rapor.ToplamEntegreOlunamayan;
            ViewBag.EntegreOlunamamaOrani = rapor.EntegreOlunamamaOrani;
            ViewBag.EnYogunAy = rapor.EnYogunAy;
            ViewBag.EnYogunAyIsSayisi = rapor.EnYogunAyIsSayisi;

            ViewBag.SeciliDonemBaslik = seciliAy == 0
                ? $"{seciliYil} Full Year"
                : $"{culture.DateTimeFormat.GetMonthName(seciliAy)} {seciliYil}";
            ViewBag.SeciliDonemToplam = seciliDonemIsleri.Count;
            ViewBag.KisiAdlari = kisiDagilimi.Select(x => x.Kisi).ToList();
            ViewBag.KisiIsSayilari = kisiDagilimi.Select(x => x.IsSayisi).ToList();
            ViewBag.KisiYuzdeleri = kisiDagilimi.Select(x => x.Yuzde).ToList();

            ViewBag.AktifToplam = aktifIsler.Count;
            ViewBag.AktifKisiAdlari = aktifKisiDagilimi.Select(x => x.Kisi).ToList();
            ViewBag.AktifKisiIsSayilari = aktifKisiDagilimi.Select(x => x.IsSayisi).ToList();
            ViewBag.AktifKisiYuzdeleri = aktifKisiDagilimi.Select(x => x.Yuzde).ToList();

            return View();
        }

        [HttpGet]
        public IActionResult ExportExcel(int? yil)
        {
            var culture = CultureInfo.GetCultureInfo("en-US");
            var now = DateTime.Now;

            var tasks = _context.JiraTasks
                .AsNoTracking()
                .ToList();

            var availableYears = tasks
                .Select(x => x.OlusturmaTarihi.Year)
                .Distinct()
                .ToList();

            var selectedYear = yil.HasValue && (availableYears.Contains(yil.Value) || yil.Value == now.Year)
                ? yil.Value
                : now.Year;

            var report = BuildYearReport(tasks, selectedYear, culture);

            using var ms = new MemoryStream();

            using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
            {
                var workbookPart = document.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
                stylesPart.Stylesheet = CreateExcelStylesheet();
                stylesPart.Stylesheet.Save();

                var sheets = workbookPart.Workbook.AppendChild(new Sheets());

                AddMonthlySummarySheet(workbookPart, sheets, report, selectedYear, 1U);
                AddMonthlyPersonDistributionSheet(workbookPart, sheets, tasks, selectedYear, culture, 2U);
                AddCurrentActiveWorkloadSheet(workbookPart, sheets, tasks, 3U);

                workbookPart.Workbook.Save();
            }

            return File(
                ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"Operasyon_Raporu_{selectedYear}_Tum_Aylar.xlsx"
            );
        }

        private static void AddMonthlySummarySheet(
            WorkbookPart workbookPart,
            Sheets sheets,
            YearReport report,
            int selectedYear,
            uint sheetId)
        {
            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var sheetData = new SheetData();
            var worksheet = new Worksheet();

            worksheet.Append(new Columns(
                CreateColumn(1, 1, 22),
                CreateColumn(2, 3, 24),
                CreateColumn(4, 4, 24)
            ));
            worksheet.Append(sheetData);

            uint rowIndex = 1;
            var header = new Row { RowIndex = rowIndex };
            header.Append(
                CreateTextCell("A", rowIndex, "Ay", 1),
                CreateTextCell("B", rowIndex, "Operasyona Açılan", 1),
                CreateTextCell("C", rowIndex, "Entegre Olunamayan", 1),
                CreateTextCell("D", rowIndex, "Entegre Olunamama Oranı", 1)
            );
            sheetData.Append(header);

            for (var i = 0; i < 12; i++)
            {
                rowIndex++;
                var total = report.OperasyonIsleri[i];
                var failed = report.EntegreOlunamayanlar[i];
                var rate = total <= 0 ? 0 : Math.Round((double)failed / total * 100, 1);

                var row = new Row { RowIndex = rowIndex };
                row.Append(
                    CreateTextCell("A", rowIndex, report.AyEtiketleri[i], 0),
                    CreateNumberCell("B", rowIndex, total, 0),
                    CreateNumberCell("C", rowIndex, failed, 0),
                    CreateTextCell("D", rowIndex, $"%{rate:0.0}", 0)
                );
                sheetData.Append(row);
            }

            rowIndex++;
            var totalRow = new Row { RowIndex = rowIndex };
            totalRow.Append(
                CreateTextCell("A", rowIndex, "TOPLAM", 1),
                CreateNumberCell("B", rowIndex, report.ToplamOperasyonIsi, 1),
                CreateNumberCell("C", rowIndex, report.ToplamEntegreOlunamayan, 1),
                CreateTextCell("D", rowIndex, $"%{report.EntegreOlunamamaOrani:0.0}", 1)
            );
            sheetData.Append(totalRow);

            worksheet.Append(new AutoFilter { Reference = $"A1:D{rowIndex}" });
            worksheetPart.Worksheet = worksheet;

            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = sheetId,
                Name = $"{selectedYear} Monthly Summary"
            });
        }

        private static void AddMonthlyPersonDistributionSheet(
            WorkbookPart workbookPart,
            Sheets sheets,
            IEnumerable<JiraTask> allTasks,
            int selectedYear,
            CultureInfo culture,
            uint sheetId)
        {
            var taskList = allTasks.ToList();
            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var sheetData = new SheetData();
            var worksheet = new Worksheet();

            worksheet.Append(new Columns(
                CreateColumn(1, 1, 18),
                CreateColumn(2, 2, 28),
                CreateColumn(3, 3, 18),
                CreateColumn(4, 4, 18),
                CreateColumn(5, 5, 22)
            ));
            worksheet.Append(sheetData);

            uint rowIndex = 1;
            var header = new Row { RowIndex = rowIndex };
            header.Append(
                CreateTextCell("A", rowIndex, "Ay", 1),
                CreateTextCell("B", rowIndex, "Operasyon Personeli", 1),
                CreateTextCell("C", rowIndex, "Kişideki İş", 1),
                CreateTextCell("D", rowIndex, "Ay Toplamı", 1),
                CreateTextCell("E", rowIndex, "İş Yükü Payı", 1)
            );
            sheetData.Append(header);

            for (var month = 1; month <= 12; month++)
            {
                var monthTasks = taskList
                    .Where(x => x.OlusturmaTarihi.Year == selectedYear && x.OlusturmaTarihi.Month == month)
                    .ToList();

                var distribution = BuildPersonDistribution(monthTasks);
                var monthName = culture.DateTimeFormat.GetMonthName(month);

                if (distribution.Count == 0)
                {
                    rowIndex++;
                    var emptyRow = new Row { RowIndex = rowIndex };
                    emptyRow.Append(
                        CreateTextCell("A", rowIndex, monthName, 0),
                        CreateTextCell("B", rowIndex, "-", 0),
                        CreateNumberCell("C", rowIndex, 0, 0),
                        CreateNumberCell("D", rowIndex, 0, 0),
                        CreateTextCell("E", rowIndex, "%0.0", 0)
                    );
                    sheetData.Append(emptyRow);
                    continue;
                }

                foreach (var person in distribution)
                {
                    rowIndex++;
                    var row = new Row { RowIndex = rowIndex };
                    row.Append(
                        CreateTextCell("A", rowIndex, monthName, 0),
                        CreateTextCell("B", rowIndex, person.Kisi, 0),
                        CreateNumberCell("C", rowIndex, person.IsSayisi, 0),
                        CreateNumberCell("D", rowIndex, monthTasks.Count, 0),
                        CreateTextCell("E", rowIndex, $"%{person.Yuzde:0.0}", 0)
                    );
                    sheetData.Append(row);
                }
            }

            worksheet.Append(new AutoFilter { Reference = $"A1:E{rowIndex}" });
            worksheetPart.Worksheet = worksheet;

            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = sheetId,
                Name = "Ay-Kişi Dağılımı"
            });
        }

        private static void AddCurrentActiveWorkloadSheet(
            WorkbookPart workbookPart,
            Sheets sheets,
            IEnumerable<JiraTask> allTasks,
            uint sheetId)
        {
            var activeTasks = allTasks
                .Where(x => AktifMi(x.Durum))
                .ToList();

            var distribution = BuildPersonDistribution(activeTasks);

            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var sheetData = new SheetData();
            var worksheet = new Worksheet();

            worksheet.Append(new Columns(
                CreateColumn(1, 1, 30),
                CreateColumn(2, 2, 18),
                CreateColumn(3, 3, 20)
            ));
            worksheet.Append(sheetData);

            uint rowIndex = 1;
            var header = new Row { RowIndex = rowIndex };
            header.Append(
                CreateTextCell("A", rowIndex, "Operasyon Personeli", 1),
                CreateTextCell("B", rowIndex, "Aktif İş", 1),
                CreateTextCell("C", rowIndex, "Güncel Yük Payı", 1)
            );
            sheetData.Append(header);

            if (distribution.Count == 0)
            {
                rowIndex++;
                var emptyRow = new Row { RowIndex = rowIndex };
                emptyRow.Append(
                    CreateTextCell("A", rowIndex, "-", 0),
                    CreateNumberCell("B", rowIndex, 0, 0),
                    CreateTextCell("C", rowIndex, "%0.0", 0)
                );
                sheetData.Append(emptyRow);
            }
            else
            {
                foreach (var person in distribution)
                {
                    rowIndex++;
                    var row = new Row { RowIndex = rowIndex };
                    row.Append(
                        CreateTextCell("A", rowIndex, person.Kisi, 0),
                        CreateNumberCell("B", rowIndex, person.IsSayisi, 0),
                        CreateTextCell("C", rowIndex, $"%{person.Yuzde:0.0}", 0)
                    );
                    sheetData.Append(row);
                }
            }

            worksheet.Append(new AutoFilter { Reference = $"A1:C{rowIndex}" });
            worksheetPart.Worksheet = worksheet;

            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = sheetId,
                Name = "Güncel Aktif Yük"
            });
        }

        private static YearReport BuildYearReport(IEnumerable<JiraTask> tasks, int year, CultureInfo culture)
        {
            var taskList = tasks.ToList();
            var ayEtiketleri = new List<string>(12);
            var operasyonIsleri = new List<int>(12);
            var entegreOlunamayanlar = new List<int>(12);

            for (var month = 1; month <= 12; month++)
            {
                var ayTasks = taskList
                    .Where(x => x.OlusturmaTarihi.Year == year && x.OlusturmaTarihi.Month == month)
                    .ToList();

                ayEtiketleri.Add(culture.DateTimeFormat.GetMonthName(month));
                operasyonIsleri.Add(ayTasks.Count);
                entegreOlunamayanlar.Add(ayTasks.Count(x => EntegrasyonTamamlanmadiMi(x.Durum)));
            }

            var toplamOperasyonIsi = operasyonIsleri.Sum();
            var toplamEntegreOlunamayan = entegreOlunamayanlar.Sum();
            var entegreOlunamamaOrani = toplamOperasyonIsi <= 0
                ? 0
                : Math.Round((double)toplamEntegreOlunamayan / toplamOperasyonIsi * 100, 1);

            var enYogunAyIndex = operasyonIsleri.Max() > 0
                ? operasyonIsleri.IndexOf(operasyonIsleri.Max())
                : -1;

            return new YearReport(
                ayEtiketleri,
                operasyonIsleri,
                entegreOlunamayanlar,
                toplamOperasyonIsi,
                toplamEntegreOlunamayan,
                entegreOlunamamaOrani,
                enYogunAyIndex >= 0 ? ayEtiketleri[enYogunAyIndex] : "-",
                enYogunAyIndex >= 0 ? operasyonIsleri[enYogunAyIndex] : 0
            );
        }

        private static List<PersonWorkload> BuildPersonDistribution(IEnumerable<JiraTask> tasks)
        {
            var taskList = tasks.ToList();
            var total = taskList.Count;

            if (total == 0)
                return new List<PersonWorkload>();

            return taskList
                .GroupBy(
                    x => string.IsNullOrWhiteSpace(x.TakipEden) ? "Atanmamış" : x.TakipEden!.Trim(),
                    StringComparer.OrdinalIgnoreCase)
                .Select(g => new PersonWorkload(
                    g.Key,
                    g.Count(),
                    Math.Round((double)g.Count() / total * 100, 1)))
                .OrderByDescending(x => x.IsSayisi)
                .ThenBy(x => x.Kisi)
                .ToList();
        }

        private static bool AktifMi(string? durum)
        {
            return Normalize(durum) == Normalize("Aktif");
        }

        private static bool EntegrasyonTamamlanmadiMi(string? durum)
        {
            var d = Normalize(durum);
            return d == Normalize("Entegrasyon Tamamlanmadı") ||
                   d == Normalize("Entegrasyon Tamamlanmadi") ||
                   d == Normalize("Entegrasyon Başarısız") ||
                   d == Normalize("Entegrasyon Basarisiz");
        }

        private static string Normalize(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            var normalized = value.Trim().Normalize(NormalizationForm.FormD);
            var chars = normalized
                .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                .ToArray();

            return new string(chars)
                .Normalize(NormalizationForm.FormC)
                .Replace("ı", "i")
                .Replace("İ", "i")
                .ToUpperInvariant()
                .Replace(" ", string.Empty)
                .Replace("-", string.Empty)
                .Replace("_", string.Empty);
        }

        private static Column CreateColumn(uint min, uint max, double width)
        {
            return new Column
            {
                Min = min,
                Max = max,
                Width = width,
                CustomWidth = true
            };
        }

        private static Cell CreateTextCell(string column, uint row, string? text, uint styleIndex)
        {
            return new Cell
            {
                CellReference = column + row,
                DataType = CellValues.InlineString,
                StyleIndex = styleIndex,
                InlineString = new InlineString(new Text(text ?? string.Empty))
            };
        }

        private static Cell CreateNumberCell(string column, uint row, int value, uint styleIndex)
        {
            return new Cell
            {
                CellReference = column + row,
                CellValue = new CellValue(value.ToString(CultureInfo.InvariantCulture)),
                DataType = CellValues.Number,
                StyleIndex = styleIndex
            };
        }

        private static Stylesheet CreateExcelStylesheet()
        {
            return new Stylesheet(
                new Fonts(
                    new Font(new FontSize { Val = 11 }),
                    new Font(
                        new Bold(),
                        new FontSize { Val = 11 },
                        new Color { Rgb = HexBinaryValue.FromString("FFFFFFFF") }
                    )
                ),
                new Fills(
                    new Fill(new PatternFill { PatternType = PatternValues.None }),
                    new Fill(new PatternFill { PatternType = PatternValues.Gray125 }),
                    new Fill(new PatternFill(
                        new ForegroundColor { Rgb = HexBinaryValue.FromString("1D4ED8") },
                        new BackgroundColor { Indexed = 64U }
                    ) { PatternType = PatternValues.Solid })
                ),
                new Borders(
                    new Border(
                        new LeftBorder(),
                        new RightBorder(),
                        new TopBorder(),
                        new BottomBorder(),
                        new DiagonalBorder()
                    ),
                    new Border(
                        new LeftBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                        new RightBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                        new TopBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                        new BottomBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                        new DiagonalBorder()
                    )
                ),
                new CellFormats(
                    new CellFormat(),
                    new CellFormat
                    {
                        FontId = 1U,
                        FillId = 2U,
                        BorderId = 1U,
                        ApplyFont = true,
                        ApplyFill = true,
                        ApplyBorder = true,
                        Alignment = new Alignment
                        {
                            Horizontal = HorizontalAlignmentValues.Center,
                            Vertical = VerticalAlignmentValues.Center,
                            WrapText = true
                        },
                        ApplyAlignment = true
                    }
                )
            );
        }

        private sealed record YearReport(
            List<string> AyEtiketleri,
            List<int> OperasyonIsleri,
            List<int> EntegreOlunamayanlar,
            int ToplamOperasyonIsi,
            int ToplamEntegreOlunamayan,
            double EntegreOlunamamaOrani,
            string EnYogunAy,
            int EnYogunAyIsSayisi
        );

        private sealed record PersonWorkload(
            string Kisi,
            int IsSayisi,
            double Yuzde
        );
    }
}
