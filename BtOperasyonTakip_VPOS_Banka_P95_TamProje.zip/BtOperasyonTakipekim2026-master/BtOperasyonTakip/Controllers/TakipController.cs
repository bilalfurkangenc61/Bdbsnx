﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Services;
using BtOperasyonTakip.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.EntityFrameworkCore;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Globalization;
using System.Text.RegularExpressions;

namespace BtOperasyonTakip.Controllers
{
    [Authorize]
    public class TakipController : Controller
    {
        private readonly AppDbContext _context;
        private readonly BildirimStore _bildirimStore;

        private static readonly string[] AllowedTalepTurleri = ["Geliştirme", "Eğitim", "Entegrasyon", "Hata Çözüm"];
        private static readonly string[] ExcelDisiTalepTurleri = ["Geliştirme", "Eğitim"];
        
        
        
        private const string UyumOnayindaDurum = "Uyum Onayında";
        private const string EntegrasyonTamamlanmadiDurum = "Entegrasyon Tamamlanmadı";
        private const string DokumanIletildiDurum = "Döküman İletildi";

        private static readonly string[] TakipAnaDurumlar =
        [
            "Beklemede",
            "Aktif",
            "Döküman İletildi",
            "Satışa Bilgi Verildi"
        ];

        
        
        
        private static readonly string[] TakipSecilebilirDurumlar =
        [
            "Beklemede",
            "Aktif",
            "Döküman İletildi",
            "Satışa Bilgi Verildi",
            "Entegrasyon Tamamlandı",
            EntegrasyonTamamlanmadiDurum,
            UyumOnayindaDurum
        ];
        private const string LegacyTalepTuru = "Detay Kaydı";
        private const int DefaultPageSize = 10;
        private const int MaxPageSize = 100;
        private const string OperasyonYorumPrefix = "[OPERASYON] ";
        private const string SahaYorumPrefix = "[SAHA] ";
        private const string VposTaskPrefix = "[VPOS] ";
        private const string MobilTaskPrefix = "[MOBIL] ";
        private const string OperasyonCustomerParamType = "UrunMusteri:OPERASYON";
        private const string VposCustomerParamType = "UrunMusteri:VPOS";
        private const string MobilCustomerParamType = "UrunMusteri:MOBIL";
        private const string ProductConfiguredParamType = "UrunMusteri:YAPILANDIRILDI";

        public TakipController(AppDbContext context)
        {
            _context = context;
            _bildirimStore = new BildirimStore(context);
        }

        private static string NormalizeUrun(string? urun)
        {
            var value = (urun ?? string.Empty).Trim().ToUpperInvariant();
            return value is "VPOS" or "MOBIL" ? value : "OPERASYON";
        }

        private static string GetTaskPrefix(string? urun) => NormalizeUrun(urun) switch
        {
            "VPOS" => VposTaskPrefix,
            "MOBIL" => MobilTaskPrefix,
            _ => string.Empty
        };

        private static bool IsTaskForUrun(JiraTask task, string? urun)
        {
            var konu = task.TalepKonusu ?? string.Empty;
            return NormalizeUrun(urun) switch
            {
                "VPOS" => konu.StartsWith(VposTaskPrefix, StringComparison.OrdinalIgnoreCase),
                "MOBIL" => konu.StartsWith(MobilTaskPrefix, StringComparison.OrdinalIgnoreCase),
                _ => !konu.StartsWith(VposTaskPrefix, StringComparison.OrdinalIgnoreCase) &&
                     !konu.StartsWith(MobilTaskPrefix, StringComparison.OrdinalIgnoreCase)
            };
        }

        private HashSet<int> GetRawUrunMusteriIds(string tur)
        {
            return _context.Parametreler.AsNoTracking()
                .Where(x => x.Tur == tur && x.ParAdi != null)
                .Select(x => x.ParAdi!)
                .ToList()
                .Select(x => int.TryParse(x, out var id) ? id : 0)
                .Where(x => x > 0)
                .ToHashSet();
        }

        private HashSet<int> GetUrunMusteriIds(string urun)
        {
            var normalized = NormalizeUrun(urun);
            if (normalized == "VPOS") return GetRawUrunMusteriIds(VposCustomerParamType);
            if (normalized == "MOBIL") return GetRawUrunMusteriIds(MobilCustomerParamType);

            var configuredIds = GetRawUrunMusteriIds(ProductConfiguredParamType);
            var explicitOperasyonIds = GetRawUrunMusteriIds(OperasyonCustomerParamType);
            var result = _context.Musteriler.AsNoTracking().Select(x => x.MusteriID).ToHashSet();

            
            result.RemoveWhere(id => configuredIds.Contains(id) && !explicitOperasyonIds.Contains(id));
            return result;
        }

        private static IQueryable<JiraTask> ApplyUrunTaskFilter(IQueryable<JiraTask> query, string? urun)
        {
            return NormalizeUrun(urun) switch
            {
                "VPOS" => query.Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(VposTaskPrefix)),
                "MOBIL" => query.Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(MobilTaskPrefix)),
                _ => query.Where(x => x.TalepKonusu == null ||
                    (!x.TalepKonusu.StartsWith(VposTaskPrefix) && !x.TalepKonusu.StartsWith(MobilTaskPrefix)))
            };
        }

        private static string CleanTaskSubject(string? subject)
        {
            var value = (subject ?? string.Empty).Trim();
            if (value.StartsWith(VposTaskPrefix, StringComparison.OrdinalIgnoreCase)) return value[VposTaskPrefix.Length..].Trim();
            if (value.StartsWith(MobilTaskPrefix, StringComparison.OrdinalIgnoreCase)) return value[MobilTaskPrefix.Length..].Trim();
            return value;
        }

        private static bool IsEnglishExport(string? lang) =>
            string.IsNullOrWhiteSpace(lang) || lang.StartsWith("en", StringComparison.OrdinalIgnoreCase);

        private static string L(bool isEn, string tr, string en) => isEn ? en : tr;

        private static string TranslateExportValue(string? value, bool isEn)
        {
            if (!isEn || string.IsNullOrWhiteSpace(value))
                return value ?? string.Empty;

            return value.Trim() switch
            {
                "Beklemede" => "Pending",
                "Aktif" => "Active",
                "Pasif" => "Inactive",
                "Tamamlandı" => "Completed",
                "Döküman İletildi" => "Document Sent",
                "Doküman İletildi" => "Document Sent",
                "Dokuman İletildi" => "Document Sent",
                "Satışa Bilgi Verildi" => "Sales Informed",
                "Entegrasyon Tamamlandı" => "Integration Completed",
                "Canlıda Entegrasyon Tamamlandı" => "Live Integration Completed",
                EntegrasyonTamamlanmadiDurum => "Integration Not Completed",
                UyumOnayindaDurum => "Compliance Approval",
                "Geliştirme" => "Development",
                "Eğitim" => "Training",
                "Entegrasyon" => "Integration",
                "Hata Çözüm" => "Issue Resolution",
                _ => value
            };
        }

        private IActionResult RedirectToLocalOrIndex(string? returnUrl, object? routeValues = null)
        {
            if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
                return LocalRedirect(returnUrl);

            return RedirectToAction(nameof(Index), routeValues);
        }

        private string? RemoveQueryParametersFromLocalUrl(string? returnUrl, params string[] parameterNames)
        {
            if (string.IsNullOrWhiteSpace(returnUrl) || !Url.IsLocalUrl(returnUrl) || parameterNames == null || parameterNames.Length == 0)
                return returnUrl;

            var hashIndex = returnUrl.IndexOf('#');
            var hashPart = hashIndex >= 0 ? returnUrl[hashIndex..] : string.Empty;
            var pathAndQuery = hashIndex >= 0 ? returnUrl[..hashIndex] : returnUrl;

            var queryIndex = pathAndQuery.IndexOf('?');
            if (queryIndex < 0)
                return returnUrl;

            var path = pathAndQuery[..queryIndex];
            var query = QueryHelpers.ParseQuery(pathAndQuery[queryIndex..]);
            var filteredQuery = query
                .Where(x => !parameterNames.Contains(x.Key, StringComparer.OrdinalIgnoreCase))
                .SelectMany(x => x.Value, (x, value) => new KeyValuePair<string, string?>(x.Key, value));

            var newQueryString = QueryString.Create(filteredQuery).ToString();
            return $"{path}{newQueryString}{hashPart}";
        }

        private List<string> GetKullaniciSecenekleri()
        {
            return _context.Users
                .AsNoTracking()
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct()
                .OrderBy(x => x)
                .ToList();
        }

        private List<string> GetOperasyonKullaniciSecenekleri()
        {
            
            
            
            
            
            var takipEdenRolleri = new[]
            {
                AppRoles.Operasyon,
                AppRoles.OperasyonSuperAdmin,
                "Operasyon Süper Admin",
                "Operasyon Super Admin",
                "Admin",
                "Saha",
                AppRoles.SahaSuperAdmin,
                "KurumsalSaha",
                "Kurumsal Saha"
            };

            var kullanicilar = _context.Users
                .AsNoTracking()
                .Where(x => x.Role != null && takipEdenRolleri.Contains(x.Role))
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .ToList();

            var parametreler = _context.Parametreler
                .AsNoTracking()
                .Where(x =>
                    x.ParAdi != null &&
                    x.ParAdi != "" &&
                    (
                        x.Tur == "TakipEden" ||
                        x.Tur == "Takip Eden" ||
                        x.Tur == "OperasyonKullanici" ||
                        x.Tur == "Operasyon Kullanıcı" ||
                        x.Tur == "Saha" ||
                        x.Tur == "SahaSorumlusu" ||
                        x.Tur == "Saha Sorumlusu"
                    ))
                .Select(x => x.ParAdi!)
                .ToList();

            var atanmisKisiler = _context.JiraTasks
                .AsNoTracking()
                .Where(x => x.TakipEden != null && x.TakipEden != "")
                .Select(x => x.TakipEden!)
                .ToList();

            return kullanicilar
                .Concat(parametreler)
                .Concat(atanmisKisiler)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => x)
                .ToList();
        }

        private List<string> GetAtanabilirOperasyonKullanicilari()
        {
            return _context.Users
                .AsNoTracking()
                .Where(x => x.Role == AppRoles.Operasyon ||
                            x.Role == AppRoles.OperasyonSuperAdmin ||
                            x.Role == "Operasyon Süper Admin" ||
                            x.Role == "Operasyon Super Admin")
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct()
                .OrderBy(x => x)
                .ToList();
        }

        private List<string> GetSahaIndexKisiSecenekleri(IEnumerable<JiraTask> tasks)
        {
            
            
            var sahaVaryantlari = GetAllSahaUserNameVariants();

            var sahaKullanicilari = _context.Users
                .AsNoTracking()
                .Select(x => new { x.UserName, x.FullName, x.Role })
                .ToList()
                .Where(x => IsSahaRole(x.Role) || IsSahaSuperAdminRole(x.Role))
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .ToList();

            var sahaParametreleri = _context.Parametreler
                .AsNoTracking()
                .Where(x => x.ParAdi != null && x.ParAdi != "")
                .Select(x => new { x.ParAdi, x.Tur })
                .ToList()
                .Where(x =>
                    string.Equals((x.Tur ?? string.Empty).Trim(), "Saha", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "SahaSorumlusu", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "Saha Sorumlusu", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "KurumsalSaha", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "Kurumsal Saha", StringComparison.OrdinalIgnoreCase))
                .Select(x => x.ParAdi!)
                .ToList();

            var taskSahaKisileri = tasks
                .Where(x => sahaVaryantlari.Any(v => PersonNameMatches(x.TakipEden, v)))
                .Select(x => x.TakipEden)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x!.Trim())
                .ToList();

            return sahaKullanicilari
                .Concat(sahaParametreleri)
                .Concat(taskSahaKisileri)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => x)
                .ToList();
        }

        private static bool IsSahaRole(string? role)
        {
            role = (role ?? string.Empty).Trim();

            return string.Equals(role, "Saha", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "KurumsalSaha", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Kurumsal Saha", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsSahaSuperAdminRole(string? role)
        {
            role = (role ?? string.Empty).Trim();

            return string.Equals(role, AppRoles.SahaSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsOperasyonSuperAdminRole(string? role)
        {
            role = (role ?? string.Empty).Trim();

            return string.Equals(role, AppRoles.OperasyonSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Operasyon Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Operasyon Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private string? GetCurrentUserDbRole()
        {
            var identityName = (User.Identity?.Name ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(identityName))
                return null;

            return _context.Users
                .AsNoTracking()
                .Where(x => x.UserName == identityName || x.Email == identityName)
                .Select(x => x.Role)
                .FirstOrDefault();
        }

        private bool IsOperasyonKullanici()
        {
            var dbRole = GetCurrentUserDbRole();

            return User.IsInRole(AppRoles.Operasyon) ||
                   User.IsInRole(AppRoles.OperasyonSuperAdmin) ||
                   User.IsInRole("Operasyon Süper Admin") ||
                   User.IsInRole("Operasyon Super Admin") ||
                   string.Equals(dbRole, AppRoles.Operasyon, StringComparison.OrdinalIgnoreCase) ||
                   IsOperasyonSuperAdminRole(dbRole);
        }

        private bool IsOperasyonSuperAdminKullanici()
        {
            var dbRole = GetCurrentUserDbRole();

            return User.IsInRole(AppRoles.OperasyonSuperAdmin) ||
                   User.IsInRole("Operasyon Süper Admin") ||
                   User.IsInRole("Operasyon Super Admin") ||
                   IsOperasyonSuperAdminRole(dbRole);
        }

        private bool IsVposKullanici()
        {
            var dbRole = GetCurrentUserDbRole();
            return User.IsInRole(AppRoles.VposKullanici) ||
                   string.Equals(dbRole, AppRoles.VposKullanici, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(dbRole, "VPOS", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsSahaKullanici()
        {
            var dbRole = GetCurrentUserDbRole();

            
            
            if (User.IsInRole("Admin") ||
                User.IsInRole(AppRoles.Admin) ||
                IsOperasyonKullanici() ||
                IsSahaSuperAdminKullanici() ||
                string.Equals(dbRole, "Admin", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(dbRole, AppRoles.Admin, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            return User.IsInRole("Saha") ||
                   User.IsInRole("KurumsalSaha") ||
                   User.IsInRole("Kurumsal Saha") ||
                   IsSahaRole(dbRole);
        }

        private bool IsSahaSuperAdminKullanici()
        {
            var dbRole = GetCurrentUserDbRole();

            return User.IsInRole(AppRoles.SahaSuperAdmin) ||
                   User.IsInRole("Saha Süper Admin") ||
                   User.IsInRole("Saha Super Admin") ||
                   IsSahaSuperAdminRole(dbRole);
        }

        private List<string> GetAllSahaUserNameVariants()
        {
            
            
            var sahaUsers = _context.Users
                .AsNoTracking()
                .Select(x => new { x.UserName, x.Email, x.FullName, x.Role })
                .ToList()
                .Where(x => IsSahaRole(x.Role) || IsSahaSuperAdminRole(x.Role))
                .ToList();

            var sahaParametreleri = _context.Parametreler
                .AsNoTracking()
                .Where(x => x.ParAdi != null && x.ParAdi != "")
                .Select(x => new { x.ParAdi, x.Tur })
                .ToList()
                .Where(x =>
                    string.Equals((x.Tur ?? string.Empty).Trim(), "Saha", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "SahaSorumlusu", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "Saha Sorumlusu", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "KurumsalSaha", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals((x.Tur ?? string.Empty).Trim(), "Kurumsal Saha", StringComparison.OrdinalIgnoreCase))
                .Select(x => x.ParAdi!)
                .ToList();

            var result = new List<string>();

            foreach (var user in sahaUsers)
            {
                AddUserVariant(result, user.UserName);
                AddUserVariant(result, user.Email);
                AddUserVariant(result, user.FullName);
            }

            foreach (var sahaKisi in sahaParametreleri)
            {
                AddUserVariant(result, sahaKisi);
            }

            return result
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private static bool HasAssignedPerson(JiraTask task)
        {
            return !string.IsNullOrWhiteSpace((task.TakipEden ?? string.Empty).Trim());
        }

        private static void AddUserVariant(List<string> result, string? value)
        {
            value = (value ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(value))
                return;

            result.Add(value);

            var prefix = value.Contains('@')
                ? value.Split('@')[0]
                : value;

            if (!string.IsNullOrWhiteSpace(prefix))
                result.Add(prefix.Trim());
        }

        private string GetCurrentUserDisplayName()
        {
            var identityName = (User.Identity?.Name ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(identityName))
                return string.Empty;

            var displayName = _context.Users
                .AsNoTracking()
                .Where(x => x.UserName == identityName || x.Email == identityName)
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .FirstOrDefault();

            if (!string.IsNullOrWhiteSpace(displayName))
                return displayName.Trim();

            return identityName.Contains('@')
                ? identityName.Split('@')[0].Trim()
                : identityName;
        }

        private List<string> GetCurrentUserNameVariants()
        {
            var result = new List<string>();
            var identityName = (User.Identity?.Name ?? string.Empty).Trim();

            if (!string.IsNullOrWhiteSpace(identityName))
            {
                result.Add(identityName);

                var identityPrefix = identityName.Contains('@')
                    ? identityName.Split('@')[0]
                    : identityName;

                if (!string.IsNullOrWhiteSpace(identityPrefix))
                    result.Add(identityPrefix);
            }

            var appUser = _context.Users
                .AsNoTracking()
                .FirstOrDefault(x => x.UserName == identityName || x.Email == identityName);

            if (appUser != null)
            {
                if (!string.IsNullOrWhiteSpace(appUser.FullName))
                    result.Add(appUser.FullName.Trim());

                if (!string.IsNullOrWhiteSpace(appUser.UserName))
                {
                    result.Add(appUser.UserName.Trim());

                    var userNamePrefix = appUser.UserName.Contains('@')
                        ? appUser.UserName.Split('@')[0]
                        : appUser.UserName;

                    if (!string.IsNullOrWhiteSpace(userNamePrefix))
                        result.Add(userNamePrefix.Trim());
                }

                if (!string.IsNullOrWhiteSpace(appUser.Email))
                {
                    result.Add(appUser.Email.Trim());

                    var emailPrefix = appUser.Email.Contains('@')
                        ? appUser.Email.Split('@')[0]
                        : appUser.Email;

                    if (!string.IsNullOrWhiteSpace(emailPrefix))
                        result.Add(emailPrefix.Trim());
                }
            }

            return result
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private List<string> GetTalepAcanSecenekleri()
        {
            return _context.Users
                .AsNoTracking()
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Concat(
                    _context.Parametreler
                        .AsNoTracking()
                        .Where(x =>
                            (
                                x.Tur == "TalepSahibi" ||
                                x.Tur == "TalepEden" ||
                                x.Tur == "TalepAcan" ||
                                x.Tur == "Talep Açan" ||
                                x.Tur == "KimdenGeldi" ||
                                x.Tur == "Kimden Geldi"
                            ) &&
                            x.ParAdi != null &&
                            x.ParAdi != "")
                        .Select(x => x.ParAdi!.Trim()))
                .Concat(
                    _context.Musteriler
                        .AsNoTracking()
                        .Where(x => x.TalepSahibi != null && x.TalepSahibi != "")
                        .Select(x => x.TalepSahibi!.Trim()))
                .Distinct()
                .OrderBy(x => x)
                .ToList();
        }

        private static DateTime ResolveSelectedMonth(string? month)
        {
            if (!string.IsNullOrWhiteSpace(month) &&
                DateTime.TryParseExact(month.Trim(), "yyyy-MM", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedMonth))
            {
                return new DateTime(parsedMonth.Year, parsedMonth.Month, 1);
            }

            var now = DateTime.Now;
            return new DateTime(now.Year, now.Month, 1);
        }

        private List<DateTime> GetAvailableMonths(DateTime selectedMonth)
        {
            var taskMonths = _context.JiraTasks
                .AsNoTracking()
                .Select(x => x.OlusturmaTarihi)
                .ToList()
                .Select(x => new DateTime(x.Year, x.Month, 1));

            var commentMonths = _context.JiraYorumlar
                .AsNoTracking()
                .Select(x => x.Tarih)
                .ToList()
                .Select(x => new DateTime(x.Year, x.Month, 1));

            var detayMonths = _context.Detaylar
                .AsNoTracking()
                .Select(x => x.Tarih)
                .ToList()
                .Select(x => new DateTime(x.Year, x.Month, 1));

            var months = taskMonths
                .Concat(commentMonths)
                .Concat(detayMonths)
                .Distinct()
                .OrderByDescending(x => x)
                .ToList();

            if (!months.Any())
            {
                months.Add(selectedMonth);
            }
            else if (!months.Contains(selectedMonth))
            {
                months.Add(selectedMonth);
                months = months.OrderByDescending(x => x).ToList();
            }

            return months;
        }

        private static string NormalizeLookupText(string? value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? string.Empty
                : value.Trim().ToLowerInvariant();
        }

        private int? GetCurrentUserIdForNotification()
        {
            var claimValue = User.FindFirst("UserId")?.Value;
            if (int.TryParse(claimValue, out var claimUserId) && claimUserId > 0)
                return claimUserId;

            var identityName = (User.Identity?.Name ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(identityName))
                return null;

            return _context.Users
                .AsNoTracking()
                .Where(x => x.UserName == identityName || x.Email == identityName || x.FullName == identityName)
                .Select(x => (int?)x.Id)
                .FirstOrDefault();
        }

        private static bool IsAdminNotificationRole(User user)
        {
            var role = (user.Role ?? string.Empty).Trim();
            return string.Equals(user.UserName, "admin", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, AppRoles.Admin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, AppRoles.OperasyonSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Operasyon Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Operasyon Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsSahaSuperAdminNotificationRole(User user)
        {
            var role = (user.Role ?? string.Empty).Trim();
            return string.Equals(role, AppRoles.SahaSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsSahaNotificationRole(User user)
        {
            var role = (user.Role ?? string.Empty).Trim();
            return string.Equals(role, AppRoles.Saha, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, AppRoles.KurumsalSaha, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Kurumsal Saha", StringComparison.OrdinalIgnoreCase) ||
                   IsSahaSuperAdminNotificationRole(user);
        }

        private bool IsOperasyonVeyaAdminBildirimAktoru()
        {
            var dbRole = GetCurrentUserDbRole();

            return IsOperasyonKullanici() ||
                   User.IsInRole(AppRoles.Admin) ||
                   User.IsInRole("Admin") ||
                   string.Equals(dbRole, AppRoles.Admin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(dbRole, "Admin", StringComparison.OrdinalIgnoreCase);
        }

        private static bool UserMatchesAssignedValue(User user, string assignedValue)
        {
            var key = NormalizeLookupText(assignedValue);
            if (key == string.Empty)
                return false;

            static IEnumerable<string> Variants(string? value)
            {
                value = (value ?? string.Empty).Trim();
                if (value == string.Empty)
                    yield break;

                yield return value;
                if (value.Contains('@'))
                    yield return value.Split('@')[0];
            }

            
            
            
            
            return Variants(user.FullName)
                .Concat(Variants(user.UserName))
                .Concat(Variants(user.Email))
                .Any(x => NormalizeLookupText(x) == key || PersonNameMatches(x, assignedValue));
        }

        private static bool SahaUserCanSeeTask(User user, JiraTask task)
        {
            if (!IsSahaNotificationRole(user))
                return false;

            var variants = new[] { user.FullName, user.UserName, user.Email }
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x!.Trim())
                .ToList();

            return variants.Any(v =>
                PersonNameMatches(task.TakipEden, v) ||
                PersonNameMatches(task.TalepAcan, v));
        }

        private static string GetTaskNotificationName(JiraTask task)
        {
            if (!string.IsNullOrWhiteSpace(task.MusteriAdi))
                return task.MusteriAdi.Trim();

            if (!string.IsNullOrWhiteSpace(task.JiraId))
                return task.JiraId.Trim();

            if (!string.IsNullOrWhiteSpace(task.TalepKonusu))
                return task.TalepKonusu.Trim();

            return $"Work #{task.Id}";
        }

        private void AddTaskNotification(
            JiraTask task,
            string baslik,
            string mesaj,
            string tur,
            string onem = "Normal",
            bool sahaSuperAdminleriDahilEt = false)
        {
            if (task == null || task.Id <= 0)
                return;

            var actorUserId = GetCurrentUserIdForNotification();
            var actorName = GetCurrentUserDisplayName();
            if (string.IsNullOrWhiteSpace(actorName))
                actorName = User.Identity?.Name ?? "Sistem";

            var users = _context.Users.AsNoTracking().ToList();
            var recipientIds = new HashSet<int>();

            var assignedValue = (task.TakipEden ?? string.Empty).Trim();
            if (!string.IsNullOrWhiteSpace(assignedValue))
            {
                
                
                foreach (var assignedUser in users.Where(x => UserMatchesAssignedValue(x, assignedValue)))
                    recipientIds.Add(assignedUser.Id);
            }

            foreach (var admin in users.Where(IsAdminNotificationRole))
                recipientIds.Add(admin.Id);

            
            
            
            
            var operasyonVeyaAdminDegisikligi = IsOperasyonVeyaAdminBildirimAktoru();
            if (operasyonVeyaAdminDegisikligi)
            {
                foreach (var sahaUser in users.Where(u => SahaUserCanSeeTask(u, task)))
                    recipientIds.Add(sahaUser.Id);

                
                
                var jiraId = (task.JiraId ?? string.Empty).Trim();
                if (jiraId.StartsWith("TICKET-", StringComparison.OrdinalIgnoreCase) &&
                    int.TryParse(jiraId[7..], out var ticketId) &&
                    ticketId > 0)
                {
                    var sahaOlusturanUserId = _context.Tickets
                        .AsNoTracking()
                        .Where(t => t.Id == ticketId)
                        .Select(t => (int?)t.OlusturanUserId)
                        .FirstOrDefault();

                    if (sahaOlusturanUserId.HasValue && users.Any(u => u.Id == sahaOlusturanUserId.Value))
                        recipientIds.Add(sahaOlusturanUserId.Value);
                }
            }

            if (sahaSuperAdminleriDahilEt || operasyonVeyaAdminDegisikligi)
            {
                foreach (var sahaAdmin in users.Where(IsSahaSuperAdminNotificationRole))
                    recipientIds.Add(sahaAdmin.Id);
            }

            if (actorUserId.HasValue)
                recipientIds.Remove(actorUserId.Value);

            var now = DateTime.Now;
            foreach (var recipientId in recipientIds)
            {
                _bildirimStore.Ekle(new BildirimYeniKayit
                {
                    UserId = recipientId,
                    Baslik = baslik,
                    Mesaj = mesaj,
                    Tur = tur,
                    Onem = onem,
                    IlgiliVarlikTuru = "JiraTask",
                    IlgiliVarlikId = task.Id,
                    IslemiYapanUserId = actorUserId,
                    IslemiYapan = actorName,
                    OlusturmaTarihi = now
                });
            }
        }

        private static IReadOnlyList<int> GetTaskMusteriIds(
            JiraTask task,
            IReadOnlyDictionary<string, List<int>> musteriIdsByFirma)
        {
            if (task.MusteriID.HasValue && task.MusteriID.Value > 0)
            {
                return [task.MusteriID.Value];
            }

            var firmaKey = NormalizeLookupText(task.MusteriAdi);
            if (firmaKey != string.Empty && musteriIdsByFirma.TryGetValue(firmaKey, out var musteriIds))
            {
                return musteriIds;
            }

            return [];
        }

        private static Detay? GetLatestDetayForTask(
            IEnumerable<int> taskMusteriIds,
            IReadOnlyDictionary<int, Detay> detayByMusteri)
        {
            return taskMusteriIds
                .Where(detayByMusteri.ContainsKey)
                .Select(musteriId => detayByMusteri[musteriId])
                .OrderByDescending(x => x.Tarih)
                .ThenByDescending(x => x.DetayID)
                .FirstOrDefault();
        }

        private static bool IsTaskInSelectedMonth(
            JiraTask task,
            DateTime monthStart,
            DateTime nextMonthStart,
            IReadOnlyCollection<int> musteriIdsWithDetayInMonth,
            IReadOnlyCollection<int> taskMusteriIds)
        {
            if (taskMusteriIds.Any(musteriIdsWithDetayInMonth.Contains))
            {
                return true;
            }

            return (task.OlusturmaTarihi >= monthStart && task.OlusturmaTarihi < nextMonthStart) ||
                   (task.Yorumlar?.Any(y => y.Tarih >= monthStart && y.Tarih < nextMonthStart) ?? false);
        }

        private static bool IsArchiveDurum(string? durum)
        {
            var clean = (durum ?? string.Empty).Trim();
            return string.Equals(clean, "Arşiv", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(clean, "Arsiv", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsDokumanIletildiDurum(string? durum)
        {
            var clean = (durum ?? string.Empty).Trim();

            return string.Equals(clean, "Döküman İletildi", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(clean, "Doküman İletildi", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(clean, "Dokuman İletildi", StringComparison.OrdinalIgnoreCase);
        }

        private static string GetBoardColumnDurum(string? durum)
        {
            var clean = (durum ?? string.Empty).Trim();

            if (string.Equals(clean, UyumOnayindaDurum, StringComparison.OrdinalIgnoreCase))
                return "Beklemede";

            
            if (IsDokumanIletildiDurum(clean))
                return DokumanIletildiDurum;

            return clean;
        }

        private static bool IsTakipBoardVisibleStatus(string? durum)
        {
            var clean = (durum ?? string.Empty).Trim();

            if (IsArchiveDurum(clean) || string.Equals(clean, EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase))
                return false;

            var boardDurum = GetBoardColumnDurum(clean);
            return TakipAnaDurumlar.Contains(boardDurum, StringComparer.OrdinalIgnoreCase);
        }

        private static int GetStatusOrder(string? durum)
        {
            var boardDurum = GetBoardColumnDurum(durum);

            var index = Array.FindIndex(TakipAnaDurumlar, x =>
                string.Equals(x, boardDurum, StringComparison.OrdinalIgnoreCase));

            return index < 0 ? 999 : index;
        }

        private static DateTime GetTaskOrderDate(
            JiraTask task,
            IReadOnlyDictionary<int, Detay> latestDetailByMusteri,
            IReadOnlyCollection<int> taskMusteriIds)
        {
            var latestDetail = GetLatestDetayForTask(taskMusteriIds, latestDetailByMusteri);
            if (latestDetail != null)
            {
                return latestDetail.Tarih;
            }

            var latestCommentDate = task.Yorumlar?
                .Select(y => (DateTime?)y.Tarih)
                .Max();

            return latestCommentDate ?? task.OlusturmaTarihi;
        }

        private static bool MatchesTaskSearch(JiraTask task, string searchText, string? extraText = null)
        {
            if (string.IsNullOrWhiteSpace(searchText))
            {
                return true;
            }

            var qq = searchText.Trim().ToLowerInvariant();
            return (task.MusteriAdi ?? string.Empty).ToLowerInvariant().Contains(qq) ||
                   (task.TalepKonusu ?? string.Empty).ToLowerInvariant().Contains(qq) ||
                   (task.TalepAcan ?? string.Empty).ToLowerInvariant().Contains(qq) ||
                   (task.TakipEden ?? string.Empty).ToLowerInvariant().Contains(qq) ||
                   (task.Durum ?? string.Empty).ToLowerInvariant().Contains(qq) ||
                   (task.TalepTuru ?? string.Empty).ToLowerInvariant().Contains(qq) ||
                   (!string.IsNullOrWhiteSpace(extraText) && extraText.ToLowerInvariant().Contains(qq));
        }

        private static bool MatchesTaskKisi(JiraTask task, string kisi)
        {
            if (string.IsNullOrWhiteSpace(kisi))
            {
                return true;
            }

            
            
            
            return PersonNameMatches(task.TakipEden, kisi) ||
                   PersonNameMatches(task.TalepAcan, kisi);
        }

        private static bool MatchesTaskAnyKisi(JiraTask task, IEnumerable<string> kisiVaryantlari)
        {
            return kisiVaryantlari.Any(kisi =>
                !string.IsNullOrWhiteSpace(kisi) &&
                (
                    PersonNameMatches(task.TakipEden, kisi) ||
                    PersonNameMatches(task.TalepAcan, kisi)
                ));
        }


        private static bool MatchesTaskOpenedByAnySahaUser(JiraTask task, IEnumerable<string> sahaKisiVaryantlari)
        {
            
            
            
            return sahaKisiVaryantlari.Any(kisi =>
                !string.IsNullOrWhiteSpace(kisi) &&
                PersonNameMatches(task.TalepAcan, kisi));
        }

        private static bool MatchesTaskSahaGorunurIsleri(JiraTask task, IEnumerable<string> kisiVaryantlari)
        {
            
            
            return kisiVaryantlari.Any(kisi =>
                !string.IsNullOrWhiteSpace(kisi) &&
                (
                    PersonNameMatches(task.TakipEden, kisi) ||
                    PersonNameMatches(task.TalepAcan, kisi)
                ));
        }

        private static bool MatchesTaskAssignedToAnyVariant(JiraTask task, IEnumerable<string> kisiVaryantlari)
        {
            
            
            return kisiVaryantlari.Any(kisi =>
                !string.IsNullOrWhiteSpace(kisi) &&
                PersonNameMatches(task.TakipEden, kisi));
        }

        private static bool PersonNameMatches(string? left, string? right)
        {
            var leftKey = NormalizePersonKey(left);
            var rightKey = NormalizePersonKey(right);

            if (string.IsNullOrWhiteSpace(leftKey) || string.IsNullOrWhiteSpace(rightKey))
                return false;

            if (string.Equals(leftKey, rightKey, StringComparison.OrdinalIgnoreCase))
                return true;

            var leftTokens = leftKey
                .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Where(x => x.Length >= 3)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            var rightTokens = rightKey
                .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Where(x => x.Length >= 3)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            return leftTokens.Overlaps(rightTokens);
        }

        private static string NormalizePersonKey(string? value)
        {
            value = (value ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            value = value.Contains('@')
                ? value.Split('@')[0]
                : value;

            value = value
                .Replace("İ", "I")
                .Replace("ı", "i")
                .Replace("Ğ", "G")
                .Replace("ğ", "g")
                .Replace("Ü", "U")
                .Replace("ü", "u")
                .Replace("Ş", "S")
                .Replace("ş", "s")
                .Replace("Ö", "O")
                .Replace("ö", "o")
                .Replace("Ç", "C")
                .Replace("ç", "c")
                .ToLowerInvariant();

            value = Regex.Replace(value, @"[^a-z0-9]+", " ");
            value = Regex.Replace(value, @"\s+", " ").Trim();

            return value;
        }

        private static JiraTask CreateLegacyTask(Detay detay, string? musteriAdi, string? musteriDurumu)
        {
            var konu = string.IsNullOrWhiteSpace(detay.Gorusulen) ? LegacyTalepTuru : detay.Gorusulen.Trim();
            var kisi = (detay.Kekleyen ?? string.Empty).Trim();
            var durum = (musteriDurumu ?? string.Empty).Trim();

            return new JiraTask
            {
                Id = -detay.DetayID,
                MusteriID = detay.MusteriID,
                MusteriAdi = (musteriAdi ?? string.Empty).Trim(),
                JiraId = string.Empty,
                TalepKonusu = konu,
                TalepTuru = LegacyTalepTuru,
                TalepAcan = string.IsNullOrWhiteSpace(kisi) ? "-" : kisi,
                Durum = string.IsNullOrWhiteSpace(durum) ? "Aktif" : durum,
                TakipEden = kisi,
                OlusturmaTarihi = detay.Tarih,
                Yorumlar = new List<JiraYorum>()
            };
        }

        private static bool IsLegacyDetailCandidate(
            Detay detay,
            IReadOnlyCollection<JiraTask> tasks,
            IReadOnlyDictionary<int, IReadOnlyList<int>> taskMusteriIdsByTaskId)
        {
            var ekleyen = NormalizeLookupText(detay.Kekleyen);
            if (ekleyen == string.Empty || ekleyen == "sistem")
            {
                return false;
            }

            var gorusulen = NormalizeLookupText(detay.Gorusulen);
            if (gorusulen == "iş takip yorumu")
            {
                return false;
            }

            return !tasks.Any(task =>
            {
                if (!taskMusteriIdsByTaskId.TryGetValue(task.Id, out var musteriIds) || !musteriIds.Contains(detay.MusteriID))
                {
                    return false;
                }

                if (gorusulen == string.Empty)
                {
                    return true;
                }

                return NormalizeLookupText(task.TalepKonusu) == gorusulen;
            });
        }

        private static string PrefixYorum(string yorum, bool sahaYorumu)
        {
            yorum = (yorum ?? string.Empty).Trim();
            if (yorum.StartsWith(SahaYorumPrefix, StringComparison.OrdinalIgnoreCase) ||
                yorum.StartsWith(OperasyonYorumPrefix, StringComparison.OrdinalIgnoreCase))
            {
                return yorum;
            }

            return (sahaYorumu ? SahaYorumPrefix : OperasyonYorumPrefix) + yorum;
        }

        private void AddYorumVeMusteriDetay(JiraTask task, string yorum, string ekleyen)
        {
            var now = DateTime.Now;

            _context.JiraYorumlar.Add(new JiraYorum
            {
                JiraTaskId = task.Id,
                YorumMetni = yorum,
                Ekleyen = ekleyen,
                Tarih = now
            });

            if (task.MusteriID.HasValue && task.MusteriID.Value > 0)
            {
                _context.Detaylar.Add(new Detay
                {
                    MusteriID = task.MusteriID.Value,
                    Tarih = now,
                    Gorusulen = string.IsNullOrWhiteSpace(task.TalepKonusu) ? "İş Takip Yorumu" : task.TalepKonusu.Trim(),
                    Aciklama = yorum,
                    Kekleyen = ekleyen
                });
            }

            var temizYorum = yorum
                .Replace(OperasyonYorumPrefix, string.Empty, StringComparison.OrdinalIgnoreCase)
                .Replace(SahaYorumPrefix, string.Empty, StringComparison.OrdinalIgnoreCase)
                .Trim();
            if (temizYorum.Length > 180)
                temizYorum = temizYorum[..180] + "…";

            var taskName = GetTaskNotificationName(task);
            var sahaYorumu = yorum.StartsWith(SahaYorumPrefix, StringComparison.OrdinalIgnoreCase);
            AddTaskNotification(
                task,
                "Yeni yorum",
                $"A new comment was added to {taskName}: {temizYorum}",
                "Yorum",
                "Normal",
                sahaSuperAdminleriDahilEt: sahaYorumu);

            _context.SaveChanges();
        }
        [HttpGet]
        public IActionResult SahaIndex(string? q, string? durum = null, string? kisi = null, int? selectedTaskId = null)
        {
            
            
            
            var sahaKullaniciMi = IsSahaKullanici();
            var operasyonKullaniciMi = IsOperasyonKullanici();
            var operasyonSuperAdminMi = IsOperasyonSuperAdminKullanici();
            var sahaSuperAdminMi = IsSahaSuperAdminKullanici();

            if (!sahaKullaniciMi && !operasyonKullaniciMi && !sahaSuperAdminMi)
            {
                return RedirectToAction(nameof(Index));
            }

            q = (q ?? string.Empty).Trim();
            durum = (durum ?? string.Empty).Trim();
            kisi = (kisi ?? string.Empty).Trim();

            
            
            if (!sahaSuperAdminMi)
                kisi = string.Empty;

            
            
            var kisiVaryantlari = sahaSuperAdminMi
                ? new List<string>()
                : GetCurrentUserNameVariants();

            var kullaniciDisplayName = sahaSuperAdminMi
                ? "Saha Süper Admin"
                : GetCurrentUserDisplayName();

            
            
            
            
            
            var tumAtananIsler = _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .ToList();

            if (sahaKullaniciMi || sahaSuperAdminMi)
            {
                tumAtananIsler = tumAtananIsler
                    .Where(t => IsTaskForUrun(t, "OPERASYON"))
                    .ToList();
            }

            if (sahaSuperAdminMi)
            {
                
                
                var superAdminAdayIsler = tumAtananIsler
                    .Where(HasAssignedPerson)
                    .Where(t =>
                        !string.Equals((t.Durum ?? string.Empty).Trim(), "Arşiv", StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals((t.Durum ?? string.Empty).Trim(), "Arsiv", StringComparison.OrdinalIgnoreCase))
                    .Where(t => IsTakipBoardVisibleStatus(t.Durum))
                    .ToList();

                var tumSahaVaryantlari = GetAllSahaUserNameVariants();

                if (tumSahaVaryantlari.Count > 0)
                {
                    var sahaEslesenIsler = superAdminAdayIsler
                        .Where(t => MatchesTaskAssignedToAnyVariant(t, tumSahaVaryantlari))
                        .ToList();

                    
                    
                    
                    tumAtananIsler = sahaEslesenIsler.Any()
                        ? sahaEslesenIsler
                        : superAdminAdayIsler;
                }
                else
                {
                    tumAtananIsler = superAdminAdayIsler;
                }
            }
            else
            {
                
                
                tumAtananIsler = tumAtananIsler
                    .Where(t => sahaKullaniciMi
                        ? MatchesTaskSahaGorunurIsleri(t, kisiVaryantlari)
                        : MatchesTaskAssignedToAnyVariant(t, kisiVaryantlari))
                    .Where(t =>
                        !string.Equals((t.Durum ?? string.Empty).Trim(), "Arşiv", StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals((t.Durum ?? string.Empty).Trim(), "Arsiv", StringComparison.OrdinalIgnoreCase))
                    .Where(t => IsTakipBoardVisibleStatus(t.Durum))
                    .ToList();
            }

            var kisiListesi = sahaSuperAdminMi
                ? GetSahaIndexKisiSecenekleri(tumAtananIsler)
                : new List<string>();

            
            if (sahaSuperAdminMi && !string.IsNullOrWhiteSpace(kisi) &&
                !kisiListesi.Any(x => PersonNameMatches(x, kisi)))
            {
                kisi = string.Empty;
            }

            var durumListesi = _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == "Durum" && x.ParAdi != null && x.ParAdi != "")
                .Select(x => x.ParAdi!)
                .ToList()
                .Concat(tumAtananIsler.Select(x => x.Durum ?? string.Empty))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => GetStatusOrder(x))
                .ThenBy(x => x)
                .ToList();

            var tasks = tumAtananIsler;

            if (!string.IsNullOrWhiteSpace(q))
            {
                tasks = tasks
                    .Where(t => MatchesTaskSearch(t, q))
                    .ToList();
            }

            if (sahaSuperAdminMi && !string.IsNullOrWhiteSpace(kisi))
            {
                
                tasks = tasks
                    .Where(t => PersonNameMatches(t.TakipEden, kisi))
                    .ToList();
            }

            if (!string.IsNullOrWhiteSpace(durum))
            {
                tasks = tasks
                    .Where(t => string.Equals((t.Durum ?? string.Empty).Trim(), durum, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }

            tasks = tasks
                .OrderBy(t => GetStatusOrder(t.Durum))
                .ThenByDescending(t => t.OlusturmaTarihi)
                .ThenByDescending(t => t.Id)
                .ToList();

            var selectedTask = selectedTaskId.HasValue && selectedTaskId.Value > 0
                ? tasks.FirstOrDefault(x => x.Id == selectedTaskId.Value)
                : null;

            if (selectedTask?.Yorumlar != null)
            {
                selectedTask.Yorumlar = selectedTask.Yorumlar
                    .OrderByDescending(y => y.Tarih)
                    .ToList();
            }

            var musteriList = _context.Musteriler
                .AsNoTracking()
                .Where(m => !string.IsNullOrWhiteSpace(m.Firma))
                .OrderBy(m => m.Firma)
                .ToList();

            var musteriIdsByFirma = musteriList
                .GroupBy(m => NormalizeLookupText(m.Firma))
                .Where(g => g.Key != string.Empty)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(x => x.MusteriID).Distinct().ToList());

            var latestDetailByMusteri = _context.Detaylar
                .AsNoTracking()
                .Where(x => x.MusteriID > 0)
                .OrderByDescending(x => x.Tarih)
                .ThenByDescending(x => x.DetayID)
                .ToList()
                .GroupBy(x => x.MusteriID)
                .ToDictionary(x => x.Key, x => x.First());

            var musteriDurumById = _context.Musteriler
                .AsNoTracking()
                .ToDictionary(x => x.MusteriID, x => (x.Durum ?? string.Empty).Trim());

            var tasksForDetail = tasks.ToDictionary(x => x.Id, x => x);
            if (selectedTask != null && !tasksForDetail.ContainsKey(selectedTask.Id))
            {
                tasksForDetail[selectedTask.Id] = selectedTask;
            }

            ViewBag.TaskLatestDetaylar = tasksForDetail.Values.ToDictionary(
                task => task.Id,
                task =>
                {
                    var taskMusteriIds = GetTaskMusteriIds(task, musteriIdsByFirma);
                    return GetLatestDetayForTask(taskMusteriIds, latestDetailByMusteri);
                });

            ViewBag.TaskMusteriDurumlari = tasksForDetail.Values.ToDictionary(
                task => task.Id,
                task =>
                {
                    var taskMusteriIds = GetTaskMusteriIds(task, musteriIdsByFirma);
                    var fallbackDetay = GetLatestDetayForTask(taskMusteriIds, latestDetailByMusteri);
                    var durumMusteriId = fallbackDetay?.MusteriID ?? taskMusteriIds.FirstOrDefault();

                    if (durumMusteriId > 0 && musteriDurumById.TryGetValue(durumMusteriId, out var musteriDurum))
                    {
                        return musteriDurum;
                    }

                    return string.Empty;
                });

            ViewBag.Q = q;
            ViewBag.Durum = durum;
            ViewBag.Kisi = kisi;
            ViewBag.DurumListesi = durumListesi;
            ViewBag.KisiListesi = kisiListesi;
            ViewBag.SelectedTask = selectedTask;
            ViewBag.SelectedTaskId = selectedTask?.Id;
            ViewBag.SahaKullaniciAdi = kullaniciDisplayName;
            ViewBag.KullaniciSecenekleri = GetOperasyonKullaniciSecenekleri();
            ViewBag.SahaKisiVaryantlari = kisiVaryantlari;
            ViewBag.SahaEslesmeBilgisi = string.Join(" / ", kisiVaryantlari);
            ViewBag.IsOperasyonKullanici = operasyonKullaniciMi;
            ViewBag.IsOperasyonSuperAdmin = operasyonSuperAdminMi;
            ViewBag.IsSahaKullanici = sahaKullaniciMi;
            ViewBag.IsSahaSuperAdmin = sahaSuperAdminMi;

            return View(tasks);
        }

        [HttpGet]
        public IActionResult ExportSahaIndexExcel(string? q, string? durum = null, string? kisi = null, string? lang = null)
        {
            
            
            
            
            var sahaKullaniciMi = IsSahaKullanici();
            var operasyonKullaniciMi = IsOperasyonKullanici();
            var operasyonSuperAdminMi = IsOperasyonSuperAdminKullanici();
            var sahaSuperAdminMi = IsSahaSuperAdminKullanici();

            if (!sahaKullaniciMi && !operasyonKullaniciMi && !sahaSuperAdminMi)
            {
                return RedirectToAction(nameof(Index));
            }

            var isEn = IsEnglishExport(lang);
            kisi = (kisi ?? string.Empty).Trim();

            var kisiVaryantlari = sahaSuperAdminMi
                ? new List<string>()
                : GetCurrentUserNameVariants();

            var assignedTasks = _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .ToList();

            
            
            if (sahaKullaniciMi || sahaSuperAdminMi)
            {
                assignedTasks = assignedTasks
                    .Where(t => IsTaskForUrun(t, "OPERASYON"))
                    .ToList();
            }

            
            if (!sahaSuperAdminMi)
            {
                assignedTasks = assignedTasks
                    .Where(t => sahaKullaniciMi
                        ? MatchesTaskSahaGorunurIsleri(t, kisiVaryantlari)
                        : MatchesTaskAssignedToAnyVariant(t, kisiVaryantlari))
                    .ToList();
            }

            
            if (sahaSuperAdminMi && !string.IsNullOrWhiteSpace(kisi))
            {
                assignedTasks = assignedTasks
                    .Where(t => MatchesTaskAssignedToAnyVariant(t, new[] { kisi }))
                    .ToList();
            }

            
            assignedTasks = assignedTasks
                .OrderBy(t => GetStatusOrder(t.Durum))
                .ThenByDescending(t => t.OlusturmaTarihi)
                .ThenByDescending(t => t.Id)
                .ToList();

            var rows = BuildExportTaskRows(assignedTasks.AsQueryable(), false);
            
            var superAdminExcelMi = sahaSuperAdminMi;

            var sheetName = superAdminExcelMi
                ? (isEn ? "FieldWorkAllStatuses" : "SahaTumDurumlar")
                : (isEn ? "MyWorkAllStatuses" : "IslerimTumDurumlar");

            var fileName = superAdminExcelMi
                ? (isEn
                    ? $"FieldWork_AllStatuses_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                    : $"SahaIsleri_TumDurumlar_{DateTime.Now:yyyyMMdd_HHmm}.xlsx")
                : (isEn
                    ? $"MyWork_AllStatuses_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                    : $"BanaAtananIsler_TumDurumlar_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");

            return CreateAssignedTaskExcelFile(rows, sheetName, fileName, isEn);
        }

        [HttpGet]
        public IActionResult Vpos(string? q, string? kisi = null, string? ay = null, int? selectedTaskId = null, int page = 1, int pageSize = DefaultPageSize)
        {
            if (IsSahaKullanici() || IsSahaSuperAdminKullanici())
                return RedirectToAction(nameof(SahaIndex));

            return Index(q, kisi, ay, selectedTaskId, page, pageSize, "VPOS");
        }

        [HttpGet]
        public IActionResult Mobil(string? q, string? kisi = null, string? ay = null, int? selectedTaskId = null, int page = 1, int pageSize = DefaultPageSize)
        {
            if (IsSahaKullanici() || IsSahaSuperAdminKullanici())
                return RedirectToAction(nameof(SahaIndex));

            return Index(q, kisi, ay, selectedTaskId, page, pageSize, "MOBIL");
        }

        public IActionResult Index(string? q, string? kisi = null, string? ay = null, int? selectedTaskId = null, int page = 1, int pageSize = DefaultPageSize, string? urun = null)
        {
            
            

            
            
            

            urun = NormalizeUrun(urun);
            var vposKullaniciMi = IsVposKullanici();
            if (vposKullaniciMi && !string.Equals(urun, "VPOS", StringComparison.OrdinalIgnoreCase))
                return RedirectToAction(nameof(Vpos));

            ViewBag.Urun = urun;
            ViewBag.PageTitle = urun switch { "VPOS" => "VPOS Work Tracking", "MOBIL" => "Wallet Work Tracking", _ => "PF Work Tracking" };
            ViewBag.PageAction = urun switch { "VPOS" => nameof(Vpos), "MOBIL" => nameof(Mobil), _ => nameof(Index) };

            page = page < 1 ? 1 : page;
            pageSize = pageSize < 1 ? DefaultPageSize : pageSize;
            pageSize = pageSize > MaxPageSize ? MaxPageSize : pageSize;

            var selectedMonth = ResolveSelectedMonth(ay);

            
            
            var selectedMonthValue = string.Empty;
            var selectedMonthLabel = "All Time";
            var monthStart = DateTime.MinValue;
            var nextMonthStart = DateTime.MaxValue;

            var musteriList = _context.Musteriler
                .AsNoTracking()
                .Where(m => !string.IsNullOrWhiteSpace(m.Firma))
                .OrderBy(m => m.Firma)
                .ToList();

            var urunMusteriIds = GetUrunMusteriIds(urun);
            musteriList = musteriList.Where(m => urunMusteriIds.Contains(m.MusteriID)).ToList();

            var musteriIdsByFirma = musteriList
                .GroupBy(m => NormalizeLookupText(m.Firma))
                .Where(g => g.Key != string.Empty)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(x => x.MusteriID).Distinct().ToList());

            var latestDetailByMusteri = _context.Detaylar
                .AsNoTracking()
                .Where(x => x.MusteriID > 0)
                .OrderByDescending(x => x.Tarih)
                .ThenByDescending(x => x.DetayID)
                .ToList()
                .GroupBy(x => x.MusteriID)
                .ToDictionary(x => x.Key, x => x.First());

            var selectedMonthDetaylar = _context.Detaylar
                .AsNoTracking()
                .Where(x => x.MusteriID > 0 && x.Tarih >= monthStart && x.Tarih < nextMonthStart)
                .OrderByDescending(x => x.Tarih)
                .ThenByDescending(x => x.DetayID)
                .ToList();

            var selectedMonthLatestDetailByMusteri = selectedMonthDetaylar
                .GroupBy(x => x.MusteriID)
                .ToDictionary(x => x.Key, x => x.First());

            var musteriIdsWithDetayInMonth = selectedMonthLatestDetailByMusteri.Keys.ToHashSet();

            var musteriDurumById = _context.Musteriler
                .AsNoTracking()
                .ToDictionary(x => x.MusteriID, x => (x.Durum ?? string.Empty).Trim());

            var availableMonths = GetAvailableMonths(selectedMonth);

            var anaDurumlar = TakipAnaDurumlar;
            var seciliEkstraDurumlar = new List<string>();

            var talepAcanList = GetTalepAcanSecenekleri();
            var operasyonKullaniciList = GetOperasyonKullaniciSecenekleri();
            kisi = (kisi ?? string.Empty).Trim();

            var sahaKullaniciMi = IsSahaKullanici();
            var operasyonSuperAdminMi = IsOperasyonSuperAdminKullanici();
            var sahaKisiVaryantlari = sahaKullaniciMi
                ? GetCurrentUserNameVariants()
                : new List<string>();

            if (sahaKullaniciMi)
            {
                
                
                
                
                kisi = GetCurrentUserDisplayName();
            }

            var query = _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .AsQueryable();

            q = (q ?? "").Trim();
            var tasks = query.ToList()
                .Where(t => IsTaskForUrun(t, urun))
                .ToList();

            if (!string.IsNullOrWhiteSpace(q))
            {
                tasks = tasks
                    .Where(t => MatchesTaskSearch(t, q))
                    .ToList();
            }

            if (sahaKullaniciMi)
            {
                tasks = tasks
                    .Where(t => MatchesTaskSahaGorunurIsleri(t, sahaKisiVaryantlari))
                    .ToList();
            }
            else if (!string.IsNullOrWhiteSpace(kisi))
            {
                tasks = tasks
                    .Where(t => MatchesTaskKisi(t, kisi))
                    .ToList();
            }

            
            
            
            
            tasks = tasks
                .Where(t => !string.Equals((t.Durum ?? string.Empty).Trim(), "Arşiv", StringComparison.OrdinalIgnoreCase))
                .Where(t => IsTakipBoardVisibleStatus(t.Durum))
                .ToList();

            var taskMusteriIdsByTaskId = tasks.ToDictionary(
                t => t.Id,
                t => GetTaskMusteriIds(t, musteriIdsByFirma));

            var filteredTasks = tasks
                .OrderBy(t => GetStatusOrder(t.Durum))
                .ThenByDescending(t => GetTaskOrderDate(t, latestDetailByMusteri, taskMusteriIdsByTaskId[t.Id]))
                .ThenByDescending(t => t.OlusturmaTarihi)
                .ToList();

            var legacyTasks = selectedMonthDetaylar
                .Where(detay => string.Equals(urun, "OPERASYON", StringComparison.OrdinalIgnoreCase))
                .Where(detay => IsLegacyDetailCandidate(detay, tasks, taskMusteriIdsByTaskId))
                .Select(detay =>
                {
                    musteriDurumById.TryGetValue(detay.MusteriID, out var legacyDurum);
                    var legacyMusteriAdi = musteriList.FirstOrDefault(x => x.MusteriID == detay.MusteriID)?.Firma;
                    return new
                    {
                        Detay = detay,
                        Task = CreateLegacyTask(detay, legacyMusteriAdi, legacyDurum)
                    };
                })
                .Where(x =>
                    MatchesTaskSearch(x.Task, q, x.Detay.Aciklama) &&
                    (sahaKullaniciMi
                        ? MatchesTaskSahaGorunurIsleri(x.Task, sahaKisiVaryantlari)
                        : MatchesTaskKisi(x.Task, kisi)))
                .OrderByDescending(x => x.Detay.Tarih)
                .ThenByDescending(x => x.Detay.DetayID)
                .ToList();

            var legacyTaskIds = legacyTasks
                .Select(x => x.Task.Id)
                .ToHashSet();

            
            var combinedTasks = filteredTasks
                .OrderByDescending(t => t.OlusturmaTarihi)
                .ThenByDescending(t => t.Id)
                .ToList();

            var totalCount = combinedTasks.Count;

            
            
            var paged = combinedTasks.ToList();
            page = 1;
            pageSize = totalCount <= 0 ? 1 : totalCount;

            var durumListesi = TakipSecilebilirDurumlar.ToList();


            var model = new JiraBoardViewModel
            {
                Q = q,
                SelectedTaskId = selectedTaskId,
                Page = page,
                PageSize = pageSize,
                TotalCount = totalCount,
                Beklemede = paged.Where(t => (t.Durum ?? "").Trim().Equals("Beklemede", StringComparison.OrdinalIgnoreCase)).ToList(),
                Aktif = paged.Where(t => (t.Durum ?? "").Trim().Equals("Aktif", StringComparison.OrdinalIgnoreCase)).ToList(),
                Tamamlandi = paged.Where(t => (t.Durum ?? "").Trim().Equals("Tamamlandı", StringComparison.OrdinalIgnoreCase)).ToList(),
                MusteriSecenekleri = musteriList,
                TalepAcanSecenekleri = talepAcanList,
                TakipEdenSecenekleri = operasyonKullaniciList
            };

            if (selectedTaskId.HasValue && selectedTaskId.Value > 0)
            {
                model.SelectedTask = filteredTasks.FirstOrDefault(x => x.Id == selectedTaskId.Value);

                if (model.SelectedTask?.Yorumlar != null)
                {
                    model.SelectedTask.Yorumlar = model.SelectedTask.Yorumlar
                        .OrderByDescending(y => y.Tarih)
                        .ToList();
                }
            }

            var taskIdsForView = paged
                .Select(x => x.Id)
                .ToHashSet();

            if (model.SelectedTask != null)
            {
                taskIdsForView.Add(model.SelectedTask.Id);
            }

            var legacyDetayByTaskId = legacyTasks.ToDictionary(x => x.Task.Id, x => x.Detay);

            ViewBag.TaskLatestDetaylar = taskIdsForView.ToDictionary(
                taskId => taskId,
                taskId =>
                {
                    if (legacyDetayByTaskId.TryGetValue(taskId, out var legacyDetay))
                    {
                        return legacyDetay;
                    }

                    var taskMusteriIds = taskMusteriIdsByTaskId.TryGetValue(taskId, out var ids) ? ids : [];
                    return GetLatestDetayForTask(taskMusteriIds, latestDetailByMusteri);
                });

            ViewBag.TaskMusteriDurumlari = taskIdsForView.ToDictionary(
                taskId => taskId,
                taskId =>
                {
                    if (legacyDetayByTaskId.TryGetValue(taskId, out var legacyDetay) && musteriDurumById.TryGetValue(legacyDetay.MusteriID, out var legacyMusteriDurum))
                    {
                        return legacyMusteriDurum;
                    }

                    var taskMusteriIds = taskMusteriIdsByTaskId.TryGetValue(taskId, out var ids) ? ids : [];
                    var fallbackDetay = GetLatestDetayForTask(taskMusteriIds, latestDetailByMusteri);
                    var durumMusteriId = fallbackDetay?.MusteriID ?? taskMusteriIds.FirstOrDefault();

                    if (durumMusteriId > 0 && musteriDurumById.TryGetValue(durumMusteriId, out var musteriDurum))
                    {
                        return musteriDurum;
                    }

                    return string.Empty;
                });

            ViewBag.KullaniciSecenekleri = operasyonKullaniciList;
            ViewBag.AtanabilirOperasyonKullanicilari = GetAtanabilirOperasyonKullanicilari();
            ViewBag.KisiSecenekleri = operasyonKullaniciList;
            ViewBag.SelectedKisi = kisi;
            ViewBag.IsSahaKullanici = sahaKullaniciMi;
            ViewBag.IsVposKullanici = vposKullaniciMi;
            ViewBag.IsAdminKullanici = User.IsInRole("Admin") || User.IsInRole(AppRoles.Admin) || operasyonSuperAdminMi;
            ViewBag.IsOperasyonSuperAdmin = operasyonSuperAdminMi;
            ViewBag.SelectedAy = selectedMonthValue;
            ViewBag.SelectedAyLabel = selectedMonthLabel;
            ViewBag.AvailableAylar = availableMonths;
            ViewBag.DurumListesi = durumListesi;
            ViewBag.AnaDurumlar = anaDurumlar;
            ViewBag.SelectedEkstraDurumlar = seciliEkstraDurumlar;
            ViewBag.LegacyTaskIds = legacyTaskIds;
            ViewBag.PagedTasks = paged;
            return View("Index", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(JiraTask model, string? returnUrl, string? urun = null)
        {
            if (IsVposKullanici())
            {
                TempData["JiraError"] = "VPOS kullanıcısı yeni işi VPOS Yeni İş ekranından açmalıdır. Atama sistem tarafından iş yoğunluğuna göre yapılır.";
                return RedirectToAction("Yeni", "Vpos");
            }

            if (model == null) return RedirectToLocalOrIndex(returnUrl);

            model.JiraId = (model.JiraId ?? string.Empty).Trim();
            model.TalepKonusu = (model.TalepKonusu ?? "").Trim();
            urun = NormalizeUrun(urun);
            var taskPrefix = GetTaskPrefix(urun);
            if (!string.IsNullOrWhiteSpace(taskPrefix) && !model.TalepKonusu.StartsWith(taskPrefix, StringComparison.OrdinalIgnoreCase))
                model.TalepKonusu = taskPrefix + model.TalepKonusu;
            model.TalepTuru = (model.TalepTuru ?? "").Trim();
            model.TalepAcan = (model.TalepAcan ?? "").Trim();
            model.Durum = string.IsNullOrWhiteSpace(model.Durum) ? "Aktif" : model.Durum.Trim();
            if (!TakipSecilebilirDurumlar.Contains(model.Durum, StringComparer.OrdinalIgnoreCase))
            {
                TempData["JiraError"] = "Invalid status selected. Only main tracking statuses can be used on the Work Tracking screen.";
                return RedirectToLocalOrIndex(returnUrl);
            }
            model.TakipEden = (model.TakipEden ?? "").Trim();
            model.MusteriAdi = (model.MusteriAdi ?? "").Trim();

            if (!string.IsNullOrWhiteSpace(model.TalepTuru) && !AllowedTalepTurleri.Contains(model.TalepTuru, StringComparer.Ordinal))
            {
                TempData["JiraError"] = "Invalid work type selected.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            if (model.MusteriID.HasValue && model.MusteriID > 0)
            {
                var musteri = _context.Musteriler
                    .AsNoTracking()
                    .FirstOrDefault(x => x.MusteriID == model.MusteriID.Value);

                if (musteri == null)
                {
                    TempData["JiraError"] = "Selected customer was not found.";
                    return RedirectToLocalOrIndex(returnUrl);
                }

                var allowedCustomerIds = GetUrunMusteriIds(urun);
                if (!allowedCustomerIds.Contains(musteri.MusteriID))
                {
                    var urunAdi = urun == "MOBIL" ? "Cüzdan" : urun == "VPOS" ? "VPOS" : "PF";
                    TempData["JiraError"] = $"The selected customer is not marked as a {urunAdi} customer.";
                    return RedirectToLocalOrIndex(returnUrl);
                }

                model.MusteriAdi = (musteri.Firma ?? "").Trim();
            }
            else
            {
                model.MusteriID = null;
                model.MusteriAdi = string.Empty;
            }

            if (string.IsNullOrWhiteSpace(model.TalepKonusu))
            {
                TempData["JiraError"] = "Request Subject is required.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            model.OlusturmaTarihi = DateTime.Now;

            var olusturmaDurumu = model.Durum;

            _context.JiraTasks.Add(model);
            _context.SaveChanges();

            if (!string.IsNullOrWhiteSpace(model.TakipEden))
            {
                AddTaskNotification(
                    model,
                    "Yeni iş atandı",
                    $"{GetTaskNotificationName(model)} was assigned to {model.TakipEden}.",
                    "Atama",
                    "Önemli");
                _context.SaveChanges();
            }

            
            if (string.Equals(olusturmaDurumu, "Entegrasyon Tamamlandı", StringComparison.OrdinalIgnoreCase))
            {
                ApplyDurumToTaskAndMusteri(
                    model,
                    model.MusteriID,
                    olusturmaDurumu,
                    User.Identity?.Name ?? "Sistem",
                    "Task created as Integration Completed and automatically archived.");

                _context.SaveChanges();
                TempData["JiraOk"] = ArchiveMessageForSelectedStatus(olusturmaDurumu);
            }
            else
            {
                TempData["JiraOk"] = "Task added.";
            }

            return RedirectToLocalOrIndex(returnUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddYorum(int jiraTaskId, string yorum, string ekleyen)
        {
            
            var operasyonYetkili = IsOperasyonKullanici() || IsOperasyonSuperAdminKullanici() || User.IsInRole("Admin") || User.IsInRole(AppRoles.Admin);
            if (!operasyonYetkili)
            {
                return Forbid();
            }

            yorum = (yorum ?? "").Trim();
            ekleyen = string.IsNullOrWhiteSpace(ekleyen) ? "Sistem" : ekleyen.Trim();

            if (string.IsNullOrWhiteSpace(yorum))
            {
                TempData["JiraError"] = "Comment cannot be empty.";
                return RedirectToAction(nameof(Index));
            }

            var task = _context.JiraTasks.FirstOrDefault(t => t.Id == jiraTaskId);
            if (task == null)
            {
                TempData["JiraError"] = "Task was not found.";
                return RedirectToAction(nameof(Index));
            }

            AddYorumVeMusteriDetay(task, yorum, ekleyen);
            TempData["JiraOk"] = "Comment added.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddYorumForm(int jiraTaskId, string yorum, string ekleyen, string? returnUrl)
        {
            var operasyonYetkili = IsOperasyonKullanici() || IsOperasyonSuperAdminKullanici() || User.IsInRole("Admin") || User.IsInRole(AppRoles.Admin);
            if (!operasyonYetkili)
            {
                return Forbid();
            }

            yorum = (yorum ?? "").Trim();
            if (string.IsNullOrWhiteSpace(yorum))
            {
                TempData["JiraError"] = "Yorum boş olamaz.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var task = _context.JiraTasks.FirstOrDefault(t => t.Id == jiraTaskId);
            if (task == null)
            {
                TempData["JiraError"] = "İş kaydı bulunamadı.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            
            
            var currentUser = GetCurrentUserDisplayName();
            ekleyen = string.IsNullOrWhiteSpace(currentUser) ? (User.Identity?.Name ?? "Sistem") : currentUser;
            AddYorumVeMusteriDetay(task, PrefixYorum(yorum, sahaYorumu: false), ekleyen);
            TempData["JiraOk"] = "Operasyon yorumu eklendi.";
            return RedirectToLocalOrIndex(returnUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddSahaYorumForm(int jiraTaskId, string yorum, string? returnUrl)
        {
            yorum = (yorum ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(yorum))
            {
                TempData["JiraError"] = "Saha yorumu boş olamaz.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var sahaKullaniciMi = IsSahaKullanici();
            var sahaSuperAdminMi = IsSahaSuperAdminKullanici();
            if (!sahaKullaniciMi && !sahaSuperAdminMi)
            {
                return Forbid();
            }

            var task = _context.JiraTasks.FirstOrDefault(t => t.Id == jiraTaskId);
            if (task == null)
            {
                TempData["JiraError"] = "İş kaydı bulunamadı.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            if (!sahaSuperAdminMi)
            {
                var variants = GetCurrentUserNameVariants();
                if (!MatchesTaskSahaGorunurIsleri(task, variants))
                {
                    return Forbid();
                }
            }

            var currentUser = GetCurrentUserDisplayName();
            var ekleyen = string.IsNullOrWhiteSpace(currentUser) ? (User.Identity?.Name ?? "Sistem") : currentUser;
            AddYorumVeMusteriDetay(task, PrefixYorum(yorum, sahaYorumu: true), ekleyen);
            TempData["JiraOk"] = "Saha yorumu eklendi.";
            return RedirectToLocalOrIndex(returnUrl);
        }

        [HttpPost]
        [Authorize(Roles = AppRoles.Admin + "," + AppRoles.Operasyon + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin")]
        [ValidateAntiForgeryToken]
        public IActionResult AssignForm(int id, string? takipEden, string? returnUrl, string? lang)
        {
            if (id <= 0)
            {
                TempData["JiraError"] = L(IsEnglishExport(lang), "Geçersiz kayıt.", "Invalid record.");
                return RedirectToLocalOrIndex(returnUrl);
            }

            var task = _context.JiraTasks.Find(id);
            if (task == null)
            {
                TempData["JiraError"] = "Record was not found.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            if (IsTaskForUrun(task, "VPOS") &&
                !(User.IsInRole(AppRoles.Admin) || User.IsInRole("Admin") || IsOperasyonSuperAdminKullanici()))
            {
                TempData["JiraError"] = "VPOS iş atamasını yalnızca Operasyon Süper Admin veya Admin değiştirebilir.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var yeniTakipEden = (takipEden ?? string.Empty).Trim();
            if (IsTaskForUrun(task, "VPOS") && !string.IsNullOrWhiteSpace(yeniTakipEden))
            {
                var allowed = GetAtanabilirOperasyonKullanicilari();
                if (!allowed.Contains(yeniTakipEden, StringComparer.OrdinalIgnoreCase))
                {
                    TempData["JiraError"] = "VPOS işleri yalnızca Operasyon grubundaki kullanıcılara atanabilir.";
                    return RedirectToLocalOrIndex(returnUrl);
                }
            }

            var eskiTakipEden = (task.TakipEden ?? string.Empty).Trim();
            task.TakipEden = yeniTakipEden;

            if (!string.Equals(eskiTakipEden, task.TakipEden, StringComparison.OrdinalIgnoreCase) &&
                !string.IsNullOrWhiteSpace(task.TakipEden))
            {
                AddTaskNotification(
                    task,
                    "İş ataması değişti",
                    $"{GetTaskNotificationName(task)} was assigned to {task.TakipEden}.",
                    "Atama",
                    "Önemli");
            }

            _context.SaveChanges();
TempData["JiraOk"] = "Assignee updated.";
            return RedirectToLocalOrIndex(returnUrl);
        }

        private int? ResolveTaskMusteriIdForUpdate(JiraTask task)
        {
            if (task.MusteriID.HasValue && task.MusteriID.Value > 0)
                return task.MusteriID.Value;

            var musteriAdi = (task.MusteriAdi ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(musteriAdi))
                return null;

            var musteriAdiKey = NormalizeLookupText(musteriAdi);

            var musteri = _context.Musteriler
                .AsEnumerable()
                .FirstOrDefault(x => NormalizeLookupText(x.Firma) == musteriAdiKey);

            return musteri?.MusteriID;
        }

        private static bool ShouldArchiveWhenSelected(string? durum)
        {
            var clean = (durum ?? string.Empty).Trim();

            
            
            return string.Equals(clean, "Entegrasyon Tamamlandı", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(clean, "Canlıda Entegrasyon Tamamlandı", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(clean, EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase);
        }

        private static string ArchiveMessageForSelectedStatus(string durum)
        {
            var clean = (durum ?? string.Empty).Trim();

            if (string.Equals(clean, EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase))
                return "Entegrasyon Tamamlanmadı seçildi. Kayıt otomatik olarak arşive alındı.";

            if (string.Equals(clean, "Entegrasyon Tamamlandı", StringComparison.OrdinalIgnoreCase))
                return "Entegrasyon Tamamlandı seçildi. Kayıt otomatik olarak arşive alındı.";

            return "Canlıda Entegrasyon Tamamlandı seçildi. Kayıt otomatik olarak arşive alındı.";
        }

        private void ApplyDurumToTaskAndMusteri(JiraTask? task, int? musteriId, string yeniDurum, string degistiren, string aciklama)
        {
            yeniDurum = (yeniDurum ?? string.Empty).Trim();
            degistiren = string.IsNullOrWhiteSpace(degistiren) ? "Sistem" : degistiren.Trim();
            aciklama = string.IsNullOrWhiteSpace(aciklama) ? "Status updated." : aciklama.Trim();

            if (task != null)
            {
                var taskEskiDurum = (task.Durum ?? string.Empty).Trim();

                
                
                task.Durum = ShouldArchiveWhenSelected(yeniDurum)
                    ? "Arşiv"
                    : yeniDurum;

                if (!string.Equals(taskEskiDurum, yeniDurum, StringComparison.OrdinalIgnoreCase))
                {
                    AddTaskNotification(
                        task,
                        "İş durumu değişti",
                        $"The status of {GetTaskNotificationName(task)} was updated: {taskEskiDurum} → {yeniDurum}.",
                        "Durum",
                        string.Equals(yeniDurum, EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase) ? "Kritik" : "Önemli");
                }

                musteriId ??= ResolveTaskMusteriIdForUpdate(task);

                if (musteriId.HasValue && musteriId.Value > 0 && (!task.MusteriID.HasValue || task.MusteriID.Value <= 0))
                    task.MusteriID = musteriId.Value;

                if (ShouldArchiveWhenSelected(yeniDurum) && task.Id > 0)
                {
                    _context.JiraYorumlar.Add(new JiraYorum
                    {
                        JiraTaskId = task.Id,
                        YorumMetni = "Arşivlendi",
                        Ekleyen = degistiren,
                        Tarih = DateTime.Now
                    });

                    _context.JiraYorumlar.Add(new JiraYorum
                    {
                        JiraTaskId = task.Id,
                        YorumMetni = $"Status: {taskEskiDurum} → {yeniDurum}. Record automatically archived.",
                        Ekleyen = degistiren,
                        Tarih = DateTime.Now
                    });
                }
            }

            if (!musteriId.HasValue || musteriId.Value <= 0)
                return;

            var musteri = _context.Musteriler.FirstOrDefault(x => x.MusteriID == musteriId.Value);
            if (musteri == null)
                return;

            var eskiDurum = (musteri.Durum ?? string.Empty).Trim();

            musteri.Durum = yeniDurum;
            musteri.DurumDegisiklikTarihi = DateTime.Now;

            if (!string.Equals(eskiDurum, yeniDurum, StringComparison.OrdinalIgnoreCase))
            {
                _context.MusteriDurumGecmisleri.Add(new MusteriDurumGecmisi
                {
                    MusteriID = musteri.MusteriID,
                    EskiDurum = eskiDurum,
                    YeniDurum = yeniDurum,
                    Tarih = DateTime.Now,
                    DegistirenKullanici = degistiren,
                    Aciklama = aciklama
                });
            }
        }


        private void AddRequiredExplanationCommentForFailedIntegration(JiraTask? task, string yeniDurum, string aciklama, string ekleyen)
        {
            if (task == null || task.Id <= 0)
                return;

            if (!string.Equals((yeniDurum ?? string.Empty).Trim(), EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase))
                return;

            aciklama = (aciklama ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(aciklama))
                return;

            ekleyen = string.IsNullOrWhiteSpace(ekleyen) ? "Sistem" : ekleyen.Trim();

            _context.JiraYorumlar.Add(new JiraYorum
            {
                JiraTaskId = task.Id,
                YorumMetni = $"Integration Not Completed Description: {aciklama}",
                Ekleyen = ekleyen,
                Tarih = DateTime.Now
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateDurumForm(int id, string? yeniDurum, string? aciklama, string? returnUrl)
        {
            if (IsVposKullanici())
            {
                TempData["JiraError"] = "VPOS kullanıcıları İş Takip ekranını salt okunur görüntüler. Durumu operasyon ekibi günceller.";
                return RedirectToAction(nameof(Vpos));
            }
            if (id <= 0 || string.IsNullOrWhiteSpace(yeniDurum))
            {
                TempData["JiraError"] = "Invalid status update.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var task = _context.JiraTasks.Find(id);
            if (task == null)
            {
                TempData["JiraError"] = "Record was not found.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var yeni = yeniDurum.Trim();
            if (!TakipSecilebilirDurumlar.Contains(yeni, StringComparer.OrdinalIgnoreCase))
            {
                TempData["JiraError"] = "This status cannot be used on the Work Tracking screen. Other statuses are kept only on the Excel side.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var durumAciklama = (aciklama ?? string.Empty).Trim();
            if (string.Equals(yeni, EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(durumAciklama))
            {
                TempData["JiraError"] = "Entegrasyon Tamamlanmadı seçildiğinde açıklama girmek zorunludur.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            ApplyDurumToTaskAndMusteri(
                task,
                null,
                yeni,
                User.Identity?.Name ?? "Sistem",
                string.IsNullOrWhiteSpace(durumAciklama) ? "Work Tracking status update" : durumAciklama);

            AddRequiredExplanationCommentForFailedIntegration(task, yeni, durumAciklama, User.Identity?.Name ?? "Sistem");

            _context.SaveChanges();

            if (ShouldArchiveWhenSelected(yeni))
                returnUrl = RemoveQueryParametersFromLocalUrl(returnUrl, "selectedTaskId");

            TempData["JiraOk"] = ShouldArchiveWhenSelected(yeni)
                ? ArchiveMessageForSelectedStatus(yeni)
                : "Status updated. Detail/Customer status was also updated.";
            return RedirectToLocalOrIndex(returnUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateDetayDurumForm(int id, string? yeniDurum, string? aciklama, string? returnUrl)
        {
            if (IsVposKullanici())
            {
                TempData["JiraError"] = "VPOS kullanıcıları İş Takip ekranını salt okunur görüntüler. Durumu operasyon ekibi günceller.";
                return RedirectToAction(nameof(Vpos));
            }
            if (string.IsNullOrWhiteSpace(yeniDurum))
            {
                TempData["JiraError"] = "Detail status cannot be empty.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var yeni = yeniDurum.Trim();
            if (!TakipSecilebilirDurumlar.Contains(yeni, StringComparer.OrdinalIgnoreCase))
            {
                TempData["JiraError"] = "This status cannot be used on the Work Tracking screen.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            var durumAciklama = (aciklama ?? string.Empty).Trim();
            if (string.Equals(yeni, EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(durumAciklama))
            {
                TempData["JiraError"] = "Entegrasyon Tamamlanmadı seçildiğinde açıklama girmek zorunludur.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            if (id == 0)
            {
                TempData["JiraError"] = "Invalid record.";
                return RedirectToLocalOrIndex(returnUrl);
            }

            JiraTask? task = null;
            int? musteriId = null;

            if (id > 0)
            {
                task = _context.JiraTasks.FirstOrDefault(x => x.Id == id);
                if (task == null)
                {
                    TempData["JiraError"] = "Work tracking record was not found.";
                    return RedirectToLocalOrIndex(returnUrl);
                }

                musteriId = ResolveTaskMusteriIdForUpdate(task);
            }
            else
            {
                var detayId = Math.Abs(id);
                var detay = _context.Detaylar.FirstOrDefault(x => x.DetayID == detayId);
                if (detay == null)
                {
                    TempData["JiraError"] = "Detail record was not found.";
                    return RedirectToLocalOrIndex(returnUrl);
                }

                musteriId = detay.MusteriID;
            }

            ApplyDurumToTaskAndMusteri(
                task,
                musteriId,
                yeni,
                User.Identity?.Name ?? "Sistem",
                string.IsNullOrWhiteSpace(durumAciklama) ? "Status updated from the tracking detail screen." : durumAciklama);

            AddRequiredExplanationCommentForFailedIntegration(task, yeni, durumAciklama, User.Identity?.Name ?? "Sistem");

            _context.SaveChanges();

            if (ShouldArchiveWhenSelected(yeni))
                returnUrl = RemoveQueryParametersFromLocalUrl(returnUrl, "selectedTaskId");

            TempData["JiraOk"] = ShouldArchiveWhenSelected(yeni)
                ? ArchiveMessageForSelectedStatus(yeni)
                : "Detail status updated.";
            return RedirectToLocalOrIndex(returnUrl);
        }

        [HttpPost]
        [Authorize(Roles = AppRoles.Admin + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteForm(int id, string? returnUrl, string? lang)
        {
            if (id <= 0)
            {
                TempData["JiraError"] = L(IsEnglishExport(lang), "Geçersiz kayıt.", "Invalid record.");
                return RedirectToLocalOrIndex(returnUrl);
            }

            var task = _context.JiraTasks
                .Include(t => t.Yorumlar)
                .FirstOrDefault(t => t.Id == id);

            if (task == null)
            {
                TempData["JiraError"] = L(IsEnglishExport(lang), "Kayıt bulunamadı.", "Record was not found.");
                return RedirectToLocalOrIndex(returnUrl);
            }

            if (task.Yorumlar != null && task.Yorumlar.Any())
                _context.JiraYorumlar.RemoveRange(task.Yorumlar);
_context.JiraTasks.Remove(task);
            _context.SaveChanges();
            TempData["JiraOk"] = L(IsEnglishExport(lang), "Kayıt silindi.", "Record deleted.");
            return RedirectToLocalOrIndex(returnUrl);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddYorumJson([FromBody] AddYorumJsonModel model)
        {
            if (IsVposKullanici())
                return Json(new { success = false, message = "VPOS kullanıcıları bu ekranda operasyon yorumu ekleyemez." });

            if (model == null || model.JiraTaskId <= 0)
                return Json(new { success = false, message = "Invalid model" });

            var yorum = (model.Yorum ?? "").Trim();
            var ekleyen = string.IsNullOrWhiteSpace(model.Ekleyen) ? "Sistem" : model.Ekleyen.Trim();

            if (string.IsNullOrWhiteSpace(yorum))
                return Json(new { success = false, message = "Comment cannot be empty." });

            var task = _context.JiraTasks.FirstOrDefault(t => t.Id == model.JiraTaskId);
            if (task == null)
                return Json(new { success = false, message = "Task was not found." });

            AddYorumVeMusteriDetay(task, yorum, ekleyen);
            return Json(new { success = true });
        }

        public class AddYorumJsonModel
        {
            public int JiraTaskId { get; set; }
            public string? Yorum { get; set; }
            public string? Ekleyen { get; set; }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult UpdateDurum([FromBody] UpdateDurumModel model)
        {
            if (IsVposKullanici())
                return Json(new { success = false, message = "VPOS kullanıcıları İş Takip ekranını salt okunur görüntüler." });

            try
            {
                if (model == null)
                    return Json(new { success = false, message = "Model is null" });

                if (model.Id <= 0)
                    return Json(new { success = false, message = "Invalid ID" });

                if (string.IsNullOrWhiteSpace(model.YeniDurum))
                    return Json(new { success = false, message = "Status cannot be empty." });

                var task = _context.JiraTasks.Find(model.Id);
                if (task == null)
                    return Json(new { success = false, message = "Task was not found." });

                var yeni = model.YeniDurum.Trim();
                if (!TakipSecilebilirDurumlar.Contains(yeni, StringComparer.OrdinalIgnoreCase))
                {
                    return Json(new
                    {
                        success = false,
                        message = "This status cannot be used on the Work Tracking screen. Other statuses are kept only on the Excel side."
                    });
                }

                var durumAciklama = (model.Aciklama ?? string.Empty).Trim();
                if (string.Equals(yeni, EntegrasyonTamamlanmadiDurum, StringComparison.OrdinalIgnoreCase) && string.IsNullOrWhiteSpace(durumAciklama))
                {
                    return Json(new
                    {
                        success = false,
                        message = "Entegrasyon Tamamlanmadı seçildiğinde açıklama girmek zorunludur."
                    });
                }

                ApplyDurumToTaskAndMusteri(
                    task,
                    null,
                    yeni,
                    User.Identity?.Name ?? "Sistem",
                    string.IsNullOrWhiteSpace(durumAciklama) ? "Work Tracking drag-and-drop status update" : durumAciklama);

                AddRequiredExplanationCommentForFailedIntegration(task, yeni, durumAciklama, User.Identity?.Name ?? "Sistem");

                _context.SaveChanges();

                return Json(new
                {
                    success = true,
                    message = ShouldArchiveWhenSelected(yeni)
                        ? ArchiveMessageForSelectedStatus(yeni)
                        : "Status and detail status updated."
                });
            }
            catch (Exception)
            {
                return Json(new { success = false, message = "İşlem sırasında beklenmeyen bir hata oluştu." });
            }
        }

        [HttpPost]
        [Authorize(Roles = AppRoles.Admin + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin")]
        [ValidateAntiForgeryToken]
        public JsonResult Delete([FromBody] DeleteModel model)
        {
            if (model == null || model.Id <= 0)
                return Json(new { success = false, message = "Invalid record." });

            var task = _context.JiraTasks
                .Include(t => t.Yorumlar)
                .FirstOrDefault(t => t.Id == model.Id);

            if (task == null)
                return Json(new { success = false, message = "Record was not found." });

            if (task.Yorumlar != null && task.Yorumlar.Any())
                _context.JiraYorumlar.RemoveRange(task.Yorumlar);
_context.JiraTasks.Remove(task);
            _context.SaveChanges();

            return Json(new { success = true });
        }

        [HttpPost]
        [Authorize(Roles = AppRoles.Admin + "," + AppRoles.Operasyon + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin")]
        [ValidateAntiForgeryToken]
        public JsonResult Assign([FromBody] AssignModel model)
        {
            if (model == null || model.Id <= 0)
                return Json(new { success = false, message = "Invalid record." });

            var task = _context.JiraTasks.Find(model.Id);
            if (task == null)
                return Json(new { success = false, message = "Record was not found." });

            var isVposTask = IsTaskForUrun(task, "VPOS");
            if (isVposTask &&
                !(User.IsInRole(AppRoles.Admin) || User.IsInRole("Admin") || IsOperasyonSuperAdminKullanici()))
            {
                return Json(new
                {
                    success = false,
                    message = "VPOS iş atamasını yalnızca Operasyon Süper Admin veya Admin değiştirebilir."
                });
            }

            var yeniTakipEden = (model.TakipEden ?? string.Empty).Trim();
            if (isVposTask && !string.IsNullOrWhiteSpace(yeniTakipEden))
            {
                var allowed = GetAtanabilirOperasyonKullanicilari();
                if (!allowed.Contains(yeniTakipEden, StringComparer.OrdinalIgnoreCase))
                {
                    return Json(new
                    {
                        success = false,
                        message = "VPOS işleri yalnızca Operasyon grubundaki kullanıcılara atanabilir."
                    });
                }
            }

            var eskiTakipEden = (task.TakipEden ?? string.Empty).Trim();
            task.TakipEden = yeniTakipEden;

            if (!string.Equals(eskiTakipEden, task.TakipEden, StringComparison.OrdinalIgnoreCase) &&
                !string.IsNullOrWhiteSpace(task.TakipEden))
            {
                AddTaskNotification(
                    task,
                    "İş ataması değişti",
                    $"{GetTaskNotificationName(task)} was assigned to {task.TakipEden}.",
                    "Atama",
                    "Önemli");
            }

            _context.SaveChanges();
return Json(new { success = true });
        }

        public class AssignModel
        {
            public int Id { get; set; }
            public string? TakipEden { get; set; }
        }

        [HttpGet]
        public async Task<IActionResult> DetailCard(int id)
        {
            int? musteriId = null;
            string musteriAdi = string.Empty;

            if (id < 0)
            {
                var detayId = Math.Abs(id);

                var detay = await _context.Detaylar
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.DetayID == detayId);

                if (detay == null)
                    return NotFound("Detail record was not found.");

                musteriId = detay.MusteriID;
            }
            else
            {
                var task = await _context.JiraTasks
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.Id == id);

                if (task == null)
                    return NotFound("Work tracking record was not found.");

                musteriId = task.MusteriID;
            }

            if (!musteriId.HasValue || musteriId.Value <= 0)
                return NotFound("Customer information was not found.");

            var musteri = await _context.Musteriler
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.MusteriID == musteriId.Value);

            if (musteri != null)
                musteriAdi = musteri.Firma ?? string.Empty;

            var detaylar = await _context.Detaylar
                .AsNoTracking()
                .Where(x => x.MusteriID == musteriId.Value)
                .OrderByDescending(x => x.Tarih)
                .ThenByDescending(x => x.DetayID)
                .ToListAsync();

            var operasyonKullaniciList = GetOperasyonKullaniciSecenekleri();

            ViewBag.MusteriID = musteriId.Value;
            ViewBag.MusteriAdi = musteriAdi;
            ViewBag.KullaniciSecenekleri = operasyonKullaniciList;

            return PartialView("~/Views/Detay/_DetayListesi.cshtml", detaylar);
        }




        [HttpGet]
        public IActionResult ExportExcelGrouped(string? lang, string? urun = null)
        {
            var isEn = IsEnglishExport(lang);
            urun = (IsSahaKullanici() || IsSahaSuperAdminKullanici()) ? "OPERASYON" : NormalizeUrun(urun);

            var query = _context.JiraTasks
                .AsNoTracking()
                .Where(x => !ExcelDisiTalepTurleri.Contains((x.TalepTuru ?? string.Empty).Trim()))
                .AsQueryable();
            query = ApplyUrunTaskFilter(query, urun);

            var rows = BuildExportTaskRows(query, true);
            var urunKey = urun == "VPOS" ? "VPOS" : urun == "MOBIL" ? "Cuzdan" : "PF";
            var sheetName = isEn ? $"{urunKey}WorkTracking" : $"{urunKey}IsTakip";
            var fileName = isEn
                ? $"{urunKey}_WorkTracking_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                : $"{urunKey}_IsTakip_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
            return CreateTaskExcelFile(rows, sheetName, fileName, isEn);
        }

        [HttpGet]
        public IActionResult ExportExcelTumAylar(string? lang, string? urun = null)
        {
            var isEn = IsEnglishExport(lang);
            urun = (IsSahaKullanici() || IsSahaSuperAdminKullanici()) ? "OPERASYON" : NormalizeUrun(urun);

            var query = _context.JiraTasks
                .AsNoTracking()
                .Where(x => !ExcelDisiTalepTurleri.Contains((x.TalepTuru ?? string.Empty).Trim()))
                .AsQueryable();
            query = ApplyUrunTaskFilter(query, urun);

            var rows = BuildExportTaskRows(query, false);
            var urunKey = urun == "VPOS" ? "VPOS" : urun == "MOBIL" ? "Cuzdan" : "PF";
            var sheetName = isEn ? $"{urunKey}AllMonths" : $"{urunKey}TumAylar";
            var fileName = isEn
                ? $"{urunKey}_WorkTracking_AllMonths_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                : $"{urunKey}_IsTakip_TumAylar_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
            return CreateTaskExcelFile(rows, sheetName, fileName, isEn);
        }

        private static string GetExportDisplayDurum(string? taskDurum, int? musteriId, IReadOnlyDictionary<int, string> musteriDurumById)
        {
            var clean = (taskDurum ?? string.Empty).Trim();

            if (IsArchiveDurum(clean) &&
                musteriId.HasValue &&
                musteriId.Value > 0 &&
                musteriDurumById.TryGetValue(musteriId.Value, out var musteriDurum) &&
                !string.IsNullOrWhiteSpace(musteriDurum))
            {
                return musteriDurum.Trim();
            }

            return clean;
        }

        private List<ExportTaskRow> BuildExportTaskRows(IQueryable<JiraTask> query, bool orderByJiraId)
        {
            var musteriDurumById = _context.Musteriler
                .AsNoTracking()
                .Select(x => new { x.MusteriID, x.Durum })
                .ToList()
                .ToDictionary(x => x.MusteriID, x => (x.Durum ?? string.Empty).Trim());

            var yorumLookup = _context.JiraYorumlar
                .AsNoTracking()
                .OrderBy(y => y.Tarih)
                .Select(y => new
                {
                    y.JiraTaskId,
                    y.Ekleyen,
                    y.YorumMetni,
                    y.Tarih
                })
                .ToList()
                .GroupBy(y => y.JiraTaskId)
                .ToDictionary(
                    g => g.Key,
                    g => string.Join(Environment.NewLine + Environment.NewLine,
                        g.Select(y =>
                            $"{y.Tarih:dd.MM.yyyy HH:mm} - {(y.Ekleyen ?? "").Trim()}" +
                            (string.IsNullOrWhiteSpace(y.YorumMetni) ? string.Empty : Environment.NewLine + y.YorumMetni.Trim()))));

            var rows = query
                .AsEnumerable()
                .Select(x => new ExportTaskRow
                {
                    Id = x.Id,
                    MusteriID = x.MusteriID,
                    MusteriAdi = x.MusteriAdi,
                    JiraId = x.JiraId,
                    TalepKonusu = CleanTaskSubject(x.TalepKonusu),
                    TalepTuru = x.TalepTuru,
                    TalepAcan = x.TalepAcan,
                    TakipEden = x.TakipEden,
                    Durum = GetExportDisplayDurum(x.Durum, x.MusteriID, musteriDurumById),
                    OlusturmaTarihi = x.OlusturmaTarihi
                })
                .ToList();

            var orderedRows = orderByJiraId
                ? rows.OrderBy(x => x.JiraId ?? string.Empty, new JiraIdNaturalComparer()).ThenByDescending(x => x.OlusturmaTarihi)
                : rows.OrderByDescending(x => x.OlusturmaTarihi).ThenBy(x => x.JiraId ?? string.Empty, new JiraIdNaturalComparer());

            return orderedRows
                .Select(x =>
                {
                    x.Yorumlar = yorumLookup.TryGetValue(x.Id, out var yorumlar) ? yorumlar : string.Empty;
                    return x;
                })
                .ToList();
        }

        private IActionResult CreateTaskExcelFile(List<ExportTaskRow> rows, string sheetName, string fileName, bool isEn)
        {
            using var ms = new MemoryStream();

            using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
            {
                var workbookPart = document.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
                stylesPart.Stylesheet = CreateStylesheet();
                stylesPart.Stylesheet.Save();

                var sheets = workbookPart.Workbook.AppendChild(new Sheets());

                uint sheetId = 1;

                var isTakipPart = workbookPart.AddNewPart<WorksheetPart>();
                var isTakipSheetData = new SheetData();
                var isTakipWorksheet = new Worksheet();

                var isTakipColumns = new Columns(
                    CreateColumn(1, 1, 24),  
                    CreateColumn(2, 2, 48),  
                    CreateColumn(3, 3, 16),  
                    CreateColumn(4, 4, 20),  
                    CreateColumn(5, 5, 20),  
                    CreateColumn(6, 6, 16),  
                    CreateColumn(7, 7, 20),  
                    CreateColumn(8, 8, 60)   
                );

                isTakipWorksheet.Append(isTakipColumns);
                isTakipWorksheet.Append(isTakipSheetData);

                BuildTaskSheet(isTakipSheetData, isTakipWorksheet, rows, isEn);

                isTakipPart.Worksheet = isTakipWorksheet;
                isTakipPart.Worksheet.Save();

                sheets.Append(new Sheet
                {
                    Id = workbookPart.GetIdOfPart(isTakipPart),
                    SheetId = sheetId++,
                    Name = sheetName
                });

                workbookPart.Workbook.Save();
            }

            ms.Position = 0;

            return File(
                ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName
            );
        }

        private IActionResult CreateAssignedTaskExcelFile(List<ExportTaskRow> rows, string sheetName, string fileName, bool isEn)
        {
            using var ms = new MemoryStream();

            using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
            {
                var workbookPart = document.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
                stylesPart.Stylesheet = CreateStylesheet();
                stylesPart.Stylesheet.Save();

                var sheets = workbookPart.Workbook.AppendChild(new Sheets());

                var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
                var sheetData = new SheetData();
                var worksheet = new Worksheet();

                var columns = new Columns(
                    CreateColumn(1, 1, 10),   
                    CreateColumn(2, 2, 10),   
                    CreateColumn(3, 3, 18),   
                    CreateColumn(4, 4, 18),   
                    CreateColumn(5, 5, 28),   
                    CreateColumn(6, 6, 48),   
                    CreateColumn(7, 7, 18),   
                    CreateColumn(8, 8, 22),   
                    CreateColumn(9, 9, 22),   
                    CreateColumn(10, 10, 24), 
                    CreateColumn(11, 11, 22), 
                    CreateColumn(12, 12, 70)  
                );

                worksheet.Append(columns);
                worksheet.Append(sheetData);

                BuildAssignedTaskSheet(sheetData, worksheet, rows, isEn);

                worksheetPart.Worksheet = worksheet;
                worksheetPart.Worksheet.Save();

                sheets.Append(new Sheet
                {
                    Id = workbookPart.GetIdOfPart(worksheetPart),
                    SheetId = 1,
                    Name = sheetName
                });

                workbookPart.Workbook.Save();
            }

            ms.Position = 0;

            return File(
                ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName
            );
        }

        [HttpGet]
        public IActionResult ExportExcelDisiIsler(string? q, string? lang, string? urun = null)
        {
            var isEn = IsEnglishExport(lang);
            q = (q ?? string.Empty).Trim();
            urun = (IsSahaKullanici() || IsSahaSuperAdminKullanici()) ? "OPERASYON" : NormalizeUrun(urun);

            var query = _context.JiraTasks
                .AsNoTracking()
                .Where(x => ExcelDisiTalepTurleri.Contains((x.TalepTuru ?? string.Empty).Trim()))
                .AsQueryable();
            query = ApplyUrunTaskFilter(query, urun);

            if (!string.IsNullOrWhiteSpace(q))
            {
                var qq = q.ToLowerInvariant();
                query = query.Where(t =>
                    (t.MusteriAdi ?? string.Empty).ToLower().Contains(qq) ||
                    (t.JiraId ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepKonusu ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepTuru ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepAcan ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TakipEden ?? string.Empty).ToLower().Contains(qq) ||
                    (t.Durum ?? string.Empty).ToLower().Contains(qq));
            }

            var musteriDurumById = _context.Musteriler
                .AsNoTracking()
                .Select(x => new { x.MusteriID, x.Durum })
                .ToList()
                .ToDictionary(x => x.MusteriID, x => (x.Durum ?? string.Empty).Trim());

            var yorumLookup = _context.JiraYorumlar
                .AsNoTracking()
                .OrderBy(y => y.Tarih)
                .Select(y => new
                {
                    y.JiraTaskId,
                    y.Ekleyen,
                    y.YorumMetni,
                    y.Tarih
                })
                .ToList()
                .GroupBy(y => y.JiraTaskId)
                .ToDictionary(
                    g => g.Key,
                    g => string.Join(Environment.NewLine + Environment.NewLine,
                        g.Select(y =>
                            $"{y.Tarih:dd.MM.yyyy HH:mm} - {(y.Ekleyen ?? string.Empty).Trim()}" +
                            (string.IsNullOrWhiteSpace(y.YorumMetni) ? string.Empty : Environment.NewLine + y.YorumMetni.Trim()))));

            var rows = query
                .AsEnumerable()
                .Select(x => new ExportTaskRow
                {
                    Id = x.Id,
                    MusteriID = x.MusteriID,
                    MusteriAdi = x.MusteriAdi,
                    JiraId = x.JiraId,
                    TalepKonusu = CleanTaskSubject(x.TalepKonusu),
                    TalepTuru = x.TalepTuru,
                    TalepAcan = x.TalepAcan,
                    TakipEden = x.TakipEden,
                    Durum = GetExportDisplayDurum(x.Durum, x.MusteriID, musteriDurumById),
                    OlusturmaTarihi = x.OlusturmaTarihi
                })
                .ToList()
                .OrderBy(x => x.JiraId ?? string.Empty, new JiraIdNaturalComparer())
                .ThenByDescending(x => x.OlusturmaTarihi)
                .Select(x =>
                {
                    x.Yorumlar = yorumLookup.TryGetValue(x.Id, out var yorumlar) ? yorumlar : string.Empty;
                    return x;
                })
                .ToList();

            using var ms = new MemoryStream();

            using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
            {
                var workbookPart = document.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
                stylesPart.Stylesheet = CreateStylesheet();
                stylesPart.Stylesheet.Save();

                var sheets = workbookPart.Workbook.AppendChild(new Sheets());

                uint sheetId = 1;

                var isTakipPart = workbookPart.AddNewPart<WorksheetPart>();
                var isTakipSheetData = new SheetData();
                var isTakipWorksheet = new Worksheet();

                var isTakipColumns = new Columns(
                    CreateColumn(1, 1, 24),
                    CreateColumn(2, 2, 48),
                    CreateColumn(3, 3, 16),
                    CreateColumn(4, 4, 20),
                    CreateColumn(5, 5, 20),
                    CreateColumn(6, 6, 16),
                    CreateColumn(7, 7, 20),
                    CreateColumn(8, 8, 60)
                );

                isTakipWorksheet.Append(isTakipColumns);
                isTakipWorksheet.Append(isTakipSheetData);

                BuildTaskSheet(isTakipSheetData, isTakipWorksheet, rows, isEn);

                isTakipPart.Worksheet = isTakipWorksheet;
                isTakipPart.Worksheet.Save();

                sheets.Append(new Sheet
                {
                    Id = workbookPart.GetIdOfPart(isTakipPart),
                    SheetId = sheetId++,
                    Name = isEn ? "ExcludedWork" : "ExcelDisiIsler"
                });

                workbookPart.Workbook.Save();
            }

            ms.Position = 0;

            var urunKey = urun == "VPOS" ? "VPOS" : urun == "MOBIL" ? "Cuzdan" : "PF";
            var fileName = isEn
                ? $"{urunKey}_ExcludedWork_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                : $"{urunKey}_ExcelDisiIsler_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
            return File(
                ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName
            );
        }

        [HttpGet]
        public IActionResult ExcelDisiIsler(string? q, string? urun = null)
        {
            q = (q ?? string.Empty).Trim();
            urun = (IsSahaKullanici() || IsSahaSuperAdminKullanici()) ? "OPERASYON" : NormalizeUrun(urun);

            var query = _context.JiraTasks
                .AsNoTracking()
                .Where(x => ExcelDisiTalepTurleri.Contains((x.TalepTuru ?? string.Empty).Trim()))
                .AsQueryable();
            query = ApplyUrunTaskFilter(query, urun);

            if (!string.IsNullOrWhiteSpace(q))
            {
                var qq = q.ToLowerInvariant();
                query = query.Where(t =>
                    (t.MusteriAdi ?? string.Empty).ToLower().Contains(qq) ||
                    (t.JiraId ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepKonusu ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepTuru ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepAcan ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TakipEden ?? string.Empty).ToLower().Contains(qq) ||
                    (t.Durum ?? string.Empty).ToLower().Contains(qq));
            }

            var tasks = query
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToList();

            ViewBag.Title = "Development and Training Work";
            ViewBag.Q = q;
            ViewBag.Urun = urun;
            return View(tasks);
        }

        private static void BuildAssignedTaskSheet(SheetData sheetData, Worksheet worksheet, List<ExportTaskRow> rows, bool isEn)
        {
            uint currentRow = 1;

            var header = new Row { RowIndex = currentRow };
            header.Append(
                CreateTextCell("A", currentRow, L(isEn, "Yıl", "Year"), 1),
                CreateTextCell("B", currentRow, L(isEn, "Ay No", "Month No"), 1),
                CreateTextCell("C", currentRow, L(isEn, "Ay", "Month"), 1),
                CreateTextCell("D", currentRow, L(isEn, "İş No", "Work No"), 1),
                CreateTextCell("E", currentRow, L(isEn, "Müşteri", "Customer"), 1),
                CreateTextCell("F", currentRow, L(isEn, "Talep Konusu", "Request Subject"), 1),
                CreateTextCell("G", currentRow, L(isEn, "Talep Türü", "Request Type"), 1),
                CreateTextCell("H", currentRow, L(isEn, "Talep Açan", "Requester"), 1),
                CreateTextCell("I", currentRow, L(isEn, "Takip Eden", "Assignee"), 1),
                CreateTextCell("J", currentRow, L(isEn, "Durum", "Status"), 1),
                CreateTextCell("K", currentRow, L(isEn, "Oluşturma Tarihi", "Created Date"), 1),
                CreateTextCell("L", currentRow, L(isEn, "Yorumlar", "Comments"), 1)
            );
            sheetData.Append(header);

            bool alternate = false;

            foreach (var item in rows)
            {
                currentRow++;
                alternate = !alternate;

                uint style = alternate ? 2u : 3u;
                var created = item.OlusturmaTarihi;
                var culture = isEn ? CultureInfo.InvariantCulture : new CultureInfo("tr-TR");
                var monthName = culture.DateTimeFormat.GetMonthName(created.Month);

                var row = new Row { RowIndex = currentRow };
                row.Append(
                    CreateNumberCell("A", currentRow, created.Year.ToString(CultureInfo.InvariantCulture), style),
                    CreateNumberCell("B", currentRow, created.Month.ToString(CultureInfo.InvariantCulture), style),
                    CreateTextCell("C", currentRow, monthName, style),
                    CreateTextCell("D", currentRow, string.IsNullOrWhiteSpace(item.JiraId) ? item.Id.ToString(CultureInfo.InvariantCulture) : item.JiraId!, style),
                    CreateTextCell("E", currentRow, item.MusteriAdi ?? "", style),
                    CreateTextCell("F", currentRow, item.TalepKonusu ?? "", style),
                    CreateTextCell("G", currentRow, TranslateExportValue(item.TalepTuru, isEn), style),
                    CreateTextCell("H", currentRow, item.TalepAcan ?? "", style),
                    CreateTextCell("I", currentRow, item.TakipEden ?? "", style),
                    CreateTextCell("J", currentRow, TranslateExportValue(item.Durum, isEn), style),
                    CreateDateCell("K", currentRow, item.OlusturmaTarihi, alternate ? 4u : 5u),
                    CreateTextCell("L", currentRow, item.Yorumlar ?? "", style)
                );
                sheetData.Append(row);
            }

            if (currentRow >= 1)
            {
                var autoFilter = new AutoFilter { Reference = $"A1:L{Math.Max(currentRow, 1)}" };
                var sheetViews = new SheetViews(
                    new SheetView
                    {
                        WorkbookViewId = 0U,
                        Pane = new Pane
                        {
                            VerticalSplit = 1D,
                            TopLeftCell = "A2",
                            ActivePane = PaneValues.BottomLeft,
                            State = PaneStateValues.Frozen
                        }
                    });

                worksheet.InsertAt(sheetViews, 0);
                worksheet.Append(autoFilter);
            }
        }

        private static void BuildTaskSheet(SheetData sheetData, Worksheet worksheet, List<ExportTaskRow> rows, bool isEn)
        {
            uint currentRow = 1;

            var header = new Row { RowIndex = currentRow };
            header.Append(
                CreateTextCell("A", currentRow, L(isEn, "Müşteri", "Customer"), 1),
                CreateTextCell("B", currentRow, L(isEn, "Talep Konusu", "Request Subject"), 1),
                CreateTextCell("C", currentRow, L(isEn, "Talep Türü", "Request Type"), 1),
                CreateTextCell("D", currentRow, L(isEn, "Talep Açan", "Requester"), 1),
                CreateTextCell("E", currentRow, L(isEn, "Takip Eden", "Assignee"), 1),
                CreateTextCell("F", currentRow, L(isEn, "Durum", "Status"), 1),
                CreateTextCell("G", currentRow, L(isEn, "Oluşturma Tarihi", "Created Date"), 1),
                CreateTextCell("H", currentRow, L(isEn, "Yorumlar", "Comments"), 1)
            );
            sheetData.Append(header);

            bool alternate = false;

            foreach (var item in rows)
            {
                currentRow++;
                alternate = !alternate;

                uint style = alternate ? 2u : 3u;

                var row = new Row { RowIndex = currentRow };
                row.Append(
                    CreateTextCell("A", currentRow, item.MusteriAdi ?? "", style),
                    CreateTextCell("B", currentRow, item.TalepKonusu ?? "", style),
                    CreateTextCell("C", currentRow, TranslateExportValue(item.TalepTuru, isEn), style),
                    CreateTextCell("D", currentRow, item.TalepAcan ?? "", style),
                    CreateTextCell("E", currentRow, item.TakipEden ?? "", style),
                    CreateTextCell("F", currentRow, TranslateExportValue(item.Durum, isEn), style),
                    CreateDateCell("G", currentRow, item.OlusturmaTarihi, alternate ? 4u : 5u),
                    CreateTextCell("H", currentRow, item.Yorumlar ?? "", style)
                );
                sheetData.Append(row);
            }

            if (currentRow >= 1)
            {
                var autoFilter = new AutoFilter { Reference = $"A1:H{Math.Max(currentRow, 1)}" };
                var sheetViews = new SheetViews(
                    new SheetView
                    {
                        WorkbookViewId = 0U,
                        Pane = new Pane
                        {
                            VerticalSplit = 1D,
                            TopLeftCell = "A2",
                            ActivePane = PaneValues.BottomLeft,
                            State = PaneStateValues.Frozen
                        }
                    });

                worksheet.InsertAt(sheetViews, 0);
                worksheet.Append(autoFilter);
            }
        }

        private static Stylesheet CreateStylesheet()
        {
            var fonts = new Fonts(
                new Font(
                    new FontSize { Val = 11 }
                ),
                new Font(
                    new Bold(),
                    new FontSize { Val = 11 },
                    new Color { Rgb = HexBinaryValue.FromString("FFFFFFFF") }
                )
            );

            var fills = new Fills(
                new Fill(new PatternFill { PatternType = PatternValues.None }),
                new Fill(new PatternFill { PatternType = PatternValues.Gray125 }),
                new Fill(new PatternFill(
                    new ForegroundColor { Rgb = HexBinaryValue.FromString("1F4E78") },
                    new BackgroundColor { Indexed = 64U }
                )
                { PatternType = PatternValues.Solid }),
                new Fill(new PatternFill(
                    new ForegroundColor { Rgb = HexBinaryValue.FromString("F8FAFC") },
                    new BackgroundColor { Indexed = 64U }
                )
                { PatternType = PatternValues.Solid }),
                new Fill(new PatternFill(
                    new ForegroundColor { Rgb = HexBinaryValue.FromString("FFFFFF") },
                    new BackgroundColor { Indexed = 64U }
                )
                { PatternType = PatternValues.Solid })
            );

            var borders = new Borders(
                new Border(),
                new Border(
                    new LeftBorder { Style = BorderStyleValues.Thin },
                    new RightBorder { Style = BorderStyleValues.Thin },
                    new TopBorder { Style = BorderStyleValues.Thin },
                    new BottomBorder { Style = BorderStyleValues.Thin },
                    new DiagonalBorder()
                )
            );

            var cellFormats = new CellFormats(
                new CellFormat(), 
                new CellFormat 
                {
                    FontId = 1,
                    FillId = 2,
                    BorderId = 1,
                    ApplyFill = true,
                    ApplyFont = true,
                    ApplyBorder = true,
                    Alignment = new Alignment
                    {
                        Horizontal = HorizontalAlignmentValues.Center,
                        Vertical = VerticalAlignmentValues.Center,
                        WrapText = true
                    },
                    ApplyAlignment = true
                },
                new CellFormat 
                {
                    FontId = 0,
                    FillId = 3,
                    BorderId = 1,
                    ApplyFill = true,
                    ApplyBorder = true,
                    Alignment = new Alignment
                    {
                        Vertical = VerticalAlignmentValues.Center,
                        WrapText = true
                    },
                    ApplyAlignment = true
                },
                new CellFormat 
                {
                    FontId = 0,
                    FillId = 4,
                    BorderId = 1,
                    ApplyFill = true,
                    ApplyBorder = true,
                    Alignment = new Alignment
                    {
                        Vertical = VerticalAlignmentValues.Center,
                        WrapText = true
                    },
                    ApplyAlignment = true
                },
                new CellFormat 
                {
                    FontId = 0,
                    FillId = 3,
                    BorderId = 1,
                    ApplyFill = true,
                    ApplyBorder = true,
                    NumberFormatId = 22,
                    ApplyNumberFormat = true,
                    Alignment = new Alignment
                    {
                        Vertical = VerticalAlignmentValues.Center
                    },
                    ApplyAlignment = true
                },
                new CellFormat 
                {
                    FontId = 0,
                    FillId = 4,
                    BorderId = 1,
                    ApplyFill = true,
                    ApplyBorder = true,
                    NumberFormatId = 22,
                    ApplyNumberFormat = true,
                    Alignment = new Alignment
                    {
                        Vertical = VerticalAlignmentValues.Center
                    },
                    ApplyAlignment = true
                }
            );

            return new Stylesheet(fonts, fills, borders, cellFormats);
        }

        private static Column CreateColumn(uint min, uint max, double width)
        {
            return new Column
            {
                Min = min,
                Max = max,
                Width = width,
                CustomWidth = true
            };
        }

        private static Cell CreateTextCell(string columnName, uint rowIndex, string text, uint styleIndex)
        {
            return new Cell
            {
                CellReference = columnName + rowIndex,
                DataType = CellValues.InlineString,
                StyleIndex = styleIndex,
                InlineString = new InlineString(new Text(text ?? "") { Space = SpaceProcessingModeValues.Preserve })
            };
        }

        private static Cell CreateNumberCell(string columnName, uint rowIndex, string numberText, uint styleIndex)
        {
            return new Cell
            {
                CellReference = columnName + rowIndex,
                CellValue = new CellValue(numberText),
                DataType = CellValues.Number,
                StyleIndex = styleIndex
            };
        }

        private static Cell CreateDateCell(string columnName, uint rowIndex, DateTime dateValue, uint styleIndex)
        {
            return new Cell
            {
                CellReference = columnName + rowIndex,
                CellValue = new CellValue(dateValue.ToOADate().ToString(CultureInfo.InvariantCulture)),
                DataType = CellValues.Number,
                StyleIndex = styleIndex
            };
        }

        public class UpdateDurumModel
        {
            public int Id { get; set; }
            public string YeniDurum { get; set; } = "";
            public string? Aciklama { get; set; }
        }

        public class DeleteModel
        {
            public int Id { get; set; }
        }

        private sealed class JiraIdNaturalComparer : IComparer<string>
        {
            public int Compare(string? x, string? y)
            {
                x ??= "";
                y ??= "";

                if (string.Equals(x, y, StringComparison.OrdinalIgnoreCase))
                    return 0;

                var px = ParseJira(x);
                var py = ParseJira(y);

                var prefixCompare = string.Compare(px.Prefix, py.Prefix, StringComparison.OrdinalIgnoreCase);
                if (prefixCompare != 0)
                    return prefixCompare;

                var numberCompare = px.Number.CompareTo(py.Number);
                if (numberCompare != 0)
                    return numberCompare;

                return string.Compare(px.Raw, py.Raw, StringComparison.OrdinalIgnoreCase);
            }

            private static (string Prefix, long Number, string Raw) ParseJira(string value)
            {
                var v = value.Trim();

                if (string.IsNullOrWhiteSpace(v))
                    return ("", long.MinValue, value);

                var match = Regex.Match(v, @"^(.*?)-?(\d+)$");
                if (match.Success)
                {
                    var prefix = (match.Groups[1].Value ?? "").Trim();
                    var numText = match.Groups[2].Value;

                    if (long.TryParse(numText, out var number))
                        return (prefix, number, value);
                }

                return (v, long.MaxValue, value);
            }
        }


        private sealed class ExportTaskRow
        {
            public int Id { get; set; }
            public int? MusteriID { get; set; }
            public string? MusteriAdi { get; set; }
            public string? JiraId { get; set; }
            public string? TalepKonusu { get; set; }
            public string? TalepTuru { get; set; }
            public string? TalepAcan { get; set; }
            public string? TakipEden { get; set; }
            public string? Durum { get; set; }
            public DateTime OlusturmaTarihi { get; set; }
            public string? Yorumlar { get; set; }
        }

        private sealed class ExportCommentRow
        {
            public int Id { get; set; }
            public int JiraTaskId { get; set; }
            public string? MusteriAdi { get; set; }
            public string? JiraId { get; set; }
            public string? TalepKonusu { get; set; }
            public string? TalepTuru { get; set; }
            public string? TalepAcan { get; set; }
            public string? TakipEden { get; set; }
            public string? Durum { get; set; }
            public string? Ekleyen { get; set; }
            public string? YorumMetni { get; set; }
            public DateTime Tarih { get; set; }
        }

        private sealed class ExportStatusRow
        {
            public string? Durum { get; set; }
            public int KayitSayisi { get; set; }
        }
    }
}
