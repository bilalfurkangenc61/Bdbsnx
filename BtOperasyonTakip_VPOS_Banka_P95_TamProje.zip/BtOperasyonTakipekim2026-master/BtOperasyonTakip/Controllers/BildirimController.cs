﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Security;
using BtOperasyonTakip.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BtOperasyonTakip.Controllers;

[Authorize]
public class BildirimController : Controller
{
    private readonly AppDbContext _context;
    private readonly BildirimStore _bildirimStore;

    public BildirimController(AppDbContext context)
    {
        _context = context;
        _bildirimStore = new BildirimStore(context);
    }

    [HttpGet]
    public IActionResult Index(string? filtre = null)
    {
        var userId = ResolveCurrentUserId();
        if (!userId.HasValue)
            return Forbid();

        var sadeceOkunmamis = string.Equals(filtre, "okunmamis", StringComparison.OrdinalIgnoreCase);
        var model = _bildirimStore.Listele(userId.Value, sadeceOkunmamis, 250);

        ViewBag.Filtre = filtre ?? string.Empty;
        ViewBag.OkunmamisSayisi = _bildirimStore.OkunmamisSayisi(userId.Value);

        return View(model);
    }

    [HttpGet]
    public IActionResult Ac(int id)
    {
        var userId = ResolveCurrentUserId();
        if (!userId.HasValue)
            return Forbid();

        var bildirim = _bildirimStore.Getir(id, userId.Value);
        if (bildirim == null)
            return RedirectToAction(nameof(Index));

        if (!bildirim.OkunduMu)
            _bildirimStore.OkunduYap(id, userId.Value);

        if (string.Equals(bildirim.IlgiliVarlikTuru, "JiraTask", StringComparison.OrdinalIgnoreCase) &&
            bildirim.IlgiliVarlikId.HasValue && bildirim.IlgiliVarlikId.Value > 0)
        {
            if (IsSahaFamily())
                return RedirectToAction("SahaIndex", "Takip", new { selectedTaskId = bildirim.IlgiliVarlikId.Value });

            return RedirectToAction("Index", "Takip", new { selectedTaskId = bildirim.IlgiliVarlikId.Value });
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult TumunuOkunduYap(string? returnUrl = null)
    {
        var userId = ResolveCurrentUserId();
        if (!userId.HasValue)
            return Forbid();

        _bildirimStore.TumunuOkunduYap(userId.Value);

        if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
            return LocalRedirect(returnUrl);

        return RedirectToAction(nameof(Index));
    }

    private int? ResolveCurrentUserId()
    {
        var claimValue = User.FindFirst("UserId")?.Value;
        if (int.TryParse(claimValue, out var claimUserId) && claimUserId > 0)
            return claimUserId;

        var name = (User.Identity?.Name ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(name))
            return null;

        return _context.Users
            .AsNoTracking()
            .Where(x => x.UserName == name || x.Email == name || x.FullName == name)
            .Select(x => (int?)x.Id)
            .FirstOrDefault();
    }

    private bool IsSahaFamily()
    {
        return User.IsInRole(AppRoles.Saha) ||
               User.IsInRole(AppRoles.KurumsalSaha) ||
               User.IsInRole(AppRoles.SahaSuperAdmin) ||
               User.IsInRole("Kurumsal Saha") ||
               User.IsInRole("Saha Süper Admin") ||
               User.IsInRole("Saha Super Admin");
    }
}
