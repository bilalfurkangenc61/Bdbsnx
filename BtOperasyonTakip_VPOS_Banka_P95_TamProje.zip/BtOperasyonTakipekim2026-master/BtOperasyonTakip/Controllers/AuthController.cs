using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace BtOperasyonTakip.Controllers
{
    public class AuthController : Controller
    {
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }

        private static string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(bytes);
        }

        private static string ResolveRole(User user)
        {
            if (string.Equals(
                    user.UserName,
                    "admin",
                    StringComparison.OrdinalIgnoreCase))
            {
                return AppRoles.Admin;
            }

            return string.IsNullOrWhiteSpace(user.Role)
                ? AppRoles.Saha
                : user.Role;
        }

        private static bool IsSahaFamilyRole(string? role)
        {
            return
                string.Equals(role, AppRoles.Saha, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, AppRoles.KurumsalSaha, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, "Kurumsal Saha", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, AppRoles.SahaSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, "Saha Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, "Saha Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsOperasyonFamilyRole(string? role)
        {
            return
                string.Equals(role, AppRoles.Operasyon, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, AppRoles.OperasyonSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, "Operasyon Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(role, "Operasyon Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsVposRole(string? role)
        {
            return string.Equals(
                role,
                AppRoles.VposKullanici,
                StringComparison.OrdinalIgnoreCase);
        }

        private static ClaimsPrincipal CreatePrincipal(User user)
        {
            var role = ResolveRole(user);

            var claims = new List<Claim>
            {
                new Claim(
                    ClaimTypes.Name,
                    user.FullName ?? user.UserName),

                new Claim(
                    ClaimTypes.Email,
                    user.Email ?? string.Empty),

                new Claim(
                    "UserId",
                    user.Id.ToString()),

                new Claim(
                    ClaimTypes.Role,
                    role)
            };

            var identity = new ClaimsIdentity(
                claims,
                CookieAuthenticationDefaults.AuthenticationScheme);

            return new ClaimsPrincipal(identity);
        }

        // ============================================================
        // LOGIN - GET
        // ============================================================
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            if (User.Identity?.IsAuthenticated == true)
            {
                if (User.IsInRole(AppRoles.VposKullanici))
                {
                    return RedirectToAction("AnaSayfa", "Vpos");
                }

                if (User.IsInRole(AppRoles.Operasyon) ||
                    User.IsInRole(AppRoles.OperasyonSuperAdmin) ||
                    User.IsInRole("Operasyon Süper Admin") ||
                    User.IsInRole("Operasyon Super Admin") ||
                    User.IsInRole(AppRoles.Admin))
                {
                    return RedirectToAction("Index", "Dashboard");
                }

                if (User.IsInRole(AppRoles.Saha) ||
                    User.IsInRole(AppRoles.KurumsalSaha) ||
                    User.IsInRole("Kurumsal Saha") ||
                    User.IsInRole(AppRoles.SahaSuperAdmin))
                {
                    return RedirectToAction("SahaIndex", "Takip");
                }

                if (User.IsInRole(AppRoles.Uyum))
                {
                    return RedirectToAction("Index", "Uyum");
                }

                return RedirectToAction("Index", "Dashboard");
            }

            return View();
        }

        // ============================================================
        // ADMIN SEED
        // ============================================================
        [HttpGet]
        [AllowAnonymous]
        public IActionResult SeedAdmin()
        {
            const string username = "admin";
            const string password = "123456";
            const string email = "admin@local";

            var hash = HashPassword(password);

            var user = _context.Users
                .FirstOrDefault(x => x.UserName == username);

            if (user == null)
            {
                user = new User
                {
                    UserName = username,
                    FullName = "Admin",
                    Email = email,
                    PasswordHash = hash,
                    CreatedAt = DateTime.Now,
                    Role = AppRoles.Admin
                };

                _context.Users.Add(user);
            }
            else
            {
                user.PasswordHash = hash;
                user.Role = AppRoles.Admin;

                if (string.IsNullOrWhiteSpace(user.Email))
                {
                    user.Email = email;
                }
            }

            _context.SaveChanges();

            return Content(
                $"OK. User: {username} / Password: {password}");
        }

        // ============================================================
        // LOGIN - POST
        // ============================================================
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login(
            string username,
            string password,
            bool rememberMe)
        {
            if (string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password))
            {
                ViewBag.Error = "Kullanıcı adı ve parola zorunludur.";
                return View();
            }

            var hash = HashPassword(password);

            var user = _context.Users
                .FirstOrDefault(u =>
                    u.UserName == username &&
                    u.PasswordHash == hash);

            if (user == null)
            {
                ViewBag.Error = "Kullanıcı adı veya parola hatalı!";
                return View();
            }

            var role = ResolveRole(user);
            var principal = CreatePrincipal(user);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal,
                new AuthenticationProperties
                {
                    IsPersistent = rememberMe,
                    ExpiresUtc = rememberMe
                        ? DateTimeOffset.UtcNow.AddDays(7)
                        : DateTimeOffset.UtcNow.AddHours(12),
                    AllowRefresh = true
                });

            if (IsVposRole(role))
            {
                return RedirectToAction("AnaSayfa", "Vpos");
            }

            if (IsOperasyonFamilyRole(role) ||
                string.Equals(role, AppRoles.Admin, StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToAction("Index", "Dashboard");
            }

            if (string.Equals(role, AppRoles.Uyum, StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToAction("Index", "Uyum");
            }

            if (IsSahaFamilyRole(role))
            {
                return RedirectToAction("SahaIndex", "Takip");
            }

            return RedirectToAction("SahaIndex", "Takip");
        }

        // ============================================================
        // REGISTER - GET
        // ============================================================
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Register()
        {
            return View();
        }

        // ============================================================
        // REGISTER - POST
        // ============================================================
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Register(
            string fullName,
            string username,
            string email,
            string password,
            string role)
        {
            if (_context.Users.Any(u => u.UserName == username))
            {
                ViewBag.Error = "Bu kullanıcı adı zaten mevcut.";
                return View();
            }

            if (_context.Users.Any(u => u.Email == email))
            {
                ViewBag.Error = "Bu e-posta adresi zaten mevcut.";
                return View();
            }

            var requestedRole = string.IsNullOrWhiteSpace(role)
                ? AppRoles.Saha
                : role.Trim();

            var isRestrictedRole =
                string.Equals(requestedRole, AppRoles.SahaSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(requestedRole, AppRoles.OperasyonSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(requestedRole, "Saha Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(requestedRole, "Saha Super Admin", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(requestedRole, "Operasyon Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(requestedRole, "Operasyon Super Admin", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(requestedRole, AppRoles.Admin, StringComparison.OrdinalIgnoreCase);

            if (isRestrictedRole &&
                !User.IsInRole(AppRoles.Admin))
            {
                requestedRole = AppRoles.Saha;
            }

            var user = new User
            {
                FullName = fullName,
                UserName = username,
                Email = email,
                PasswordHash = HashPassword(password),
                CreatedAt = DateTime.Now,
                Role = requestedRole
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            await SignInUser(user);

            var resolvedRole = ResolveRole(user);

            if (IsVposRole(resolvedRole))
            {
                return RedirectToAction("AnaSayfa", "Vpos");
            }

            if (IsOperasyonFamilyRole(resolvedRole) ||
                string.Equals(resolvedRole, AppRoles.Admin, StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToAction("Index", "Dashboard");
            }

            if (string.Equals(resolvedRole, AppRoles.Uyum, StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToAction("Index", "Uyum");
            }

            if (IsSahaFamilyRole(resolvedRole))
            {
                return RedirectToAction("SahaIndex", "Takip");
            }

            return RedirectToAction("SahaIndex", "Takip");
        }

        // ============================================================
        // LOGOUT
        // ============================================================
        [HttpGet]
        [AllowAnonymous]
        [Route("/Auth/Logout")]
        public async Task<IActionResult> Logout()
        {
            HttpContext.Session.Clear();

            await HttpContext.SignOutAsync(
                CookieAuthenticationDefaults.AuthenticationScheme);

            // Aktif cookie'ler.
            Response.Cookies.Delete(
                "BtOps.Auth",
                new CookieOptions { Path = "/" });

            Response.Cookies.Delete(
                "BtOps.Session",
                new CookieOptions { Path = "/" });

            // Önceki fix sürümlerinden kalmış cookie'leri de temizle.
            Response.Cookies.Delete(
                "BtOps.Auth.v3",
                new CookieOptions { Path = "/" });

            Response.Cookies.Delete(
                "BtOps.Session.v3",
                new CookieOptions { Path = "/" });

            Response.Cookies.Delete(
                "BtOps.Auth.v2",
                new CookieOptions { Path = "/" });

            Response.Cookies.Delete(
                "BtOps.Session.v2",
                new CookieOptions { Path = "/" });

            Response.Cookies.Delete(
                ".AspNetCore.Cookies",
                new CookieOptions { Path = "/" });

            return Redirect("/Auth/Login");
        }

        private async Task SignInUser(User user)
        {
            var principal = CreatePrincipal(user);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal,
                new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddDays(7),
                    AllowRefresh = true
                });
        }
    }
}
