using System.Security.Claims;
using BtOperasyonTakip.Data;
using BtOperasyonTakip.Security;
using BtOperasyonTakip.Services;
using BtOperasyonTakip.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BtOperasyonTakip.Controllers;

[Authorize(Roles =
    AppRoles.VposKullanici + "," +
    AppRoles.Operasyon + "," +
    AppRoles.OperasyonSuperAdmin + "," +
    AppRoles.Admin + ",Operasyon Süper Admin,Operasyon Super Admin")]
[Route("Vpos/AnaSayfa")]
public sealed class VposDashboardController : Controller
{
    private const string VposCustomerParamType = "UrunMusteri:VPOS";

    private readonly AppDbContext _context;
    private readonly IVposGrafanaService _grafanaService;
    private readonly IVposMonitoringCredentialStore _credentialStore;

    public VposDashboardController(
        AppDbContext context,
        IVposGrafanaService grafanaService,
        IVposMonitoringCredentialStore credentialStore)
    {
        _context = context;
        _grafanaService = grafanaService;
        _credentialStore = credentialStore;
    }

    [HttpGet("")]
    public async Task<IActionResult> Index(int dakika = 30, CancellationToken cancellationToken = default)
    {
        var userId = GetCurrentUserId();
        if (userId <= 0)
            return Forbid();

        dakika = NormalizeLookbackMinutes(dakika);
        ViewBag.SelectedMinutes = dakika;
        ViewBag.PeriodLabel = BuildPeriodLabel(dakika);

        var vposIdTexts = await _context.Parametreler
            .AsNoTracking()
            .Where(x => x.Tur == VposCustomerParamType && x.ParAdi != null)
            .Select(x => x.ParAdi!)
            .ToListAsync(cancellationToken);

        var vposIds = vposIdTexts
            .Select(x => int.TryParse(x, out var id) ? id : 0)
            .Where(x => x > 0)
            .Distinct()
            .ToList();

        var monthStart = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        var nextMonth = monthStart.AddMonths(1);

        var toplamMusteri = vposIds.Count == 0
            ? 0
            : await _context.Musteriler
                .AsNoTracking()
                .CountAsync(x => vposIds.Contains(x.MusteriID), cancellationToken);

        var buAyEklenen = vposIds.Count == 0
            ? 0
            : await _context.Musteriler
                .AsNoTracking()
                .CountAsync(
                    x => vposIds.Contains(x.MusteriID) &&
                         x.KayitTarihi.HasValue &&
                         x.KayitTarihi.Value >= monthStart &&
                         x.KayitTarihi.Value < nextMonth,
                    cancellationToken);

        var credential = await _credentialStore.GetAsync(userId, cancellationToken);

        var model = new VposDashboardViewModel
        {
            ToplamMusteri = toplamMusteri,
            BuAyEklenen = buAyEklenen,
            GrafanaBilgisiKayitli = credential != null,
            GrafanaKullaniciAdi = credential?.Username,
            GrafanaUrl = credential?.GrafanaUrl,
            ElasticUrl = credential?.ElasticUrl,
            GrafanaMesaj = credential == null
                ? "Grafana bağlantısı için bilgilerinizi bir kez kaydedin."
                : null
        };

        if (credential != null)
        {
            var grafana = await _grafanaService.GetSnapshotAsync(
                credential,
                dakika,
                cancellationToken);

            model.LookbackMonths = grafana.LookbackMonths;
            model.GrafanaHazir = grafana.Basarili;
            model.GrafanaMesaj = grafana.Mesaj;
            model.GrafanaGuncellemeZamani = grafana.AlinmaZamani;
            model.Aylar = grafana.Aylar;
            model.FirmaSerileri = grafana.FirmaSerileri;
            model.HataKodlari = grafana.HataKodlari;
            model.HataAlanFirmalar = grafana.HataAlanFirmalar;
            model.Insights = grafana.Insights;
            model.BankaPerformansi = grafana.BankaPerformansi;
            model.DatasourceAdi = grafana.DatasourceAdi;
            model.DatasourceUid = grafana.DatasourceUid;
            model.Index = grafana.Index;
            model.TimestampField = grafana.TimestampField;
            model.CompanyField = grafana.CompanyField;
            model.ErrorCodeField = grafana.ErrorCodeField;
        }

        return View(model);
    }

    [HttpGet("AylikRapor")]
    public async Task<IActionResult> AylikRapor(int yil = 0, CancellationToken cancellationToken = default)
    {
        var userId = GetCurrentUserId();
        if (userId <= 0) return Forbid();
        if (yil == 0) yil = DateTime.UtcNow.Year;
        if (yil < 2020 || yil > DateTime.UtcNow.Year) return BadRequest("Geçersiz yıl");
        var credential = await _credentialStore.GetAsync(userId, cancellationToken);
        if (credential == null) return BadRequest("Grafana bağlantısı kayıtlı değil");
        try { return Json(await _grafanaService.GetMonthlySummaryAsync(credential, yil, cancellationToken)); }
        catch (Exception ex) { return StatusCode(502, new { mesaj = "Aylık rapor alınamadı", detay = ex.Message }); }
    }

    [HttpPost("Grafana/Baglan")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> GrafanaBaglan(
        string grafanaUrl,
        string elasticUrl,
        string grafanaUsername,
        string grafanaPassword,
        CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId <= 0)
            return Forbid();

        var credential = new VposMonitoringCredential
        {
            GrafanaUrl = grafanaUrl?.Trim() ?? string.Empty,
            ElasticUrl = elasticUrl?.Trim() ?? string.Empty,
            Username = grafanaUsername?.Trim() ?? string.Empty,
            Password = grafanaPassword ?? string.Empty
        };

        var test = await _grafanaService.TestConnectionAsync(
            credential,
            cancellationToken);

        if (!test.Basarili)
        {
            TempData["GrafanaError"] = test.Mesaj ?? "Grafana bağlantısı kurulamadı.";
            TempData["GrafanaUrl"] = credential.GrafanaUrl;
            TempData["ElasticUrl"] = credential.ElasticUrl;
            TempData["GrafanaUsername"] = credential.Username;
            return RedirectToAction(nameof(Index));
        }

        await _credentialStore.SaveAsync(
            userId,
            credential,
            cancellationToken);

        TempData["GrafanaSuccess"] = test.Mesaj ?? "Grafana bağlantısı kaydedildi.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("Grafana/Unut")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> GrafanaUnut(CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId <= 0)
            return Forbid();

        await _credentialStore.DeleteAsync(userId, cancellationToken);
        TempData["GrafanaSuccess"] = "Grafana bağlantı bilgileriniz silindi.";

        return RedirectToAction(nameof(Index));
    }

    [HttpGet("GrafanaTest")]
    public async Task<IActionResult> GrafanaTest(CancellationToken cancellationToken)
    {
        var userId = GetCurrentUserId();
        if (userId <= 0)
            return Forbid();

        var credential = await _credentialStore.GetAsync(userId, cancellationToken);
        if (credential == null)
        {
            return BadRequest(new
            {
                basarili = false,
                mesaj = "Grafana bağlantı bilgisi kayıtlı değil."
            });
        }

        var test = await _grafanaService.TestConnectionAsync(
            credential,
            cancellationToken);

        return Json(new
        {
            test.Basarili,
            test.Mesaj,
            test.DatasourceAdi,
            test.DatasourceUid,
            test.Index,
            test.TimestampField,
            test.CompanyField,
            test.ErrorCodeField
        });
    }


    private static int NormalizeLookbackMinutes(int minutes)
    {
        var allowed = new[] { 15, 30, 60, 180, 360, 720, 1440 };

        return allowed
            .OrderBy(x => Math.Abs(x - minutes))
            .First();
    }

    private static string BuildPeriodLabel(int minutes)
    {
        return minutes switch
        {
            15 => "Son 15 dakika",
            30 => "Son 30 dakika",
            60 => "Son 1 saat",
            180 => "Son 3 saat",
            360 => "Son 6 saat",
            720 => "Son 12 saat",
            1440 => "Son 24 saat",
            _ => $"Son {minutes} dakika"
        };
    }

    private int GetCurrentUserId()
    {
        var raw = User.FindFirstValue("UserId");
        return int.TryParse(raw, out var userId) ? userId : 0;
    }
}
