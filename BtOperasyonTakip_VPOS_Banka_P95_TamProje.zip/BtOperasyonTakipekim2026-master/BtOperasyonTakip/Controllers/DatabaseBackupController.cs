﻿using BtOperasyonTakip.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Globalization;
using System.Text.RegularExpressions;

namespace BtOperasyonTakip.Controllers
{
    [Authorize(Roles = "Admin")]
    public class DatabaseBackupController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<DatabaseBackupController> _logger;
        private readonly IConfiguration _configuration;

        public DatabaseBackupController(
            AppDbContext context,
            IWebHostEnvironment env,
            ILogger<DatabaseBackupController> logger,
            IConfiguration configuration)
        {
            _context = context;
            _env = env;
            _logger = logger;
            _configuration = configuration;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var backupDirectory = GetBackupDirectory();
            Directory.CreateDirectory(backupDirectory);

            var backups = Directory
                .GetFiles(backupDirectory, "*.bak")
                .Select(path => new DatabaseBackupFileViewModel
                {
                    FileName = Path.GetFileName(path),
                    FullPath = path,
                    CreatedAt = System.IO.File.GetCreationTime(path),
                    SizeBytes = new FileInfo(path).Length
                })
                .OrderByDescending(x => x.CreatedAt)
                .ToList();

            ViewBag.BackupDirectory = backupDirectory;
            ViewBag.ConnectionName = GetDetectedConnectionName();

            try
            {
                var connectionString = GetSqlServerConnectionString();
                ViewBag.SqlServiceAccount = await GetSqlServerServiceAccountAsync(connectionString);
                ViewBag.DatabaseName = await GetCurrentDatabaseNameAsync(connectionString);
            }
            catch
            {
                ViewBag.SqlServiceAccount = "Could not be read";
                ViewBag.DatabaseName = "Could not be read";
            }

            return View(backups);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateBackup()
        {
            var backupDirectory = GetBackupDirectory();
            Directory.CreateDirectory(backupDirectory);

            try
            {
                var connectionString = GetSqlServerConnectionString();
                var databaseName = await GetCurrentDatabaseNameAsync(connectionString);
                var safeDatabaseName = MakeSafeFileName(databaseName);

                var fileName = $"{safeDatabaseName}_{DateTime.Now:yyyyMMdd_HHmmss}.bak";
                var backupPath = Path.Combine(backupDirectory, fileName);

                await BackupDatabaseAsync(connectionString, backupPath);

                TempData["Success"] = $"Database backup created: {fileName}";
            }
            catch (SqlException ex) when (IsBackupPermissionError(ex))
            {
                _logger.LogError(ex, "SQL Server backup folder permission error.");

                var connectionString = GetSqlServerConnectionString();
                var serviceAccount = await GetSqlServerServiceAccountSafeAsync(connectionString);

                TempData["Error"] =
                    "Backup failed: SQL Server cannot write to this folder. " +
                    $"Folder: {backupDirectory} | " +
                    $"SQL Server service account: {serviceAccount} | " +
                    "Solution: Grant Modify/Write permission on this folder to the SQL Server service account.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating the database backup.");
                TempData["Error"] = "Backup oluşturulamadı. Ayrıntılar sunucu günlüğüne kaydedildi.";
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Download(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                TempData["Error"] = "Invalid file name.";
                return RedirectToAction(nameof(Index));
            }

            var safeFileName = Path.GetFileName(fileName);

            if (!safeFileName.EndsWith(".bak", StringComparison.OrdinalIgnoreCase))
            {
                TempData["Error"] = "Only .bak files can be downloaded.";
                return RedirectToAction(nameof(Index));
            }

            var backupDirectory = GetBackupDirectory();
            var fullPath = Path.Combine(backupDirectory, safeFileName);

            if (!System.IO.File.Exists(fullPath))
            {
                TempData["Error"] = "Backup file was not found.";
                return RedirectToAction(nameof(Index));
            }

            return PhysicalFile(fullPath, "application/octet-stream", safeFileName);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                TempData["Error"] = "Invalid file name.";
                return RedirectToAction(nameof(Index));
            }

            var safeFileName = Path.GetFileName(fileName);

            if (!safeFileName.EndsWith(".bak", StringComparison.OrdinalIgnoreCase))
            {
                TempData["Error"] = "Only .bak files can be deleted.";
                return RedirectToAction(nameof(Index));
            }

            var backupDirectory = GetBackupDirectory();
            var fullPath = Path.Combine(backupDirectory, safeFileName);

            try
            {
                if (!System.IO.File.Exists(fullPath))
                {
                    TempData["Error"] = "Backup file was not found.";
                    return RedirectToAction(nameof(Index));
                }

                System.IO.File.Delete(fullPath);
                TempData["Success"] = $"Backup deleted: {safeFileName}";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the database backup. File: {FileName}", safeFileName);
                TempData["Error"] = "Backup silinemedi. Ayrıntılar sunucu günlüğüne kaydedildi.";
            }

            return RedirectToAction(nameof(Index));
        }

        private string GetBackupDirectory()
        {
            var configuredDirectory = _configuration["DatabaseBackup:Directory"];

            if (!string.IsNullOrWhiteSpace(configuredDirectory))
                return configuredDirectory.Trim();

            








            var root = Path.GetPathRoot(_env.ContentRootPath);

            if (string.IsNullOrWhiteSpace(root))
                root = "C:\\";

            return Path.Combine(root, "SqlBackups", "BtOperasyonTakip");
        }

        private string GetDetectedConnectionName()
        {
            var knownNames = new[]
            {
                "DefaultConnection",
                "AppDbContext",
                "BtOperasyonTakipContext",
                "BtOperasyonTakip",
                "SqlServer",
                "DatabaseConnection"
            };

            foreach (var name in knownNames)
            {
                var value = _configuration.GetConnectionString(name);
                if (!string.IsNullOrWhiteSpace(value))
                    return name;
            }

            var dbConnectionString = _context.Database.GetDbConnection().ConnectionString;
            if (!string.IsNullOrWhiteSpace(dbConnectionString))
                return "DbContext";

            return "Not found";
        }

        private string GetSqlServerConnectionString()
        {
            var knownNames = new[]
            {
                "DefaultConnection",
                "AppDbContext",
                "BtOperasyonTakipContext",
                "BtOperasyonTakip",
                "SqlServer",
                "DatabaseConnection"
            };

            foreach (var name in knownNames)
            {
                var value = _configuration.GetConnectionString(name);
                if (!string.IsNullOrWhiteSpace(value))
                    return value;
            }

            var dbContextConnectionString = _context.Database.GetDbConnection().ConnectionString;
            if (!string.IsNullOrWhiteSpace(dbContextConnectionString))
                return dbContextConnectionString;

            throw new InvalidOperationException(
                "ConnectionString was not found. ConnectionStrings:DefaultConnection or AppDbContext must be defined in appsettings.json.");
        }

        private static async Task<string> GetCurrentDatabaseNameAsync(string connectionString)
        {
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            await using var command = connection.CreateCommand();
            command.CommandText = "SELECT DB_NAME();";

            var result = await command.ExecuteScalarAsync();
            var databaseName = Convert.ToString(result, CultureInfo.InvariantCulture);

            if (string.IsNullOrWhiteSpace(databaseName))
                throw new InvalidOperationException("Database name could not be read.");

            return databaseName.Trim();
        }

        private static async Task<string> GetSqlServerServiceAccountAsync(string connectionString)
        {
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            await using var command = connection.CreateCommand();
            command.CommandText = @"
SELECT TOP 1 service_account
FROM sys.dm_server_services
WHERE servicename LIKE 'SQL Server (%'
   OR servicename = 'SQL Server'
ORDER BY servicename;";

            var result = await command.ExecuteScalarAsync();
            var account = Convert.ToString(result, CultureInfo.InvariantCulture);

            return string.IsNullOrWhiteSpace(account) ? "Could not be read" : account.Trim();
        }

        private static async Task<string> GetSqlServerServiceAccountSafeAsync(string connectionString)
        {
            try
            {
                return await GetSqlServerServiceAccountAsync(connectionString);
            }
            catch
            {
                return "Could not be read. Check SQL Server Configuration Manager > SQL Server Services.";
            }
        }

        private static async Task BackupDatabaseAsync(string connectionString, string backupPath)
        {
            await using var connection = new SqlConnection(connectionString);
            await connection.OpenAsync();

            await using var command = connection.CreateCommand();
            command.CommandTimeout = 0;

            command.CommandText = @"
DECLARE @BackupPath nvarchar(4000) = @p0;
DECLARE @DbName sysname = DB_NAME();
DECLARE @Sql nvarchar(max);

SET @Sql = N'BACKUP DATABASE ' + QUOTENAME(@DbName) + N'
TO DISK = @BackupPath
WITH COPY_ONLY, INIT, CHECKSUM, STATS = 10;';

EXEC sp_executesql
    @Sql,
    N'@BackupPath nvarchar(4000)',
    @BackupPath = @BackupPath;
";

            command.Parameters.Add(new SqlParameter("@p0", SqlDbType.NVarChar, 4000)
            {
                Value = backupPath
            });

            await command.ExecuteNonQueryAsync();
        }

        private static bool IsBackupPermissionError(SqlException ex)
        {
            var message = ex.Message ?? string.Empty;

            return message.Contains("Operating system error 5", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("Erişim engellendi", StringComparison.OrdinalIgnoreCase) ||
                   message.Contains("Cannot open backup device", StringComparison.OrdinalIgnoreCase);
        }

        private static string MakeSafeFileName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "Database";

            var safe = Regex.Replace(value.Trim(), @"[^a-zA-Z0-9_\-\.]", "_");
            return string.IsNullOrWhiteSpace(safe) ? "Database" : safe;
        }
    }

    public sealed class DatabaseBackupFileViewModel
    {
        public string FileName { get; set; } = string.Empty;
        public string FullPath { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public long SizeBytes { get; set; }

        public string SizeText
        {
            get
            {
                if (SizeBytes >= 1024L * 1024L * 1024L)
                    return $"{SizeBytes / 1024d / 1024d / 1024d:N2} GB";

                if (SizeBytes >= 1024L * 1024L)
                    return $"{SizeBytes / 1024d / 1024d:N2} MB";

                if (SizeBytes >= 1024L)
                    return $"{SizeBytes / 1024d:N2} KB";

                return $"{SizeBytes:N0} B";
            }
        }
    }
}
