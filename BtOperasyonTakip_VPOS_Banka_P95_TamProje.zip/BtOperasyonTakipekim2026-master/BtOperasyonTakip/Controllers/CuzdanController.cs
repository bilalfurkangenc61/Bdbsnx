using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using BtOperasyonTakip.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.Text;

namespace BtOperasyonTakip.Controllers;

[Authorize(Roles = AppRoles.Operasyon + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin," + AppRoles.Admin)]
public sealed class CuzdanController : Controller
{
    private const string OperasyonCustomerParamType = "UrunMusteri:OPERASYON";
    private const string VposCustomerParamType = "UrunMusteri:VPOS";
    private const string MobilCustomerParamType = "UrunMusteri:MOBIL";
    private const string ProductConfiguredParamType = "UrunMusteri:YAPILANDIRILDI";
    private const string MusteriVknParamType = "MusteriEk:VKN";
    private const string MusteriHariciIdParamType = "MusteriEk:HARICI_ID";
    private const string CuzdanTaskPrefix = "[MOBIL] ";
    private const string CuzdanErrorParamType = "UrunHata:CUZDAN";

    private readonly AppDbContext _context;

    public CuzdanController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult Index() => RedirectToAction(nameof(Musteriler));

    [HttpGet]
    public async Task<IActionResult> Musteriler(string? q)
    {
        var ids = GetCuzdanMusteriIds();
        var query = _context.Musteriler
            .AsNoTracking()
            .Where(x => ids.Contains(x.MusteriID));

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(x =>
                (x.Firma != null && x.Firma.Contains(term)) ||
                (x.SiteUrl != null && x.SiteUrl.Contains(term)) ||
                (x.FirmaYetkilisi != null && x.FirmaYetkilisi.Contains(term)));
        }

        ViewBag.Q = q;
        return View(await query.OrderBy(x => x.Firma).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> YeniMusteri()
    {
        await LoadFormDataAsync();
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> YeniMusteri(
        string? firma,
        string? siteUrl,
        string? teknoloji,
        string? durum,
        string? firmaYetkilisi,
        string? telefon,
        string? aciklama,
        string? vkn,
        string? hariciMusteriId)
    {
        NormalizeFormValues(
            ref firma,
            ref siteUrl,
            ref teknoloji,
            ref durum,
            ref firmaYetkilisi,
            ref telefon,
            ref aciklama,
            ref vkn,
            ref hariciMusteriId);

        await ValidateFormAsync(firma, durum, vkn, hariciMusteriId);

        if (!ModelState.IsValid)
        {
            await LoadFormDataAsync();
            SetFormViewBags(firma, siteUrl, teknoloji, durum, firmaYetkilisi, telefon, aciklama, vkn, hariciMusteriId);
            return View();
        }

        var now = DateTime.Now;
        var currentUser = User.Identity?.Name ?? "Sistem";

        await using var transaction = await _context.Database.BeginTransactionAsync();
        try
        {
            var musteri = new Musteri
            {
                Firma = firma,
                SiteUrl = siteUrl,
                Teknoloji = teknoloji,
                Durum = durum,
                DurumDegisiklikTarihi = now,
                DokumanKontrolBaslangicTarihi = null,
                DokumanGonderimSayisi = 0,
                DokumanGonderildiMi = null,
                TalepSahibi = currentUser,
                Telefon = telefon,
                Aciklama = aciklama,
                KayitTarihi = now,
                FirmaYetkilisi = firmaYetkilisi,
                Kekleyen = currentUser,
                Kaynak = "CUZDAN"
            };

            _context.Musteriler.Add(musteri);
            await _context.SaveChangesAsync();

            var idText = musteri.MusteriID.ToString(CultureInfo.InvariantCulture);
            _context.Parametreler.Add(new Parametre { Tur = ProductConfiguredParamType, ParAdi = idText });
            _context.Parametreler.Add(new Parametre { Tur = MobilCustomerParamType, ParAdi = idText });
            SaveMusteriEkAlanlariNoSave(musteri.MusteriID, vkn, hariciMusteriId);

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            TempData["CuzdanOk"] = "Cüzdan müşterisi oluşturuldu. Kayıt ana Müşteriler ekranına da eklendi.";
            return RedirectToAction(nameof(Musteriler));
        }
        catch
        {
            await transaction.RollbackAsync();
            ModelState.AddModelError(string.Empty, "Müşteri oluşturulamadı. Lütfen tekrar deneyin.");
            await LoadFormDataAsync();
            SetFormViewBags(firma, siteUrl, teknoloji, durum, firmaYetkilisi, telefon, aciklama, vkn, hariciMusteriId);
            return View();
        }
    }

    [HttpGet]
    public async Task<IActionResult> DuzenleMusteri(int id)
    {
        if (!GetCuzdanMusteriIds().Contains(id))
            return NotFound();

        var musteri = await _context.Musteriler
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.MusteriID == id);

        if (musteri == null)
            return NotFound();

        await LoadFormDataAsync();
        var ek = GetMusteriEkAlanlari(id);
        ViewBag.VKN = ek.Vkn;
        ViewBag.HariciMusteriId = ek.HariciMusteriId;
        return View(musteri);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DuzenleMusteri(
        int musteriId,
        string? firma,
        string? siteUrl,
        string? teknoloji,
        string? durum,
        string? firmaYetkilisi,
        string? telefon,
        string? aciklama,
        string? vkn,
        string? hariciMusteriId)
    {
        if (!GetCuzdanMusteriIds().Contains(musteriId))
            return NotFound();

        var musteri = await _context.Musteriler.FirstOrDefaultAsync(x => x.MusteriID == musteriId);
        if (musteri == null)
            return NotFound();

        NormalizeFormValues(
            ref firma,
            ref siteUrl,
            ref teknoloji,
            ref durum,
            ref firmaYetkilisi,
            ref telefon,
            ref aciklama,
            ref vkn,
            ref hariciMusteriId);

        await ValidateFormAsync(firma, durum, vkn, hariciMusteriId);

        if (!ModelState.IsValid)
        {
            await LoadFormDataAsync();
            ViewBag.VKN = vkn;
            ViewBag.HariciMusteriId = hariciMusteriId;

            musteri.Firma = firma;
            musteri.SiteUrl = siteUrl;
            musteri.Teknoloji = teknoloji;
            musteri.Durum = durum;
            musteri.FirmaYetkilisi = firmaYetkilisi;
            musteri.Telefon = telefon;
            musteri.Aciklama = aciklama;
            return View(musteri);
        }

        var eskiDurum = musteri.Durum ?? string.Empty;
        var durumDegisti = !string.Equals(eskiDurum.Trim(), durum, StringComparison.OrdinalIgnoreCase);

        musteri.Firma = firma;
        musteri.SiteUrl = siteUrl;
        musteri.Teknoloji = teknoloji;
        musteri.Durum = durum;
        musteri.FirmaYetkilisi = firmaYetkilisi;
        musteri.Telefon = telefon;
        musteri.Aciklama = aciklama;

        if (durumDegisti)
        {
            musteri.DurumDegisiklikTarihi = DateTime.Now;
            musteri.DokumanGonderildiMi = null;
            musteri.DokumanGonderimSayisi = 0;
            musteri.DokumanKontrolBaslangicTarihi = musteri.DurumDegisiklikTarihi;

            _context.MusteriDurumGecmisleri.Add(new MusteriDurumGecmisi
            {
                MusteriID = musteri.MusteriID,
                EskiDurum = eskiDurum,
                YeniDurum = durum,
                Aciklama = aciklama ?? "Cüzdan müşteri ekranından güncellendi.",
                Tarih = DateTime.Now,
                DegistirenKullanici = User.Identity?.Name
            });
        }

        SetMusteriEkAlanlariNoSave(musteriId, vkn, hariciMusteriId);
        await _context.SaveChangesAsync();

        TempData["CuzdanOk"] = "Müşteri güncellendi. Değişiklik ana Müşteriler ekranına da yansıdı.";
        return RedirectToAction(nameof(Musteriler));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CuzdandanCikar(int id)
    {
        var idText = id.ToString(CultureInfo.InvariantCulture);
        var markers = await _context.Parametreler
            .Where(x => x.Tur == MobilCustomerParamType && x.ParAdi == idText)
            .ToListAsync();

        if (markers.Count == 0)
        {
            TempData["CuzdanError"] = "Müşteri Cüzdan listesinde bulunamadı.";
            return RedirectToAction(nameof(Musteriler));
        }

        var digerUrunVar = await _context.Parametreler.AnyAsync(x =>
            x.ParAdi == idText &&
            (x.Tur == OperasyonCustomerParamType || x.Tur == VposCustomerParamType));

        if (!digerUrunVar)
        {
            TempData["CuzdanError"] = "Bu müşterinin tek ürünü Cüzdan. Önce PF/VPOS ürünü ekleyin veya 'Tamamen Sil' kullanın.";
            return RedirectToAction(nameof(Musteriler));
        }

        _context.Parametreler.RemoveRange(markers);
        await _context.SaveChangesAsync();

        TempData["CuzdanOk"] = "Müşteri Cüzdan listesinden çıkarıldı. Ana müşteri kaydı korunuyor.";
        return RedirectToAction(nameof(Musteriler));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> MusteriyiTamamenSil(int id)
    {
        if (!GetCuzdanMusteriIds().Contains(id))
        {
            TempData["CuzdanError"] = "Müşteri Cüzdan listesinde bulunamadı.";
            return RedirectToAction(nameof(Musteriler));
        }

        var result = await MusteriSilmeHelper.TamamenSilAsync(_context, id);
        TempData[result.Success ? "CuzdanOk" : "CuzdanError"] = result.Message;
        return RedirectToAction(nameof(Musteriler));
    }


    [HttpGet]
    public async Task<IActionResult> Yeni(string? kayitTipi = null)
    {
        await LoadYeniIsViewDataAsync();
        ViewBag.KayitTipi = string.Equals(kayitTipi, "HATA", StringComparison.OrdinalIgnoreCase)
            ? "HATA"
            : "IS";
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Yeni(
        string kayitTipi,
        int? musteriId,
        string? konu,
        string? aciklama,
        string? kategori)
    {
        kayitTipi = (kayitTipi ?? string.Empty).Trim().ToUpperInvariant();
        konu = (konu ?? string.Empty).Trim();
        aciklama = (aciklama ?? string.Empty).Trim();
        kategori = (kategori ?? string.Empty).Trim();

        if (kayitTipi != "IS" && kayitTipi != "HATA")
            ModelState.AddModelError(nameof(kayitTipi), "Kayıt tipi seçiniz.");

        var cuzdanIds = GetCuzdanMusteriIds();
        Musteri? musteri = null;

        if (!musteriId.HasValue || !cuzdanIds.Contains(musteriId.Value))
        {
            ModelState.AddModelError(nameof(musteriId), "Cüzdan müşterisi seçiniz.");
        }
        else
        {
            musteri = await _context.Musteriler
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.MusteriID == musteriId.Value);

            if (musteri == null)
                ModelState.AddModelError(nameof(musteriId), "Müşteri bulunamadı.");
        }

        if (string.IsNullOrWhiteSpace(konu))
            ModelState.AddModelError(nameof(konu), kayitTipi == "HATA" ? "Hata adı zorunludur." : "İş konusu zorunludur.");

        if (kayitTipi == "HATA" && string.IsNullOrWhiteSpace(kategori))
            ModelState.AddModelError(nameof(kategori), "Hata kategorisi zorunludur.");

        var atama = await GetLeastLoadedOperasyonUserAsync();
        var atanacak = atama.User;
        if (atanacak == null)
            ModelState.AddModelError(string.Empty, "Atama yapılamadı. Operasyon rolünde en az bir kullanıcı olmalıdır.");

        if (!ModelState.IsValid)
        {
            await LoadYeniIsViewDataAsync();
            ViewBag.KayitTipi = kayitTipi;
            ViewBag.SeciliMusteriId = musteriId;
            ViewBag.Konu = konu;
            ViewBag.Aciklama = aciklama;
            ViewBag.Kategori = kategori;
            return View();
        }

        var currentUserId = GetCurrentUserId();
        var currentUserName = GetCurrentUserDisplayName();
        var assignedName = GetDisplayName(atanacak!);
        var now = DateTime.Now;

        if (kayitTipi == "HATA")
        {
            var hata = new Hata
            {
                HataAdi = konu,
                HataAciklama = aciklama,
                KategoriBilgisi = kategori,
                OlusturanUserId = atanacak!.Id,
                OlusturanKullaniciAdi = assignedName,
                OlusturmaTarihi = now,
                Durum = "Açık",
                SecilenHataId = currentUserId > 0 ? -currentUserId : null,
                OperasyonCevabi = string.Empty,
                CevaplayanKullaniciAdi = string.Empty,
                MusteriID = musteriId
            };

            _context.Hatalar.Add(hata);
            await _context.SaveChangesAsync();

            _context.Parametreler.Add(new Parametre
            {
                Tur = CuzdanErrorParamType,
                ParAdi = hata.Id.ToString(CultureInfo.InvariantCulture)
            });
            await _context.SaveChangesAsync();

            TempData["CuzdanOk"] = $"Hata oluşturuldu ve {assignedName} kullanıcısına atandı.";
            return RedirectToAction(nameof(Hatalar));
        }

        var jiraId = currentUserId > 0
            ? $"MOBIL-{currentUserId}-{now:yyyyMMddHHmmssfff}"
            : $"MOBIL-{now:yyyyMMddHHmmssfff}";

        var task = new JiraTask
        {
            MusteriID = musteriId,
            MusteriAdi = musteri?.Firma ?? string.Empty,
            JiraId = jiraId,
            TalepKonusu = CuzdanTaskPrefix + konu,
            TalepTuru = "Entegrasyon",
            TalepAcan = currentUserName,
            Durum = "Aktif",
            TakipEden = assignedName,
            OlusturmaTarihi = now
        };

        _context.JiraTasks.Add(task);
        await _context.SaveChangesAsync();

        if (!string.IsNullOrWhiteSpace(aciklama))
        {
            _context.JiraYorumlar.Add(new JiraYorum
            {
                JiraTaskId = task.Id,
                YorumMetni = "[CUZDAN TALEP] " + aciklama,
                Ekleyen = currentUserName,
                Tarih = now
            });
            await _context.SaveChangesAsync();
        }

        TempData["CuzdanOk"] = $"Cüzdan işi oluşturuldu ve {assignedName} kullanıcısına atandı.";
        return RedirectToAction(nameof(Islerim));
    }

    [HttpGet]
    public async Task<IActionResult> Islerim(string? q, string? durum)
    {
        var currentUserId = GetCurrentUserId();
        var currentUserName = GetCurrentUserDisplayName();
        var ownerPrefix = GetCuzdanTaskOwnerPrefix(currentUserId);

        var query = _context.JiraTasks
            .AsNoTracking()
            .Include(x => x.Yorumlar)
            .Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(CuzdanTaskPrefix))
            .Where(x => x.TalepAcan == currentUserName ||
                        (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix)));

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(x =>
                x.TalepKonusu.Contains(term) ||
                (x.MusteriAdi != null && x.MusteriAdi.Contains(term)) ||
                (x.TakipEden != null && x.TakipEden.Contains(term)));
        }

        if (!string.IsNullOrWhiteSpace(durum))
            query = query.Where(x => x.Durum == durum);

        ViewBag.Q = q;
        ViewBag.Durum = durum;

        return View(await query
            .OrderByDescending(x => x.OlusturmaTarihi)
            .ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> IsDetay(int id)
    {
        if (id <= 0)
            return NotFound();

        var currentUserId = GetCurrentUserId();
        var currentUserName = GetCurrentUserDisplayName();
        var ownerPrefix = GetCuzdanTaskOwnerPrefix(currentUserId);

        var task = await _context.JiraTasks
            .AsNoTracking()
            .Include(x => x.Yorumlar)
            .FirstOrDefaultAsync(x =>
                x.Id == id &&
                x.TalepKonusu != null &&
                x.TalepKonusu.StartsWith(CuzdanTaskPrefix) &&
                (x.TalepAcan == currentUserName ||
                 (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix))));

        if (task == null)
            return NotFound();

        return View(task);
    }

    [HttpGet]
    public async Task<IActionResult> Hatalar(string? q, string? durum, string? kategori)
    {
        var hataIds = GetCuzdanHataIds();

        var query = _context.Hatalar
            .AsNoTracking()
            .Where(x => hataIds.Contains(x.Id));

        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim();
            query = query.Where(x =>
                x.HataAdi.Contains(term) ||
                x.HataAciklama.Contains(term) ||
                x.OlusturanKullaniciAdi.Contains(term));
        }

        if (!string.IsNullOrWhiteSpace(durum))
            query = query.Where(x => x.Durum == durum);

        if (!string.IsNullOrWhiteSpace(kategori))
            query = query.Where(x => x.KategoriBilgisi == kategori);

        var data = await query
            .OrderByDescending(x => x.OlusturmaTarihi)
            .ToListAsync();

        var customerIds = data
            .Where(x => x.MusteriID.HasValue)
            .Select(x => x.MusteriID!.Value)
            .Distinct()
            .ToList();

        ViewBag.Musteriler = await _context.Musteriler
            .AsNoTracking()
            .Where(x => customerIds.Contains(x.MusteriID))
            .ToDictionaryAsync(
                x => x.MusteriID,
                x => x.Firma ?? $"Müşteri #{x.MusteriID}");

        ViewBag.Acanlar = await GetCuzdanHataOpenerMapAsync(data);
        ViewBag.Q = q;
        ViewBag.Durum = durum;
        ViewBag.Kategori = kategori;
        ViewBag.Kategoriler = data
            .Select(x => x.KategoriBilgisi)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct()
            .OrderBy(x => x)
            .ToList();

        return View(data);
    }

    [HttpGet]
    public async Task<IActionResult> HataDetay(int id)
    {
        if (!GetCuzdanHataIds().Contains(id))
            return NotFound();

        var hata = await _context.Hatalar
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.Id == id);

        if (hata == null)
            return NotFound();

        ViewBag.MusteriAdi = hata.MusteriID.HasValue
            ? await _context.Musteriler
                .AsNoTracking()
                .Where(x => x.MusteriID == hata.MusteriID.Value)
                .Select(x => x.Firma)
                .FirstOrDefaultAsync()
            : null;

        var openerMap = await GetCuzdanHataOpenerMapAsync(new[] { hata });
        ViewBag.AcanKullanici = openerMap.TryGetValue(hata.Id, out var name) ? name : "-";

        return View(hata);
    }

    [HttpGet]
    public async Task<IActionResult> IsRaporu()
    {
        var currentUserId = GetCurrentUserId();
        var currentUserName = GetCurrentUserDisplayName();
        var ownerPrefix = GetCuzdanTaskOwnerPrefix(currentUserId);

        var rows = await _context.JiraTasks
            .AsNoTracking()
            .Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(CuzdanTaskPrefix))
            .Where(x => x.TalepAcan == currentUserName ||
                        (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix)))
            .OrderByDescending(x => x.OlusturmaTarihi)
            .ToListAsync();

        var sb = new StringBuilder();
        sb.Append('\uFEFF');
        sb.AppendLine("İş ID;Müşteri;Konu;Talep Açan;Atanan Operasyon;Durum;Tarih");

        foreach (var x in rows)
        {
            sb.AppendLine(string.Join(';', new[]
            {
                CsvEscape(x.JiraId),
                CsvEscape(x.MusteriAdi),
                CsvEscape(CleanTaskSubject(x.TalepKonusu)),
                CsvEscape(x.TalepAcan),
                CsvEscape(x.TakipEden),
                CsvEscape(x.Durum),
                CsvEscape(x.OlusturmaTarihi.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("tr-TR")))
            }));
        }

        return File(
            Encoding.UTF8.GetBytes(sb.ToString()),
            "text/csv; charset=utf-8",
            $"CUZDAN_Entegrasyon_Is_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.csv");
    }

    [HttpGet]
    public async Task<IActionResult> HataRaporu()
    {
        var hataIds = GetCuzdanHataIds();

        var rows = await _context.Hatalar
            .AsNoTracking()
            .Where(x => hataIds.Contains(x.Id))
            .OrderByDescending(x => x.OlusturmaTarihi)
            .ToListAsync();

        var customerIds = rows
            .Where(x => x.MusteriID.HasValue)
            .Select(x => x.MusteriID!.Value)
            .Distinct()
            .ToList();

        var customerMap = await _context.Musteriler
            .AsNoTracking()
            .Where(x => customerIds.Contains(x.MusteriID))
            .ToDictionaryAsync(
                x => x.MusteriID,
                x => x.Firma ?? $"Müşteri #{x.MusteriID}");

        var openedBy = await GetCuzdanHataOpenerMapAsync(rows);

        var sb = new StringBuilder();
        sb.Append('\uFEFF');
        sb.AppendLine("Hata ID;Müşteri;Hata;Açıklama;Kategori;Açan Kullanıcı;Atanan Operasyon;Durum;Tarih");

        foreach (var x in rows)
        {
            var customer = x.MusteriID.HasValue && customerMap.TryGetValue(x.MusteriID.Value, out var c)
                ? c
                : "-";

            var opener = openedBy.TryGetValue(x.Id, out var o) ? o : "-";

            sb.AppendLine(string.Join(';', new[]
            {
                x.Id.ToString(CultureInfo.InvariantCulture),
                CsvEscape(customer),
                CsvEscape(x.HataAdi),
                CsvEscape(x.HataAciklama),
                CsvEscape(x.KategoriBilgisi),
                CsvEscape(opener),
                CsvEscape(x.OlusturanKullaniciAdi),
                CsvEscape(x.Durum),
                CsvEscape(x.OlusturmaTarihi.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("tr-TR")))
            }));
        }

        return File(
            Encoding.UTF8.GetBytes(sb.ToString()),
            "text/csv; charset=utf-8",
            $"CUZDAN_Hata_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.csv");
    }

    private HashSet<int> GetCuzdanHataIds()
    {
        return _context.Parametreler
            .AsNoTracking()
            .Where(x => x.Tur == CuzdanErrorParamType && x.ParAdi != null)
            .Select(x => x.ParAdi!)
            .ToList()
            .Select(x => int.TryParse(x, out var id) ? id : 0)
            .Where(x => x > 0)
            .ToHashSet();
    }

    private async Task LoadYeniIsViewDataAsync()
    {
        var ids = GetCuzdanMusteriIds();

        ViewBag.Musteriler = await _context.Musteriler
            .AsNoTracking()
            .Where(x => ids.Contains(x.MusteriID))
            .OrderBy(x => x.Firma)
            .ToListAsync();
    }

    private async Task<(User? User, int Workload)> GetLeastLoadedOperasyonUserAsync()
    {
        var users = await _context.Users
            .AsNoTracking()
            .Where(x => x.Role == AppRoles.Operasyon)
            .OrderBy(x => x.Id)
            .ToListAsync();

        if (users.Count == 0)
        {
            users = await _context.Users
                .AsNoTracking()
                .Where(x =>
                    x.Role == AppRoles.OperasyonSuperAdmin ||
                    x.Role == "Operasyon Süper Admin" ||
                    x.Role == "Operasyon Super Admin")
                .OrderBy(x => x.Id)
                .ToListAsync();
        }

        if (users.Count == 0)
            return (null, 0);

        var aktifIsAtamalari = await _context.JiraTasks
            .AsNoTracking()
            .Where(x => x.TakipEden != null && x.TakipEden != "")
            .Where(x => x.Durum != "Entegrasyon Tamamlandı" &&
                        x.Durum != "Entegrasyon Tamamlanmadı" &&
                        x.Durum != "Tamamlandı" &&
                        x.Durum != "Arşiv")
            .Select(x => x.TakipEden!)
            .ToListAsync();

        var acikHataAtamalari = await _context.Hatalar
            .AsNoTracking()
            .Where(x => x.OlusturanKullaniciAdi != null && x.OlusturanKullaniciAdi != "")
            .Where(x => x.Durum == null || x.Durum != "Kapalı")
            .Select(x => x.OlusturanKullaniciAdi)
            .ToListAsync();

        var workload = users
            .Select(user =>
            {
                var display = GetDisplayName(user);
                var aliases = new[] { display, user.UserName }
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Select(x => x.Trim())
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();

                var taskCount = aktifIsAtamalari.Count(x =>
                    aliases.Contains((x ?? string.Empty).Trim(), StringComparer.OrdinalIgnoreCase));

                var errorCount = acikHataAtamalari.Count(x =>
                    aliases.Contains((x ?? string.Empty).Trim(), StringComparer.OrdinalIgnoreCase));

                return new { User = user, Count = taskCount + errorCount };
            })
            .OrderBy(x => x.Count)
            .ThenBy(x => x.User.Id)
            .ToList();

        var selected = workload.First();
        return (selected.User, selected.Count);
    }

    private int GetCurrentUserId()
    {
        return int.TryParse(User.FindFirst("UserId")?.Value, out var id) ? id : 0;
    }

    private string GetCurrentUserDisplayName()
    {
        var id = GetCurrentUserId();

        if (id > 0)
        {
            var user = _context.Users
                .AsNoTracking()
                .FirstOrDefault(x => x.Id == id);

            if (user != null)
                return GetDisplayName(user);
        }

        return User.Identity?.Name ?? "Cüzdan Kullanıcısı";
    }

    private static string GetDisplayName(User user)
    {
        return !string.IsNullOrWhiteSpace(user.FullName)
            ? user.FullName!.Trim()
            : user.UserName.Trim();
    }

    private static string? GetCuzdanTaskOwnerPrefix(int userId)
    {
        return userId > 0 ? $"MOBIL-{userId}-" : null;
    }

    private async Task<Dictionary<int, string>> GetCuzdanHataOpenerMapAsync(IEnumerable<Hata> rows)
    {
        var list = rows.ToList();

        var userIds = list
            .Where(x => x.SecilenHataId.HasValue && x.SecilenHataId.Value < 0)
            .Select(x => -x.SecilenHataId!.Value)
            .Where(x => x > 0)
            .Distinct()
            .ToList();

        var users = await _context.Users
            .AsNoTracking()
            .Where(x => userIds.Contains(x.Id))
            .ToDictionaryAsync(
                x => x.Id,
                x => !string.IsNullOrWhiteSpace(x.FullName) ? x.FullName! : x.UserName);

        var result = new Dictionary<int, string>();

        foreach (var hata in list)
        {
            if (hata.SecilenHataId.HasValue && hata.SecilenHataId.Value < 0)
            {
                var openerId = -hata.SecilenHataId.Value;
                result[hata.Id] = users.TryGetValue(openerId, out var name)
                    ? name
                    : $"User #{openerId}";
            }
        }

        return result;
    }

    private static string CleanTaskSubject(string? subject)
    {
        var value = (subject ?? string.Empty).Trim();

        return value.StartsWith(CuzdanTaskPrefix, StringComparison.OrdinalIgnoreCase)
            ? value[CuzdanTaskPrefix.Length..].Trim()
            : value;
    }

    private static string CsvEscape(string? value)
    {
        value ??= string.Empty;
        var quote = value.Contains(';') ||
                    value.Contains('"') ||
                    value.Contains('\n') ||
                    value.Contains('\r');

        value = value.Replace("\"", "\"\"");
        return quote ? $"\"{value}\"" : value;
    }

    private HashSet<int> GetCuzdanMusteriIds() =>
        _context.Parametreler
            .AsNoTracking()
            .Where(x => x.Tur == MobilCustomerParamType && x.ParAdi != null)
            .Select(x => x.ParAdi!)
            .ToList()
            .Select(x => int.TryParse(x, out var id) ? id : 0)
            .Where(x => x > 0)
            .ToHashSet();

    private async Task LoadFormDataAsync()
    {
        ViewBag.Durumlar = await _context.Parametreler
            .AsNoTracking()
            .Where(x => x.Tur == "Durum" && x.ParAdi != null && x.ParAdi != "")
            .Select(x => x.ParAdi!)
            .Distinct()
            .OrderBy(x => x)
            .ToListAsync();

        ViewBag.Teknolojiler = await _context.Parametreler
            .AsNoTracking()
            .Where(x => x.Tur == "Teknoloji" && x.ParAdi != null && x.ParAdi != "")
            .Select(x => x.ParAdi!)
            .Distinct()
            .OrderBy(x => x)
            .ToListAsync();
    }

    private async Task ValidateFormAsync(string? firma, string? durum, string? vkn, string? hariciMusteriId)
    {
        if (string.IsNullOrWhiteSpace(firma))
            ModelState.AddModelError(nameof(firma), "Firma adı zorunludur.");

        if (!string.IsNullOrWhiteSpace(vkn) && vkn.Length > 10)
            ModelState.AddModelError(nameof(vkn), "VKN 10 karakterden uzun olamaz.");

        if (!string.IsNullOrWhiteSpace(hariciMusteriId) && hariciMusteriId.Length > 100)
            ModelState.AddModelError(nameof(hariciMusteriId), "Harici müşteri ID 100 karakterden uzun olamaz.");

        var durumlar = await _context.Parametreler
            .AsNoTracking()
            .Where(x => x.Tur == "Durum" && x.ParAdi != null && x.ParAdi != "")
            .Select(x => x.ParAdi!)
            .Distinct()
            .ToListAsync();

        if (string.IsNullOrWhiteSpace(durum))
        {
            ModelState.AddModelError(nameof(durum), "Durum seçiniz.");
        }
        else if (durumlar.Count > 0 && !durumlar.Contains(durum, StringComparer.OrdinalIgnoreCase))
        {
            ModelState.AddModelError(nameof(durum), "Geçerli bir müşteri durumu seçiniz.");
        }
    }

    private static void NormalizeFormValues(
        ref string? firma,
        ref string? siteUrl,
        ref string? teknoloji,
        ref string? durum,
        ref string? firmaYetkilisi,
        ref string? telefon,
        ref string? aciklama,
        ref string? vkn,
        ref string? hariciMusteriId)
    {
        firma = (firma ?? string.Empty).Trim();
        siteUrl = string.IsNullOrWhiteSpace(siteUrl) ? null : siteUrl.Trim();
        teknoloji = string.IsNullOrWhiteSpace(teknoloji) ? null : teknoloji.Trim();
        durum = (durum ?? string.Empty).Trim();
        firmaYetkilisi = string.IsNullOrWhiteSpace(firmaYetkilisi) ? null : firmaYetkilisi.Trim();
        telefon = string.IsNullOrWhiteSpace(telefon) ? null : telefon.Trim();
        aciklama = string.IsNullOrWhiteSpace(aciklama) ? null : aciklama.Trim();
        vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
        hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();
    }

    private void SetFormViewBags(
        string? firma,
        string? siteUrl,
        string? teknoloji,
        string? durum,
        string? firmaYetkilisi,
        string? telefon,
        string? aciklama,
        string? vkn,
        string? hariciMusteriId)
    {
        ViewBag.Firma = firma;
        ViewBag.SiteUrl = siteUrl;
        ViewBag.Teknoloji = teknoloji;
        ViewBag.Durum = durum;
        ViewBag.FirmaYetkilisi = firmaYetkilisi;
        ViewBag.Telefon = telefon;
        ViewBag.Aciklama = aciklama;
        ViewBag.VKN = vkn;
        ViewBag.HariciMusteriId = hariciMusteriId;
    }

    private void SaveMusteriEkAlanlariNoSave(int musteriId, string? vkn, string? hariciMusteriId)
    {
        var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";

        if (!string.IsNullOrWhiteSpace(vkn))
            _context.Parametreler.Add(new Parametre { Tur = MusteriVknParamType, ParAdi = prefix + vkn.Trim() });

        if (!string.IsNullOrWhiteSpace(hariciMusteriId))
            _context.Parametreler.Add(new Parametre { Tur = MusteriHariciIdParamType, ParAdi = prefix + hariciMusteriId.Trim() });
    }

    private void SetMusteriEkAlanlariNoSave(int musteriId, string? vkn, string? hariciMusteriId)
    {
        var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";
        var existing = _context.Parametreler
            .Where(x =>
                (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                x.ParAdi != null &&
                x.ParAdi.StartsWith(prefix))
            .ToList();

        if (existing.Count > 0)
            _context.Parametreler.RemoveRange(existing);

        SaveMusteriEkAlanlariNoSave(musteriId, vkn, hariciMusteriId);
    }

    private (string? Vkn, string? HariciMusteriId) GetMusteriEkAlanlari(int musteriId)
    {
        var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";
        var rows = _context.Parametreler
            .AsNoTracking()
            .Where(x =>
                (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                x.ParAdi != null &&
                x.ParAdi.StartsWith(prefix))
            .Select(x => new { x.Tur, x.ParAdi })
            .ToList();

        string? vkn = null;
        string? harici = null;

        foreach (var row in rows)
        {
            var value = row.ParAdi![prefix.Length..];
            if (row.Tur == MusteriVknParamType)
                vkn = value;
            else if (row.Tur == MusteriHariciIdParamType)
                harici = value;
        }

        return (vkn, harici);
    }
}
