﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Globalization;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using BtOperasyonTakip.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BtOperasyonTakip.Controllers;

[Authorize(Roles = AppRoles.Operasyon + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin," + AppRoles.Admin)]
public sealed class MusteriController : Controller
{
    private readonly AppDbContext _context;
    private readonly IWebHostEnvironment _env;

    private List<string> GetParametreDegerleri(string tur) =>
        _context.Parametreler
            .AsNoTracking()
            .Where(p => p.Tur == tur && p.ParAdi != null && p.ParAdi != "")
            .OrderBy(p => p.ParAdi)
            .Select(p => p.ParAdi!)
            .ToList();

    private List<string> GetTalepSahibiDegerleri() =>
        _context.Parametreler
            .AsNoTracking()
            .Where(p =>
                (p.Tur == "TalepSahibi" || p.Tur == "TalepEden") &&
                p.ParAdi != null &&
                p.ParAdi != "")
            .Select(p => p.ParAdi!)
            .Concat(
                _context.Musteriler
                    .AsNoTracking()
                    .Where(m => m.TalepSahibi != null && m.TalepSahibi != "")
                    .Select(m => m.TalepSahibi!))
            .Distinct()
            .OrderBy(x => x)
            .ToList();

    private List<string> GetKullaniciSecenekleri()
    {
        return _context.Users
            .AsNoTracking()
            .Select(x => new { x.FullName, x.UserName })
            .ToList()
            .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x!.Trim())
            .Distinct()
            .OrderBy(x => x)
            .ToList();
    }

    private List<string> GetKayitEkleyenSecenekleri()
    {
        var values = new List<string>();
        values.AddRange(GetKullaniciSecenekleri());

        values.AddRange(_context.Musteriler
            .AsNoTracking()
            .Where(x => x.Kekleyen != null && x.Kekleyen != "")
            .Select(x => x.Kekleyen!)
            .ToList());

        
        
        values.AddRange(_context.Detaylar
            .AsNoTracking()
            .Where(x => x.Kekleyen != null && x.Kekleyen != "")
            .Select(x => x.Kekleyen!)
            .ToList());

        return values
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x, StringComparer.CurrentCultureIgnoreCase)
            .ToList();
    }

    private async Task<Dictionary<int, string>> GetLatestDetayKekleyenByMusteriAsync(IEnumerable<int> musteriIds)
    {
        var idList = musteriIds
            .Distinct()
            .ToList();

        if (!idList.Any())
            return new Dictionary<int, string>();

        var latestDetayKekleyen = await _context.Detaylar
            .AsNoTracking()
            .Where(d => idList.Contains(d.MusteriID))
            .Where(d => d.Kekleyen != null && d.Kekleyen != "")
            .OrderByDescending(d => d.Tarih)
            .ThenByDescending(d => d.DetayID)
            .Select(d => new { d.MusteriID, d.Kekleyen })
            .ToListAsync();

        return latestDetayKekleyen
            .GroupBy(x => x.MusteriID)
            .ToDictionary(g => g.Key, g => g.First().Kekleyen!.Trim());
    }

    private static string? ResolveKekleyen(int musteriId, string? mevcutKekleyen, IReadOnlyDictionary<int, string> detayKekleyenleri)
    {
        if (!string.IsNullOrWhiteSpace(mevcutKekleyen))
            return mevcutKekleyen.Trim();

        return detayKekleyenleri.TryGetValue(musteriId, out var detayKekleyen) && !string.IsNullOrWhiteSpace(detayKekleyen)
            ? detayKekleyen.Trim()
            : null;
    }

    private async Task ApplyKekleyenFallbackFromDetayAsync(List<Musteri> musteriler)
    {
        var missingIds = musteriler
            .Where(m => string.IsNullOrWhiteSpace(m.Kekleyen))
            .Select(m => m.MusteriID)
            .Distinct()
            .ToList();

        var latestByMusteri = await GetLatestDetayKekleyenByMusteriAsync(missingIds);

        foreach (var musteri in musteriler)
        {
            var kekleyen = ResolveKekleyen(musteri.MusteriID, musteri.Kekleyen, latestByMusteri);
            if (!string.IsNullOrWhiteSpace(kekleyen))
            {
                musteri.Kekleyen = kekleyen;
            }
        }
    }

    public MusteriController(AppDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    private const string OperasyonCustomerParamType = "UrunMusteri:OPERASYON";
    private const string VposCustomerParamType = "UrunMusteri:VPOS";
    private const string MobilCustomerParamType = "UrunMusteri:MOBIL";
    private const string ProductConfiguredParamType = "UrunMusteri:YAPILANDIRILDI";

    private HashSet<int> GetUrunMusteriIds(string tur) =>
        _context.Parametreler.AsNoTracking()
            .Where(x => x.Tur == tur && x.ParAdi != null)
            .Select(x => x.ParAdi!)
            .ToList()
            .Select(x => int.TryParse(x, out var id) ? id : 0)
            .Where(x => x > 0)
            .ToHashSet();

    private HashSet<int> GetEffectiveUrunMusteriIds(string urun)
    {
        var normalized = (urun ?? string.Empty).Trim().ToUpperInvariant();
        if (normalized == "VPOS") return GetUrunMusteriIds(VposCustomerParamType);
        if (normalized == "MOBIL") return GetUrunMusteriIds(MobilCustomerParamType);

        var configuredIds = GetUrunMusteriIds(ProductConfiguredParamType);
        var explicitOperasyonIds = GetUrunMusteriIds(OperasyonCustomerParamType);
        var result = _context.Musteriler.AsNoTracking().Select(x => x.MusteriID).ToHashSet();

        
        result.RemoveWhere(id => configuredIds.Contains(id) && !explicitOperasyonIds.Contains(id));
        return result;
    }

    private List<string> GetDurumSecenekleri() => GetParametreDegerleri("Durum");

    private IActionResult RedirectToLocalOr(string? returnUrl, string action, object? routeValues = null)
    {
        if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
            return LocalRedirect(returnUrl);

        return RedirectToAction(action, routeValues);
    }

    private static string? NormalizeKekleyen(string? value)
    {
        value = value?.Trim();
        return string.IsNullOrWhiteSpace(value) ? null : value;
    }

    
    
    
    private const string MusteriVknParamType = "MusteriEk:VKN";
    private const string MusteriHariciIdParamType = "MusteriEk:HARICI_ID";
    private const string MusteriVknAutoSyncParamType = "MusteriEk:VKN_SYNC";

    
    
    private sealed class IsyeriVknLookup
    {
        public Dictionary<string, string> ByUyeIsyeriId { get; init; } =
            new(StringComparer.OrdinalIgnoreCase);

        public Dictionary<string, string> ByFirma { get; init; } =
            new(StringComparer.OrdinalIgnoreCase);
    }

    private sealed class IsyeriVknRow
    {
        public string UyeIsyeriId { get; init; } = string.Empty;
        public string UyeIsyeri { get; init; } = string.Empty;
        public string Vkn { get; init; } = string.Empty;
    }

    private static readonly object IsyeriVknCacheLock = new();
    private static IsyeriVknLookup? _isyeriVknCache;
    private static DateTime _isyeriVknCacheLastWriteUtc;

    private string GetIsyeriBilgileriPath() =>
        Path.Combine(_env.ContentRootPath, "App_Data", "IsyeriBilgileri.xlsx");

    private static string NormalizeFirmaAdi(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var normalized = value.Trim().ToUpperInvariant().Normalize(NormalizationForm.FormD);
        var chars = normalized
            .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
            .ToArray();

        normalized = new string(chars)
            .Normalize(NormalizationForm.FormC)
            .Replace("İ", "I")
            .Replace("Ş", "S")
            .Replace("Ğ", "G")
            .Replace("Ü", "U")
            .Replace("Ö", "O")
            .Replace("Ç", "C");

        return Regex.Replace(normalized, @"[^A-Z0-9]", string.Empty);
    }

    private static IReadOnlyList<string> NormalizeFirmaKelimeleri(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return Array.Empty<string>();

        var normalized = value.Trim().ToUpperInvariant().Normalize(NormalizationForm.FormD);
        var chars = normalized
            .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
            .ToArray();

        normalized = new string(chars)
            .Normalize(NormalizationForm.FormC)
            .Replace("İ", "I")
            .Replace("Ş", "S")
            .Replace("Ğ", "G")
            .Replace("Ü", "U")
            .Replace("Ö", "O")
            .Replace("Ç", "C");

        return Regex.Matches(normalized, @"[A-Z0-9]+")
            .Select(x => x.Value)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .ToList();
    }

    private static int LevenshteinDistance(string left, string right, int maxDistance)
    {
        if (string.Equals(left, right, StringComparison.OrdinalIgnoreCase))
            return 0;

        if (string.IsNullOrEmpty(left))
            return right.Length;

        if (string.IsNullOrEmpty(right))
            return left.Length;

        if (Math.Abs(left.Length - right.Length) > maxDistance)
            return maxDistance + 1;

        if (left.Length > right.Length)
            (left, right) = (right, left);

        var previous = new int[left.Length + 1];
        var current = new int[left.Length + 1];

        for (var i = 0; i <= left.Length; i++)
            previous[i] = i;

        for (var j = 1; j <= right.Length; j++)
        {
            current[0] = j;
            var rowMinimum = current[0];

            for (var i = 1; i <= left.Length; i++)
            {
                var cost = char.ToUpperInvariant(left[i - 1]) == char.ToUpperInvariant(right[j - 1]) ? 0 : 1;
                current[i] = Math.Min(
                    Math.Min(current[i - 1] + 1, previous[i] + 1),
                    previous[i - 1] + cost);

                if (current[i] < rowMinimum)
                    rowMinimum = current[i];
            }

            if (rowMinimum > maxDistance)
                return maxDistance + 1;

            (previous, current) = (current, previous);
        }

        return previous[left.Length];
    }

    private static double FirmaBenzerlikPuani(string left, string right, int maxDistance = 2)
    {
        if (string.IsNullOrWhiteSpace(left) || string.IsNullOrWhiteSpace(right))
            return 0d;

        if (string.Equals(left, right, StringComparison.OrdinalIgnoreCase))
            return 1d;

        var maxLength = Math.Max(left.Length, right.Length);
        if (maxLength == 0)
            return 1d;

        var distance = LevenshteinDistance(left, right, maxDistance);
        if (distance > maxDistance)
            return 0d;

        return 1d - ((double)distance / maxLength);
    }

    private static string NormalizeUyeIsyeriId(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var trimmed = value.Trim();
        return long.TryParse(trimmed, NumberStyles.Integer, CultureInfo.InvariantCulture, out var numericId)
            ? numericId.ToString(CultureInfo.InvariantCulture)
            : trimmed;
    }

    private IsyeriVknLookup GetIsyeriVknLookup()
    {
        var path = GetIsyeriBilgileriPath();
        if (!System.IO.File.Exists(path))
            return new IsyeriVknLookup();

        var lastWriteUtc = System.IO.File.GetLastWriteTimeUtc(path);

        lock (IsyeriVknCacheLock)
        {
            if (_isyeriVknCache != null && _isyeriVknCacheLastWriteUtc == lastWriteUtc)
                return _isyeriVknCache;

            var rows = ReadIsyeriVknRows(path);

            
            var byId = rows
                .Where(x => !string.IsNullOrWhiteSpace(x.UyeIsyeriId) && !string.IsNullOrWhiteSpace(x.Vkn))
                .GroupBy(x => NormalizeUyeIsyeriId(x.UyeIsyeriId), StringComparer.OrdinalIgnoreCase)
                .Select(g => new
                {
                    Key = g.Key,
                    Vkns = g.Select(x => x.Vkn.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
                })
                .Where(x => !string.IsNullOrWhiteSpace(x.Key) && x.Vkns.Count == 1)
                .ToDictionary(x => x.Key, x => x.Vkns[0], StringComparer.OrdinalIgnoreCase);

            
            var byFirma = rows
                .Where(x => !string.IsNullOrWhiteSpace(x.UyeIsyeri) && !string.IsNullOrWhiteSpace(x.Vkn))
                .GroupBy(x => NormalizeFirmaAdi(x.UyeIsyeri), StringComparer.OrdinalIgnoreCase)
                .Select(g => new
                {
                    Key = g.Key,
                    Vkns = g.Select(x => x.Vkn.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
                })
                .Where(x => !string.IsNullOrWhiteSpace(x.Key) && x.Vkns.Count == 1)
                .ToDictionary(x => x.Key, x => x.Vkns[0], StringComparer.OrdinalIgnoreCase);

            _isyeriVknCache = new IsyeriVknLookup
            {
                ByUyeIsyeriId = byId,
                ByFirma = byFirma
            };
            _isyeriVknCacheLastWriteUtc = lastWriteUtc;
            return _isyeriVknCache;
        }
    }

    private static int GetExcelColumnIndex(string? cellReference)
    {
        if (string.IsNullOrWhiteSpace(cellReference))
            return 0;

        var letters = new string(cellReference.TakeWhile(char.IsLetter).ToArray()).ToUpperInvariant();
        var result = 0;

        foreach (var c in letters)
            result = (result * 26) + (c - 'A' + 1);

        return result;
    }

    private static string NormalizeExcelHeader(string? value) => NormalizeFirmaAdi(value);

    private static int? FindHeaderColumn(
        IReadOnlyDictionary<int, string> headers,
        params string[] aliases)
    {
        var normalizedAliases = aliases
            .Select(NormalizeExcelHeader)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        foreach (var item in headers)
        {
            if (normalizedAliases.Contains(NormalizeExcelHeader(item.Value)))
                return item.Key;
        }

        return null;
    }

    private static string NormalizeExcelVkn(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        var raw = value.Trim();

        if (Regex.IsMatch(raw, @"^\d{10}$"))
            return raw;

        
        if (decimal.TryParse(
                raw,
                NumberStyles.Float | NumberStyles.AllowThousands,
                CultureInfo.InvariantCulture,
                out var numeric))
        {
            var digits = decimal.Truncate(numeric).ToString("0", CultureInfo.InvariantCulture);
            if (digits.Length < 10)
                digits = digits.PadLeft(10, '0');

            if (Regex.IsMatch(digits, @"^\d{10}$"))
                return digits;
        }

        var onlyDigits = Regex.Replace(raw, @"\D", string.Empty);
        return onlyDigits.Length == 10 ? onlyDigits : string.Empty;
    }

    private static List<IsyeriVknRow> ReadIsyeriVknRows(string path) =>
        ReadIsyeriVknRows(path, includeRowsWithoutVkn: false, out _);

    private static List<IsyeriVknRow> ReadIsyeriVknRows(string path, out string? error) =>
        ReadIsyeriVknRows(path, includeRowsWithoutVkn: false, out error);

    private static List<IsyeriVknRow> ReadIsyeriVknRows(
        string path,
        bool includeRowsWithoutVkn,
        out string? error)
    {
        error = null;
        var result = new List<IsyeriVknRow>();

        try
        {
            using var document = SpreadsheetDocument.Open(path, false);
            var workbookPart = document.WorkbookPart;
            if (workbookPart == null)
            {
                error = "Excel çalışma kitabı okunamadı.";
                return result;
            }

            string CellText(Cell? cell)
            {
                if (cell == null)
                    return string.Empty;

                
                
                
                if (cell.DataType?.Value == CellValues.InlineString)
                    return (cell.InlineString?.InnerText ?? cell.InnerText ?? string.Empty).Trim();

                var raw = cell.CellValue?.Text
                          ?? cell.CellValue?.InnerText
                          ?? cell.InnerText
                          ?? string.Empty;

                if (cell.DataType?.Value == CellValues.SharedString &&
                    int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out var sharedIndex))
                {
                    return workbookPart.SharedStringTablePart?
                               .SharedStringTable?
                               .Elements<SharedStringItem>()
                               .ElementAtOrDefault(sharedIndex)?
                               .InnerText?
                               .Trim()
                           ?? string.Empty;
                }

                
                return raw.Trim();
            }

            var sheets = workbookPart.Workbook.Sheets?.Elements<Sheet>().ToList() ?? new List<Sheet>();
            if (sheets.Count == 0)
            {
                error = "Excel içinde çalışma sayfası bulunamadı.";
                return result;
            }

            string? lastHeaderError = null;
            var detectedHeaderSamples = new List<string>();

            foreach (var sheet in sheets)
            {
                if (sheet.Id?.Value == null ||
                    workbookPart.GetPartById(sheet.Id.Value) is not WorksheetPart worksheetPart)
                {
                    continue;
                }

                var sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();
                if (sheetData == null)
                    continue;

                var allRows = sheetData.Elements<Row>().ToList();
                if (allRows.Count == 0)
                    continue;

                Row? headerRow = null;
                int? uyeIsyeriIdColumn = null;
                int? uyeIsyeriColumn = null;
                int? vknColumn = null;

                
                
                foreach (var row in allRows.Take(100))
                {
                    var headers = row.Elements<Cell>()
                        .Where(x => GetExcelColumnIndex(x.CellReference?.Value) > 0)
                        .GroupBy(x => GetExcelColumnIndex(x.CellReference?.Value))
                        .ToDictionary(g => g.Key, g => CellText(g.First()));

                    uyeIsyeriIdColumn = FindHeaderColumn(
                        headers,
                        "UyeIsyeriId",
                        "Üye İşyeri ID",
                        "Uye Isyeri Id",
                        "ÜyeİşyeriId",
                        "Üye İşyeri No",
                        "Uye Isyeri No",
                        "Excel Üye İşyeri ID",
                        "Excel Uye Isyeri ID",
                        "UIY ID",
                        "UIYID",
                        "Müşteri ID",
                        "Musteri ID",
                        "Harici Müşteri ID",
                        "Harici Musteri ID",
                        "Merchant ID",
                        "MerchantId");

                    uyeIsyeriColumn = FindHeaderColumn(
                        headers,
                        "UyeIsyeri",
                        "Üye İşyeri",
                        "Uye Isyeri",
                        "Üyeİşyeri",
                        "Firma",
                        "Firma Adı",
                        "Firma Adi",
                        "Müşteri",
                        "Musteri",
                        "Müşteri Firma",
                        "Musteri Firma",
                        "Eşleşen Üye İşyeri",
                        "Eslesen Uye Isyeri",
                        "Excel Üye İşyeri",
                        "Excel Uye Isyeri",
                        "İşyeri",
                        "Isyeri",
                        "Merchant",
                        "Merchant Name",
                        "MerchantName");

                    vknColumn = FindHeaderColumn(
                        headers,
                        "VKN",
                        "VKN No",
                        "VKN Numarası",
                        "VKN Numarasi",
                        "Eşleşen VKN",
                        "Eslesen VKN",
                        "Excel VKN",
                        "Önerilen VKN",
                        "Onerilen VKN",
                        "Vergi No",
                        "Vergi Numarası",
                        "Vergi Numarasi",
                        "Vergi Kimlik No",
                        "Vergi Kimlik Numarası",
                        "Vergi Kimlik Numarasi",
                        "Tax Number",
                        "TaxNumber");

                    if (detectedHeaderSamples.Count < 5 && headers.Count > 0)
                    {
                        var sample = string.Join(" | ", headers
                            .OrderBy(x => x.Key)
                            .Select(x => x.Value)
                            .Where(x => !string.IsNullOrWhiteSpace(x))
                            .Take(12));

                        if (!string.IsNullOrWhiteSpace(sample))
                            detectedHeaderSamples.Add($"{sheet.Name?.Value ?? "Sayfa"}: {sample}");
                    }

                    if (vknColumn.HasValue && (uyeIsyeriIdColumn.HasValue || uyeIsyeriColumn.HasValue))
                    {
                        headerRow = row;
                        break;
                    }
                }

                if (headerRow == null || !vknColumn.HasValue)
                {
                    lastHeaderError =
                        $"'{sheet.Name?.Value ?? "Sayfa"}' sayfasında VKN ve firma/üye işyeri başlıkları bulunamadı.";
                    continue;
                }

                var headerRowIndex = headerRow.RowIndex?.Value ?? 1U;

                foreach (var row in allRows.Where(x => (x.RowIndex?.Value ?? 0U) > headerRowIndex))
                {
                    var values = row.Elements<Cell>()
                        .Where(x => GetExcelColumnIndex(x.CellReference?.Value) > 0)
                        .GroupBy(x => GetExcelColumnIndex(x.CellReference?.Value))
                        .ToDictionary(g => g.Key, g => CellText(g.First()));

                    string GetValue(int? column)
                    {
                        if (!column.HasValue)
                            return string.Empty;

                        return values.TryGetValue(column.Value, out var value)
                            ? value.Trim()
                            : string.Empty;
                    }

                    var uyeIsyeriId = NormalizeUyeIsyeriId(GetValue(uyeIsyeriIdColumn));
                    var uyeIsyeri = GetValue(uyeIsyeriColumn);
                    var vkn = NormalizeExcelVkn(GetValue(vknColumn));

                    if (!includeRowsWithoutVkn && string.IsNullOrWhiteSpace(vkn))
                        continue;

                    if (string.IsNullOrWhiteSpace(uyeIsyeriId) && string.IsNullOrWhiteSpace(uyeIsyeri))
                        continue;

                    result.Add(new IsyeriVknRow
                    {
                        UyeIsyeriId = uyeIsyeriId,
                        UyeIsyeri = uyeIsyeri,
                        Vkn = vkn
                    });
                }

                
                if (result.Count > 0)
                    break;
            }

            if (result.Count == 0)
            {
                var detected = detectedHeaderSamples.Count > 0
                    ? " Algılanan ilk başlıklar: " + string.Join(" || ", detectedHeaderSamples)
                    : string.Empty;

                error = (lastHeaderError ??
                        (includeRowsWithoutVkn
                            ? "Excel kolonları bulundu fakat firma/üye işyeri kaydı okunamadı."
                            : "Excel kolonları bulundu fakat geçerli VKN içeren işyeri kaydı okunamadı. " +
                              "VKN değerlerinin 10 haneli olduğundan emin olun.")) + detected;
            }

            return result;
        }
        catch (Exception)
        {
            error = "Excel okunurken hata oluştu.";
            return result;
        }
    }

    private string? FindVknFromExcel(string? firma, string? hariciMusteriId)
    {
        var lookup = GetIsyeriVknLookup();

        var normalizedId = NormalizeUyeIsyeriId(hariciMusteriId);
        if (!string.IsNullOrWhiteSpace(normalizedId) &&
            lookup.ByUyeIsyeriId.TryGetValue(normalizedId, out var idVkn))
        {
            return idVkn;
        }

        var normalizedFirma = NormalizeFirmaAdi(firma);
        if (!string.IsNullOrWhiteSpace(normalizedFirma) &&
            lookup.ByFirma.TryGetValue(normalizedFirma, out var firmaVkn))
        {
            return firmaVkn;
        }

        return null;
    }

    private async Task<int> EnsureExistingCustomersVknMatchedAsync()
    {
        var path = GetIsyeriBilgileriPath();
        if (!System.IO.File.Exists(path))
            return 0;

        
        
        var syncSignature = $"v1|{System.IO.File.GetLastWriteTimeUtc(path).Ticks}";
        var alreadySynced = await _context.Parametreler
            .AsNoTracking()
            .AnyAsync(x => x.Tur == MusteriVknAutoSyncParamType && x.ParAdi == syncSignature);

        if (alreadySynced)
            return 0;

        var customers = await _context.Musteriler
            .AsNoTracking()
            .Select(x => new { x.MusteriID, x.Firma })
            .ToListAsync();

        if (customers.Count == 0)
        {
            await SetVknSyncMarkerAsync(syncSignature);
            return 0;
        }

        var ekAlanlar = GetMusteriEkAlanlari(customers.Select(x => x.MusteriID));
        var added = 0;

        foreach (var customer in customers)
        {
            ekAlanlar.TryGetValue(customer.MusteriID, out var extra);
            if (!string.IsNullOrWhiteSpace(extra.Vkn))
                continue;

            var matchedVkn = FindVknFromExcel(customer.Firma, extra.HariciMusteriId);
            if (string.IsNullOrWhiteSpace(matchedVkn))
                continue;

            _context.Parametreler.Add(new Parametre
            {
                Tur = MusteriVknParamType,
                ParAdi = customer.MusteriID.ToString(CultureInfo.InvariantCulture) + "|" + matchedVkn
            });
            added++;
        }

        await SetVknSyncMarkerAsync(syncSignature, saveFirst: false);
        await _context.SaveChangesAsync();
        return added;
    }

    private async Task SetVknSyncMarkerAsync(string syncSignature, bool saveFirst = true)
    {
        var oldMarkers = await _context.Parametreler
            .Where(x => x.Tur == MusteriVknAutoSyncParamType)
            .ToListAsync();

        if (oldMarkers.Count > 0)
            _context.Parametreler.RemoveRange(oldMarkers);

        _context.Parametreler.Add(new Parametre
        {
            Tur = MusteriVknAutoSyncParamType,
            ParAdi = syncSignature
        });

        if (saveFirst)
            await _context.SaveChangesAsync();
    }


    
    
    

    public sealed class VknEslemeViewModel
    {
        public string? Token { get; set; }
        public string? DosyaAdi { get; set; }
        public string? Hata { get; set; }
        public int ExcelKayitSayisi { get; set; }
        public int ReferansKayitSayisi { get; set; }
        public int MusteriSayisi { get; set; }
        public int KaydedilebilirSayisi { get; set; }
        public int KaydedilenSayisi { get; set; }
        public List<VknEslemeSatiri> Eslesenler { get; set; } = new();
        public List<VknEslemeSatiri> Eslesmeyenler { get; set; } = new();
        public List<VknEslemeSatiri> Belirsizler { get; set; } = new();
    }

    public sealed class VknEslemeSatiri
    {
        public int MusteriID { get; set; }
        public string Firma { get; set; } = string.Empty;
        public string? HariciMusteriID { get; set; }
        public string? MevcutVkn { get; set; }
        public string? ExcelUyeIsyeriId { get; set; }
        public string? ExcelUyeIsyeri { get; set; }
        public string? Vkn { get; set; }
        public string EslesmeTipi { get; set; } = string.Empty;
        public string? Sebep { get; set; }
        public bool VknGuncellenecek { get; set; }
        public bool MusteriIdGuncellenecek { get; set; }
        public bool FirmaGuncellenecek { get; set; }
        public bool Kaydedilebilir { get; set; }
    }

    private static string GetVknEslemeTempDirectory()
    {
        var directory = Path.Combine(Path.GetTempPath(), "BtOperasyonTakip", "VknEsleme");
        Directory.CreateDirectory(directory);
        return directory;
    }

    private static string CreateVknEslemeTokenPath(string token) =>
        Path.Combine(GetVknEslemeTempDirectory(), token + ".xlsx");

    private static bool TryGetVknEslemeTokenPath(string? token, out string path)
    {
        path = string.Empty;
        if (string.IsNullOrWhiteSpace(token) || !Guid.TryParseExact(token, "N", out _))
            return false;

        path = CreateVknEslemeTokenPath(token);
        return System.IO.File.Exists(path);
    }

    private static void CleanupOldVknEslemeFiles()
    {
        try
        {
            var directory = GetVknEslemeTempDirectory();
            foreach (var file in Directory.EnumerateFiles(directory, "*.xlsx"))
            {
                if (System.IO.File.GetLastWriteTimeUtc(file) < DateTime.UtcNow.AddHours(-24))
                    System.IO.File.Delete(file);
            }
        }
        catch
        {
            
        }
    }

    private async Task<VknEslemeViewModel> BuildVknEslemeModelAsync(
        string path,
        string token,
        string? dosyaAdi)
    {
        
        
        
        var uploadedRows = ReadIsyeriVknRows(
            path,
            includeRowsWithoutVkn: true,
            out var excelError);

        
        
        var referansPath = GetIsyeriBilgileriPath();
        var referansRows = System.IO.File.Exists(referansPath)
            ? ReadIsyeriVknRows(referansPath, out _)
            : new List<IsyeriVknRow>();

        var model = new VknEslemeViewModel
        {
            Token = token,
            DosyaAdi = dosyaAdi,
            ExcelKayitSayisi = uploadedRows.Count,
            ReferansKayitSayisi = referansRows.Count,
            Hata = excelError
        };

        var customers = await _context.Musteriler
            .AsNoTracking()
            .OrderBy(x => x.Firma)
            .Select(x => new
            {
                x.MusteriID,
                Firma = x.Firma ?? string.Empty
            })
            .ToListAsync();

        model.MusteriSayisi = customers.Count;

        if (!string.IsNullOrWhiteSpace(excelError) || customers.Count == 0 || uploadedRows.Count == 0)
            return model;

        var extraByCustomer = GetMusteriEkAlanlari(customers.Select(x => x.MusteriID));

        
        
        var uploadedWithVkn = uploadedRows
            .Where(x => !string.IsNullOrWhiteSpace(NormalizeExcelVkn(x.Vkn)))
            .ToList();

        
        
        var searchRows = referansRows
            .Concat(uploadedWithVkn)
            .Where(x => !string.IsNullOrWhiteSpace(NormalizeExcelVkn(x.Vkn)))
            .GroupBy(x => string.Join("|",
                    NormalizeUyeIsyeriId(x.UyeIsyeriId),
                    NormalizeFirmaAdi(x.UyeIsyeri),
                    NormalizeExcelVkn(x.Vkn)),
                StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .ToList();

        static Dictionary<string, List<IsyeriVknRow>> CreateIndex(
            IEnumerable<IsyeriVknRow> rows,
            Func<IsyeriVknRow, string> keySelector)
        {
            return rows
                .Select(x => new { Row = x, Key = keySelector(x) })
                .Where(x => !string.IsNullOrWhiteSpace(x.Key))
                .GroupBy(x => x.Key, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(x => x.Row).ToList(),
                    StringComparer.OrdinalIgnoreCase);
        }

        var uploadedById = CreateIndex(uploadedRows, x => NormalizeUyeIsyeriId(x.UyeIsyeriId));
        var uploadedByVkn = CreateIndex(uploadedWithVkn, x => NormalizeExcelVkn(x.Vkn));
        var uploadedByFirma = CreateIndex(uploadedRows, x => NormalizeFirmaAdi(x.UyeIsyeri));

        var searchById = CreateIndex(searchRows, x => NormalizeUyeIsyeriId(x.UyeIsyeriId));
        var searchByVkn = CreateIndex(searchRows, x => NormalizeExcelVkn(x.Vkn));
        var searchByFirma = CreateIndex(searchRows, x => NormalizeFirmaAdi(x.UyeIsyeri));

        var firmaGroups = searchRows
            .Where(x => !string.IsNullOrWhiteSpace(x.UyeIsyeri))
            .GroupBy(x => NormalizeFirmaAdi(x.UyeIsyeri), StringComparer.OrdinalIgnoreCase)
            .Where(g => !string.IsNullOrWhiteSpace(g.Key))
            .Select(g => new
            {
                Key = g.Key,
                Rows = g.ToList(),
                Tokens = NormalizeFirmaKelimeleri(g.First().UyeIsyeri)
            })
            .ToList();

        static List<IsyeriVknRow> MergeRows(params IEnumerable<IsyeriVknRow>[] sources)
        {
            return sources
                .SelectMany(x => x)
                .GroupBy(x => string.Join("|",
                        NormalizeUyeIsyeriId(x.UyeIsyeriId),
                        NormalizeFirmaAdi(x.UyeIsyeri),
                        NormalizeExcelVkn(x.Vkn)),
                    StringComparer.OrdinalIgnoreCase)
                .Select(g => g.First())
                .ToList();
        }

        static List<string> DistinctVkns(IEnumerable<IsyeriVknRow> rows)
        {
            return rows
                .Select(x => NormalizeExcelVkn(x.Vkn))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        static string? SingleExternalId(IEnumerable<IsyeriVknRow> rows)
        {
            var ids = rows
                .Select(x => NormalizeUyeIsyeriId(x.UyeIsyeriId))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            return ids.Count == 1 ? ids[0] : null;
        }

        static IsyeriVknRow? PickDisplayRow(IEnumerable<IsyeriVknRow> rows, string vkn)
        {
            return rows.FirstOrDefault(x =>
                       string.Equals(
                           NormalizeExcelVkn(x.Vkn),
                           vkn,
                           StringComparison.OrdinalIgnoreCase))
                   ?? rows.FirstOrDefault();
        }

        static bool TokensStartWith(
            IReadOnlyList<string> longer,
            IReadOnlyList<string> shorter)
        {
            if (shorter.Count == 0 || longer.Count < shorter.Count)
                return false;

            for (var i = 0; i < shorter.Count; i++)
            {
                if (!string.Equals(longer[i], shorter[i], StringComparison.OrdinalIgnoreCase))
                    return false;
            }

            return true;
        }

        foreach (var customer in customers)
        {
            extraByCustomer.TryGetValue(customer.MusteriID, out var extra);

            var satir = new VknEslemeSatiri
            {
                MusteriID = customer.MusteriID,
                Firma = customer.Firma,
                HariciMusteriID = extra.HariciMusteriId,
                MevcutVkn = extra.Vkn
            };

            var normalizedFirma = NormalizeFirmaAdi(customer.Firma);
            var customerTokens = NormalizeFirmaKelimeleri(customer.Firma);
            var currentVkn = NormalizeExcelVkn(extra.Vkn);
            var currentExternalId = NormalizeUyeIsyeriId(extra.HariciMusteriId);

            
            
            
            
            if (!string.IsNullOrWhiteSpace(currentVkn))
            {
                var currentRows = new List<IsyeriVknRow>();

                if (uploadedByVkn.TryGetValue(currentVkn, out var uploadedVknRows))
                    currentRows.AddRange(uploadedVknRows);

                if (searchByVkn.TryGetValue(currentVkn, out var referenceVknRows))
                    currentRows.AddRange(referenceVknRows);

                currentRows = MergeRows(currentRows);

                satir.Vkn = currentVkn;
                satir.EslesmeTipi = "Mevcut VKN";

                if (currentRows.Count > 0)
                {
                    var displayRow = PickDisplayRow(currentRows, currentVkn);
                    satir.ExcelUyeIsyeri = displayRow?.UyeIsyeri;

                    var singleId = SingleExternalId(currentRows);
                    satir.ExcelUyeIsyeriId = singleId;
                    satir.MusteriIdGuncellenecek =
                        string.IsNullOrWhiteSpace(currentExternalId) &&
                        !string.IsNullOrWhiteSpace(singleId);
                }

                satir.VknGuncellenecek = false;
                satir.FirmaGuncellenecek = false;
                satir.Kaydedilebilir = satir.MusteriIdGuncellenecek;
                satir.Sebep = satir.MusteriIdGuncellenecek
                    ? "Mevcut VKN korundu; güvenli bulunan Müşteri ID kaydedilecek."
                    : "Mevcut VKN doğru kabul edilerek korundu.";

                model.Eslesenler.Add(satir);
                continue;
            }

            List<IsyeriVknRow>? candidates = null;
            var eslesmeTipi = string.Empty;

            
            
            
            if (!string.IsNullOrWhiteSpace(currentExternalId))
            {
                var idRows = new List<IsyeriVknRow>();

                if (uploadedById.TryGetValue(currentExternalId, out var uploadedIdRows))
                    idRows.AddRange(uploadedIdRows);

                if (searchById.TryGetValue(currentExternalId, out var referenceIdRows))
                    idRows.AddRange(referenceIdRows);

                idRows = MergeRows(idRows);

                if (DistinctVkns(idRows).Count > 0)
                {
                    candidates = idRows;
                    eslesmeTipi = "Müşteri ID";
                }
            }

            
            
            
            
            
            if (candidates == null &&
                !string.IsNullOrWhiteSpace(normalizedFirma) &&
                uploadedByFirma.TryGetValue(normalizedFirma, out var uploadedNameRows))
            {
                var rowsWithVkn = uploadedNameRows
                    .Where(x => !string.IsNullOrWhiteSpace(NormalizeExcelVkn(x.Vkn)))
                    .ToList();

                if (rowsWithVkn.Count > 0)
                {
                    candidates = rowsWithVkn;
                    eslesmeTipi = "Yüklenen Excel";
                }
            }

            
            
            
            if (candidates == null &&
                !string.IsNullOrWhiteSpace(normalizedFirma) &&
                searchByFirma.TryGetValue(normalizedFirma, out var exactNameRows))
            {
                candidates = exactNameRows;
                eslesmeTipi = "Firma Adı";
            }

            
            
            
            
            
            
            if (candidates == null && normalizedFirma.Length >= 3)
            {
                var prefixGroups = firmaGroups
                    .Select(g =>
                    {
                        var candidateKey = g.Key;
                        var isPrefix =
                            candidateKey.StartsWith(normalizedFirma, StringComparison.OrdinalIgnoreCase) ||
                            normalizedFirma.StartsWith(candidateKey, StringComparison.OrdinalIgnoreCase);

                        if (!isPrefix)
                            return new { Group = g, Accepted = false, TokenPrefix = false, Score = 0d };

                        var shorterLength = Math.Min(normalizedFirma.Length, candidateKey.Length);
                        var longerLength = Math.Max(normalizedFirma.Length, candidateKey.Length);
                        var compactRatio = longerLength == 0
                            ? 0d
                            : (double)shorterLength / longerLength;

                        var tokenPrefix = customerTokens.Count <= g.Tokens.Count
                            ? TokensStartWith(g.Tokens, customerTokens)
                            : TokensStartWith(customerTokens, g.Tokens);

                        
                        
                        var accepted = compactRatio >= 0.55d || tokenPrefix;
                        return new
                        {
                            Group = g,
                            Accepted = accepted,
                            TokenPrefix = tokenPrefix,
                            Score = compactRatio + (tokenPrefix ? 0.25d : 0d)
                        };
                    })
                    .Where(x => x.Accepted)
                    .OrderByDescending(x => x.Score)
                    .ToList();

                if (prefixGroups.Count > 0)
                {
                    var allPrefixRows = prefixGroups
                        .SelectMany(x => x.Group.Rows)
                        .ToList();

                    var allPrefixVkns = DistinctVkns(allPrefixRows);

                    
                    if (allPrefixVkns.Count == 1)
                    {
                        candidates = allPrefixRows;
                        eslesmeTipi = "Yakın Firma Adı";
                    }
                    else
                    {
                        
                        var best = prefixGroups[0];
                        var secondScore = prefixGroups.Count > 1 ? prefixGroups[1].Score : 0d;
                        var bestVkns = DistinctVkns(best.Group.Rows);

                        if (bestVkns.Count == 1 &&
                            best.TokenPrefix &&
                            customerTokens.Count >= 2 &&
                            (prefixGroups.Count == 1 || best.Score - secondScore >= 0.20d))
                        {
                            candidates = best.Group.Rows;
                            eslesmeTipi = "Yakın Firma Adı";
                        }
                    }
                }
            }

            
            
            
            
            
            if (candidates == null && normalizedFirma.Length >= 5)
            {
                var scored = firmaGroups
                    .Where(g => Math.Abs(g.Key.Length - normalizedFirma.Length) <= 2)
                    .Select(g =>
                    {
                        var maxLength = Math.Max(g.Key.Length, normalizedFirma.Length);
                        var allowedDistance = maxLength >= 12 ? 2 : 1;
                        var distance = LevenshteinDistance(normalizedFirma, g.Key, allowedDistance);
                        var score = distance <= allowedDistance && maxLength > 0
                            ? 1d - ((double)distance / maxLength)
                            : 0d;

                        
                        
                        var accepted = distance == 1 ||
                                       (distance == 2 && maxLength >= 12 && score >= 0.90d);

                        return new { Group = g, Distance = distance, Score = score, Accepted = accepted };
                    })
                    .Where(x => x.Accepted)
                    .OrderBy(x => x.Distance)
                    .ThenByDescending(x => x.Score)
                    .ToList();

                if (scored.Count > 0)
                {
                    var bestDistance = scored[0].Distance;
                    var bestScore = scored[0].Score;
                    var bestGroups = scored
                        .Where(x => x.Distance == bestDistance && Math.Abs(x.Score - bestScore) < 0.000001d)
                        .ToList();

                    var bestRows = bestGroups
                        .SelectMany(x => x.Group.Rows)
                        .ToList();

                    if (DistinctVkns(bestRows).Count == 1)
                    {
                        candidates = bestRows;
                        eslesmeTipi = "Tek Harf / Güçlü Benzerlik";
                    }
                }
            }

            if (candidates == null || candidates.Count == 0)
            {
                satir.Sebep = referansRows.Count > 0
                    ? "Yüklenen Excel ve 22K referans işyeri dosyasında güvenli VKN karşılığı bulunamadı."
                    : "Yüklenen Excel'de güvenli VKN karşılığı bulunamadı; App_Data/IsyeriBilgileri.xlsx referans dosyası da bulunamadı.";

                model.Eslesmeyenler.Add(satir);
                continue;
            }

            var distinctVkns = DistinctVkns(candidates);

            if (distinctVkns.Count != 1)
            {
                satir.EslesmeTipi = eslesmeTipi;
                satir.ExcelUyeIsyeriId = candidates.FirstOrDefault()?.UyeIsyeriId;
                satir.ExcelUyeIsyeri = candidates.FirstOrDefault()?.UyeIsyeri;
                satir.Sebep = distinctVkns.Count == 0
                    ? $"A {eslesmeTipi} match was found, but the Tax ID is empty."
                    : $"{distinctVkns.Count} different Tax IDs were found for the {eslesmeTipi} match: " +
                      string.Join(", ", distinctVkns.Take(5));

                model.Belirsizler.Add(satir);
                continue;
            }

            var matchedVkn = distinctVkns[0];
            var matchedRow = PickDisplayRow(candidates, matchedVkn) ?? candidates[0];
            var excelMusteriId = SingleExternalId(candidates);

            satir.EslesmeTipi = eslesmeTipi;
            satir.ExcelUyeIsyeriId = excelMusteriId;
            satir.ExcelUyeIsyeri = matchedRow.UyeIsyeri;
            satir.Vkn = matchedVkn;

            
            
            if (!string.IsNullOrWhiteSpace(currentExternalId) &&
                !string.IsNullOrWhiteSpace(excelMusteriId) &&
                !string.Equals(currentExternalId, excelMusteriId, StringComparison.OrdinalIgnoreCase))
            {
                satir.ExcelUyeIsyeriId = null;
                satir.MusteriIdGuncellenecek = false;
            }

            satir.VknGuncellenecek = !string.IsNullOrWhiteSpace(matchedVkn);
            satir.MusteriIdGuncellenecek =
                string.IsNullOrWhiteSpace(currentExternalId) &&
                !string.IsNullOrWhiteSpace(satir.ExcelUyeIsyeriId);

            
            
            satir.FirmaGuncellenecek = false;
            satir.Kaydedilebilir = satir.VknGuncellenecek || satir.MusteriIdGuncellenecek;

            var changes = new List<string>();
            if (satir.VknGuncellenecek) changes.Add("VKN");
            if (satir.MusteriIdGuncellenecek) changes.Add("Müşteri ID");

            satir.Sebep = changes.Count > 0
                ? string.Join(", ", changes) + " güncellenecek. Firma adı korunacak."
                : "Bilgiler zaten kayıtlı.";

            model.Eslesenler.Add(satir);
        }

        model.KaydedilebilirSayisi = model.Eslesenler.Count(x => x.Kaydedilebilir);
        return model;
    }

    [HttpGet("/Musteri/VknEsleme")]
    public IActionResult VknEsleme()
    {
        return View(new VknEslemeViewModel());
    }

    [HttpPost("/Musteri/VknEsleme")]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(20 * 1024 * 1024)]
    public async Task<IActionResult> VknEslemeAnaliz(IFormFile? excelDosyasi)
    {
        if (excelDosyasi == null || excelDosyasi.Length == 0)
        {
            return View("VknEsleme", new VknEslemeViewModel
            {
                Hata = "Lütfen .xlsx formatında bir Excel dosyası seçin."
            });
        }

        if (!string.Equals(Path.GetExtension(excelDosyasi.FileName), ".xlsx", StringComparison.OrdinalIgnoreCase))
        {
            return View("VknEsleme", new VknEslemeViewModel
            {
                Hata = "Yalnızca .xlsx dosyaları destekleniyor."
            });
        }

        CleanupOldVknEslemeFiles();

        var token = Guid.NewGuid().ToString("N");
        var path = CreateVknEslemeTokenPath(token);

        try
        {
            await using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                await excelDosyasi.CopyToAsync(stream);
            }

            var model = await BuildVknEslemeModelAsync(
                path,
                token,
                Path.GetFileName(excelDosyasi.FileName));

            return View("VknEsleme", model);
        }
        catch (Exception)
        {
            try
            {
                if (System.IO.File.Exists(path))
                    System.IO.File.Delete(path);
            }
            catch
            {
                
            }

            return View("VknEsleme", new VknEslemeViewModel
            {
                Hata = "Excel okunamadı. Dosya biçimini ve içeriğini kontrol edin."
            });
        }
    }

    [HttpPost("/Musteri/VknEsleme/Kaydet")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> VknEslemeKaydet(string? token)
    {
        if (!TryGetVknEslemeTokenPath(token, out var path))
        {
            TempData["MusteriError"] =
                "Eşleştirme dosyası bulunamadı veya süresi doldu. Excel'i tekrar yükleyin.";
            return RedirectToAction(nameof(VknEsleme));
        }

        var model = await BuildVknEslemeModelAsync(path, token!, Path.GetFileName(path));
        var kaydedilecekler = model.Eslesenler.Where(x => x.Kaydedilebilir).ToList();

        if (kaydedilecekler.Count == 0)
        {
            model.Hata = "Kaydedilecek yeni ve güvenli eşleşme bulunamadı.";
            return View("VknEsleme", model);
        }

        var ids = kaydedilecekler.Select(x => x.MusteriID).ToHashSet();

        var musteriler = await _context.Musteriler
            .Where(x => ids.Contains(x.MusteriID))
            .ToDictionaryAsync(x => x.MusteriID);

        var mevcutEkAlanlar = GetMusteriEkAlanlari(ids);

        var mevcutParametreler = await _context.Parametreler
            .Where(x =>
                (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                x.ParAdi != null)
            .ToListAsync();

        var silinecekParametreler = mevcutParametreler
            .Where(x =>
                TryParseMusteriEkParam(x.ParAdi, out var id, out _) && ids.Contains(id))
            .ToList();

        if (silinecekParametreler.Count > 0)
            _context.Parametreler.RemoveRange(silinecekParametreler);

        var kaydedilen = 0;

        foreach (var satir in kaydedilecekler)
        {
            mevcutEkAlanlar.TryGetValue(satir.MusteriID, out var current);

            var finalVkn = satir.VknGuncellenecek ? satir.Vkn?.Trim() : current.Vkn;
            var finalHariciId = satir.MusteriIdGuncellenecek
                ? satir.ExcelUyeIsyeriId?.Trim()
                : current.HariciMusteriId;

            var prefix = satir.MusteriID.ToString(CultureInfo.InvariantCulture) + "|";

            if (!string.IsNullOrWhiteSpace(finalVkn))
            {
                _context.Parametreler.Add(new Parametre
                {
                    Tur = MusteriVknParamType,
                    ParAdi = prefix + finalVkn
                });
            }

            if (!string.IsNullOrWhiteSpace(finalHariciId))
            {
                _context.Parametreler.Add(new Parametre
                {
                    Tur = MusteriHariciIdParamType,
                    ParAdi = prefix + finalHariciId
                });
            }

            if (satir.FirmaGuncellenecek &&
                !string.IsNullOrWhiteSpace(satir.ExcelUyeIsyeri) &&
                musteriler.TryGetValue(satir.MusteriID, out var musteri))
            {
                musteri.Firma = satir.ExcelUyeIsyeri.Trim();
            }

            kaydedilen++;
        }

        await _context.SaveChangesAsync();

        model = await BuildVknEslemeModelAsync(path, token!, model.DosyaAdi);
        model.KaydedilenSayisi = kaydedilen;
        return View("VknEsleme", model);
    }

    [HttpGet("/Musteri/VknEsleme/Excel")]
    public async Task<IActionResult> VknEslemeExcel(string? token, string tip = "eslesen")
    {
        if (!TryGetVknEslemeTokenPath(token, out var path))
            return NotFound("Eşleştirme dosyası bulunamadı veya süresi doldu.");

        var model = await BuildVknEslemeModelAsync(path, token!, Path.GetFileName(path));
        var normalizedTip = (tip ?? string.Empty).Trim().ToLowerInvariant();

        var rows = normalizedTip switch
        {
            "eslesmeyen" => model.Eslesmeyenler,
            "belirsiz" => model.Belirsizler,
            _ => model.Eslesenler
        };

        var title = normalizedTip switch
        {
            "eslesmeyen" => "Eslesmeyenler",
            "belirsiz" => "Belirsizler",
            _ => "Eslesenler"
        };

        var bytes = CreateVknEslemeExcel(rows, title);
        return File(
            bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"VKN_{title}_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
    }

    private static byte[] CreateVknEslemeExcel(IEnumerable<VknEslemeSatiri> rows, string sheetName)
    {
        using var ms = new MemoryStream();

        using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
        {
            var workbookPart = document.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();

            var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = CreateMusteriStylesheet();
            stylesPart.Stylesheet.Save();

            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var sheetData = new SheetData();
            var worksheet = new Worksheet(
                new Columns(
                    CreateColumn(1, 1, 12),
                    CreateColumn(2, 2, 32),
                    CreateColumn(3, 3, 32),
                    CreateColumn(4, 4, 20),
                    CreateColumn(5, 5, 20),
                    CreateColumn(6, 6, 18),
                    CreateColumn(7, 7, 18),
                    CreateColumn(8, 8, 20),
                    CreateColumn(9, 9, 34),
                    CreateColumn(10, 10, 50)),
                sheetData);

            uint rowIndex = 1;
            var header = new Row { RowIndex = rowIndex };
            header.Append(
                CreateTextCell("A", rowIndex, "Sistem ID", 1),
                CreateTextCell("B", rowIndex, "Mevcut Firma", 1),
                CreateTextCell("C", rowIndex, "Kaynak Firma", 1),
                CreateTextCell("D", rowIndex, "Mevcut Müşteri ID", 1),
                CreateTextCell("E", rowIndex, "Bulunan Müşteri ID", 1),
                CreateTextCell("F", rowIndex, "Mevcut VKN", 1),
                CreateTextCell("G", rowIndex, "Bulunan VKN", 1),
                CreateTextCell("H", rowIndex, "Eşleşme Tipi", 1),
                CreateTextCell("I", rowIndex, "Yapılacak İşlem", 1),
                CreateTextCell("J", rowIndex, "Durum / Sebep", 1));
            sheetData.Append(header);

            foreach (var item in rows)
            {
                rowIndex++;

                var changes = new List<string>();
                if (item.VknGuncellenecek) changes.Add("VKN");
                if (item.MusteriIdGuncellenecek) changes.Add("Müşteri ID");
                if (item.FirmaGuncellenecek) changes.Add("Firma");

                var row = new Row { RowIndex = rowIndex };
                row.Append(
                    CreateNumberCell("A", rowIndex, item.MusteriID.ToString(CultureInfo.InvariantCulture), 0),
                    CreateTextCell("B", rowIndex, item.Firma, 0),
                    CreateTextCell("C", rowIndex, item.ExcelUyeIsyeri, 0),
                    CreateTextCell("D", rowIndex, item.HariciMusteriID, 0),
                    CreateTextCell("E", rowIndex, item.ExcelUyeIsyeriId, 0),
                    CreateTextCell("F", rowIndex, item.MevcutVkn, 0),
                    CreateTextCell("G", rowIndex, item.Vkn, 0),
                    CreateTextCell("H", rowIndex, item.EslesmeTipi, 0),
                    CreateTextCell("I", rowIndex, changes.Count == 0 ? "-" : string.Join(", ", changes), 0),
                    CreateTextCell("J", rowIndex, item.Sebep, 0));
                sheetData.Append(row);
            }

            var lastRow = Math.Max(1U, rowIndex);
            worksheet.Append(new AutoFilter { Reference = $"A1:J{lastRow}" });
            worksheetPart.Worksheet = worksheet;
            worksheetPart.Worksheet.Save();

            var sheets = workbookPart.Workbook.AppendChild(new Sheets());
            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = sheetName.Length > 31 ? sheetName[..31] : sheetName
            });

            workbookPart.Workbook.Save();
        }

        return ms.ToArray();
    }

    private static bool TryParseMusteriEkParam(string? value, out int musteriId, out string? deger)
    {
        musteriId = 0;
        deger = null;
        if (string.IsNullOrWhiteSpace(value)) return false;

        var separatorIndex = value.IndexOf('|');
        if (separatorIndex <= 0) return false;

        if (!int.TryParse(value[..separatorIndex], NumberStyles.Integer, CultureInfo.InvariantCulture, out musteriId) || musteriId <= 0)
            return false;

        deger = value[(separatorIndex + 1)..].Trim();
        if (string.IsNullOrWhiteSpace(deger)) deger = null;
        return true;
    }

    private Dictionary<int, (string? Vkn, string? HariciMusteriId)> GetMusteriEkAlanlari(IEnumerable<int> musteriIds)
    {
        var ids = musteriIds.Distinct().Where(x => x > 0).ToHashSet();
        var result = ids.ToDictionary(x => x, _ => (Vkn: (string?)null, HariciMusteriId: (string?)null));
        if (ids.Count == 0) return result;

        var rows = _context.Parametreler
            .AsNoTracking()
            .Where(x => (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) && x.ParAdi != null)
            .Select(x => new { x.Tur, x.ParAdi })
            .ToList();

        foreach (var row in rows)
        {
            if (!TryParseMusteriEkParam(row.ParAdi, out var id, out var value) || !ids.Contains(id))
                continue;

            var current = result[id];
            if (row.Tur == MusteriVknParamType)
                result[id] = (value, current.HariciMusteriId);
            else if (row.Tur == MusteriHariciIdParamType)
                result[id] = (current.Vkn, value);
        }

        return result;
    }

    private HashSet<int> GetMusteriIdsByEkAlanSearch(string term)
    {
        var result = new HashSet<int>();
        if (string.IsNullOrWhiteSpace(term)) return result;

        var search = term.Trim();
        var rows = _context.Parametreler
            .AsNoTracking()
            .Where(x => (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                        x.ParAdi != null && x.ParAdi.Contains(search))
            .Select(x => x.ParAdi!)
            .ToList();

        foreach (var row in rows)
        {
            if (TryParseMusteriEkParam(row, out var id, out _) && id > 0)
                result.Add(id);
        }

        return result;
    }

    private void SaveMusteriEkAlanlari(int musteriId, string? vkn, string? hariciMusteriId)
    {
        vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
        hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();

        var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";
        var existing = _context.Parametreler
            .Where(x => (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                        x.ParAdi != null && x.ParAdi.StartsWith(prefix))
            .ToList();

        if (existing.Count > 0)
            _context.Parametreler.RemoveRange(existing);

        if (vkn != null)
            _context.Parametreler.Add(new Parametre { Tur = MusteriVknParamType, ParAdi = prefix + vkn });

        if (hariciMusteriId != null)
            _context.Parametreler.Add(new Parametre { Tur = MusteriHariciIdParamType, ParAdi = prefix + hariciMusteriId });

        _context.SaveChanges();
    }

    private static string? ValidateMusteriEkAlanlari(string? vkn, string? hariciMusteriId)
    {
        if (!string.IsNullOrWhiteSpace(vkn) && vkn.Trim().Length > 10)
            return "VKN 10 karakterden uzun olamaz.";

        if (!string.IsNullOrWhiteSpace(hariciMusteriId) && hariciMusteriId.Trim().Length > 100)
            return "Müşteri ID 100 karakterden uzun olamaz.";

        return null;
    }

    private static bool IsEnglishExport(string? lang) =>
        string.IsNullOrWhiteSpace(lang) || lang.StartsWith("en", StringComparison.OrdinalIgnoreCase);

    private static string L(bool isEn, string tr, string en) => isEn ? en : tr;

    private static string TranslateExportValue(string? value, bool isEn)
    {
        if (!isEn || string.IsNullOrWhiteSpace(value))
            return value ?? string.Empty;

        return value.Trim() switch
        {
            "Beklemede" => "Pending",
            "Aktif" => "Active",
            "Pasif" => "Inactive",
            "Tamamlandı" => "Completed",
            "Döküman İletildi" => "Document Sent",
            "Dokuman İletildi" => "Document Sent",
            "Dokuman Gönderildi" => "Document Sent",
            "Satışa Bilgi Verildi" => "Sales Informed",
            "Satışa Gönderildi" => "Sent to Sales",
            "Entegrasyon Tamamlandı" => "Integration Completed",
            "Canlıda Entegrasyon Tamamlandı" => "Live Integration Completed",
            "Entegrasyon Tamamlanmadı" => "Integration Not Completed",
            "Geliştirme" => "Development",
            "Eğitim" => "Training",
            "Entegrasyon" => "Integration",
            "Hata Çözüm" => "Issue Resolution",
            "Sistem" => "System",
            _ => value
        };
    }

    [HttpPost("/Musteri/SetUrun")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SetUrun([FromForm] int musteriId, [FromForm] string urun, [FromForm] bool aktif, [FromForm] string? returnUrl)
    {
        var musteriVar = await _context.Musteriler.AsNoTracking().AnyAsync(x => x.MusteriID == musteriId);
        if (!musteriVar)
        {
            TempData["MusteriError"] = "Müşteri bulunamadı.";
            return RedirectToLocalOr(returnUrl, nameof(Index));
        }

        var normalizedUrun = (urun ?? string.Empty).Trim().ToUpperInvariant();
        var tur = normalizedUrun switch
        {
            "OPERASYON" => OperasyonCustomerParamType,
            "VPOS" => VposCustomerParamType,
            "MOBIL" => MobilCustomerParamType,
            _ => null
        };

        if (tur == null)
        {
            TempData["MusteriError"] = "Geçersiz ürün seçimi.";
            return RedirectToLocalOr(returnUrl, nameof(Index));
        }

        var idText = musteriId.ToString(CultureInfo.InvariantCulture);
        var configured = await _context.Parametreler.FirstOrDefaultAsync(x => x.Tur == ProductConfiguredParamType && x.ParAdi == idText);
        if (configured == null)
        {
            
            _context.Parametreler.Add(new Parametre { Tur = ProductConfiguredParamType, ParAdi = idText });
            var operasyonMevcut = await _context.Parametreler.AnyAsync(x => x.Tur == OperasyonCustomerParamType && x.ParAdi == idText);
            if (!operasyonMevcut)
                _context.Parametreler.Add(new Parametre { Tur = OperasyonCustomerParamType, ParAdi = idText });

            
            await _context.SaveChangesAsync();
        }

        var mevcut = await _context.Parametreler.FirstOrDefaultAsync(x => x.Tur == tur && x.ParAdi == idText);
        if (aktif && mevcut == null)
        {
            _context.Parametreler.Add(new Parametre { Tur = tur, ParAdi = idText });
        }
        else if (!aktif && mevcut != null)
        {
            var digerUrunSayisi = await _context.Parametreler.CountAsync(x =>
                x.ParAdi == idText &&
                (x.Tur == OperasyonCustomerParamType || x.Tur == VposCustomerParamType || x.Tur == MobilCustomerParamType) &&
                x.Tur != tur);

            if (digerUrunSayisi == 0)
            {
                TempData["MusteriError"] = "Müşteride en az bir ürün tipi seçili kalmalıdır.";
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            _context.Parametreler.Remove(mevcut);
        }

        await _context.SaveChangesAsync();
        var urunAdi = normalizedUrun == "MOBIL" ? "Cüzdan" : normalizedUrun == "OPERASYON" ? "PF" : "VPOS";
        TempData["MusteriOk"] = aktif ? $"{urunAdi} was added to the customer." : $"{urunAdi} was removed from the customer.";
        return RedirectToLocalOr(returnUrl, nameof(Index));
    }

    [HttpPost("/Musteri/SetDokumanDurumu")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SetDokumanDurumu([FromForm] int musteriId, [FromForm] bool gonderildi, [FromForm] string? returnUrl)
    {
        var musteri = await _context.Musteriler.FirstOrDefaultAsync(x => x.MusteriID == musteriId);
        if (musteri == null)
        {
            TempData["MusteriError"] = "Customer was not found.";
            return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? LocalRedirect(returnUrl)
                : RedirectToAction(nameof(Index));
        }

        if (!string.Equals((musteri.Durum ?? string.Empty).Trim(), "Döküman Gönderildi", StringComparison.OrdinalIgnoreCase))
        {
            TempData["MusteriError"] = "Document status cannot be updated for this customer.";
            return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? LocalRedirect(returnUrl)
                : RedirectToAction(nameof(Index));
        }

        musteri.DokumanGonderildiMi = gonderildi;

        if (gonderildi)
        {
            musteri.DokumanGonderimSayisi = (musteri.DokumanGonderimSayisi ?? 0) + 1;
            musteri.DurumDegisiklikTarihi = DateTime.Now;
            musteri.DokumanKontrolBaslangicTarihi = musteri.DurumDegisiklikTarihi;
        }
        else
        {
            musteri.DokumanKontrolBaslangicTarihi ??= musteri.DurumDegisiklikTarihi ?? musteri.KayitTarihi;
        }

        await _context.SaveChangesAsync();

        TempData["MusteriOk"] = "Document status updated.";
        return !string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Index(
        int page = 1,
        int pageSize = 25,
        string? search = null,
        string? durum = null,
        string? teknoloji = null,
        string? talepSahibi = null,
        string? kayitEkleyen = null,
        string? urun = null)
    {
        if (page < 1) page = 1;
        if (pageSize < 1) pageSize = 25;
        if (pageSize > 100) pageSize = 100;

        IQueryable<Musteri> query = _context.Musteriler.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            var ekAlanEslesenIds = GetMusteriIdsByEkAlanSearch(term);
            query = query.Where(x =>
                (x.Firma != null && x.Firma.Contains(term)) ||
                ekAlanEslesenIds.Contains(x.MusteriID));
        }

        if (!string.IsNullOrWhiteSpace(durum))
        {
            var d = durum.Trim();
            query = query.Where(x => x.Durum == d);
        }

        if (!string.IsNullOrWhiteSpace(teknoloji))
        {
            var t = teknoloji.Trim();
            query = query.Where(x => x.Teknoloji == t);
        }

        if (!string.IsNullOrWhiteSpace(talepSahibi))
        {
            var ts = talepSahibi.Trim();
            query = query.Where(x => x.TalepSahibi == ts);
        }

        var selectedKayitEkleyen = NormalizeKekleyen(kayitEkleyen);
        if (!string.IsNullOrWhiteSpace(selectedKayitEkleyen))
        {
            
            
            
            var kekleyenEksikMusteriIds = await _context.Musteriler
                .AsNoTracking()
                .Where(x => x.Kekleyen == null || x.Kekleyen == "")
                .Select(x => x.MusteriID)
                .ToListAsync();

            var latestDetayKekleyen = await GetLatestDetayKekleyenByMusteriAsync(kekleyenEksikMusteriIds);
            var fallbackEslesenIds = latestDetayKekleyen
                .Where(x => string.Equals(x.Value, selectedKayitEkleyen, StringComparison.OrdinalIgnoreCase))
                .Select(x => x.Key)
                .ToList();

            query = query.Where(x =>
                (x.Kekleyen != null && x.Kekleyen.Trim() == selectedKayitEkleyen) ||
                ((x.Kekleyen == null || x.Kekleyen == "") && fallbackEslesenIds.Contains(x.MusteriID)));
        }

        var selectedUrun = (urun ?? string.Empty).Trim().ToUpperInvariant();
        if (selectedUrun is "OPERASYON" or "VPOS" or "MOBIL")
        {
            var urunMusteriIds = GetEffectiveUrunMusteriIds(selectedUrun);
            query = query.Where(x => urunMusteriIds.Contains(x.MusteriID));
        }

        var totalCount = await query.CountAsync();

        
        
        var tumMusteriler = await _context.Musteriler
            .AsNoTracking()
            .Select(x => new { x.Durum, x.Teknoloji, x.KayitTarihi })
            .ToListAsync();

        static string NormalizeStatus(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            var normalized = value.Trim().Normalize(NormalizationForm.FormD);
            var chars = normalized
                .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                .ToArray();
            return new string(chars)
                .Normalize(NormalizationForm.FormC)
                .Replace("ı", "i")
                .Replace("İ", "i")
                .ToUpperInvariant()
                .Replace(" ", string.Empty);
        }

        bool StatusIs(string? value, params string[] expected) =>
            expected.Any(e => NormalizeStatus(value) == NormalizeStatus(e));

        ViewData["MusteriToplamCount"] = tumMusteriler.Count;
        ViewData["MusteriAktifCount"] = tumMusteriler.Count(x => StatusIs(x.Durum, "Aktif"));
        ViewData["MusteriBeklemedeCount"] = tumMusteriler.Count(x => StatusIs(x.Durum, "Beklemede"));
        ViewData["MusteriDokumanCount"] = tumMusteriler.Count(x => StatusIs(x.Durum, "Döküman İletildi", "Doküman İletildi", "Dokuman İletildi", "Döküman Gönderildi", "Doküman Gönderildi", "Dokuman Gönderildi"));
        ViewData["MusteriSatisCount"] = tumMusteriler.Count(x => StatusIs(x.Durum, "Satışa Bilgi Verildi", "Satisa Bilgi Verildi", "Satışa Gönderildi", "Satisa Gonderildi"));

        var aylikBaslangiclar = Enumerable.Range(0, 6)
            .Select(i => new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(-5 + i))
            .ToList();
        ViewData["MusteriAylikEtiketler"] = aylikBaslangiclar.Select(x => x.ToString("MMM yy", CultureInfo.GetCultureInfo("en-US"))).ToList();
        ViewData["MusteriAylikSayilar"] = aylikBaslangiclar
            .Select(start => tumMusteriler.Count(x => x.KayitTarihi.HasValue && x.KayitTarihi.Value >= start && x.KayitTarihi.Value < start.AddMonths(1)))
            .ToList();

        var teknolojiGruplari = tumMusteriler
            .Where(x => !string.IsNullOrWhiteSpace(x.Teknoloji))
            .GroupBy(x => x.Teknoloji!.Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => new { Label = g.Key, Count = g.Count() })
            .OrderByDescending(x => x.Count)
            .ThenBy(x => x.Label)
            .Take(6)
            .ToList();
        ViewData["MusteriTeknolojiEtiketler"] = teknolojiGruplari.Select(x => x.Label).ToList();
        ViewData["MusteriTeknolojiSayilar"] = teknolojiGruplari.Select(x => x.Count).ToList();

        var model = await query
            .OrderByDescending(x => x.KayitTarihi)
            .ThenByDescending(x => x.MusteriID)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        await ApplyKekleyenFallbackFromDetayAsync(model);

        var ekAlanlar = GetMusteriEkAlanlari(model.Select(x => x.MusteriID));
        ViewData["MusteriVknById"] = ekAlanlar.ToDictionary(x => x.Key, x => x.Value.Vkn);
        ViewData["MusteriHariciIdById"] = ekAlanlar.ToDictionary(x => x.Key, x => x.Value.HariciMusteriId);

        ViewData["Page"] = page;
        ViewData["PageSize"] = pageSize;
        ViewData["TotalCount"] = totalCount;
        ViewData["Search"] = search;
        ViewData["SelectedDurum"] = durum;
        ViewData["SelectedTeknoloji"] = teknoloji;
        ViewData["SelectedTalepSahibi"] = talepSahibi;
        ViewData["SelectedKayitEkleyen"] = selectedKayitEkleyen;
        ViewData["SelectedUrun"] = selectedUrun;

        ViewData["Durumlar"] = GetParametreDegerleri("Durum");
        ViewData["Teknolojiler"] = GetParametreDegerleri("Teknoloji");
        ViewData["TalepSahipleri"] = GetTalepSahibiDegerleri();
        ViewData["KullaniciSecenekleri"] = GetKullaniciSecenekleri();
        ViewData["KayitEkleyenSecenekleri"] = GetKayitEkleyenSecenekleri();
        ViewData["OperasyonMusteriIds"] = GetEffectiveUrunMusteriIds("OPERASYON");
        ViewData["VposMusteriIds"] = GetEffectiveUrunMusteriIds("VPOS");
        ViewData["MobilMusteriIds"] = GetEffectiveUrunMusteriIds("MOBIL");

        return View(model);
    }

    [HttpGet("/Musteri/Filters")]
    public async Task<IActionResult> Filters()
    {
        var teknolojiler = await _context.Parametreler
            .AsNoTracking()
            .Where(p => p.Tur == "Teknoloji" && p.ParAdi != null && p.ParAdi != "")
            .OrderBy(p => p.ParAdi)
            .Select(p => p.ParAdi!)
            .ToListAsync();

        var talepSahipleri = GetTalepSahibiDegerleri();

        var durumlar = await _context.Parametreler
            .AsNoTracking()
            .Where(p => p.Tur == "Durum" && p.ParAdi != null && p.ParAdi != "")
            .OrderBy(p => p.ParAdi)
            .Select(p => p.ParAdi!)
            .ToListAsync();

        return Json(new
        {
            teknolojiler,
            talepSahipleri,
            durumlar
        });
    }



    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult CreateMusteri(Musteri musteri, string? returnUrl, string[]? urunler, string? VKN, string? HariciMusteriID)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(musteri.Firma))
            {
                TempData["MusteriError"] = "Company name is required.";
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            var now = DateTime.Now;

            musteri.Firma = musteri.Firma.Trim();

            var ekAlanHatasi = ValidateMusteriEkAlanlari(VKN, HariciMusteriID);
            if (ekAlanHatasi != null)
            {
                TempData["MusteriError"] = ekAlanHatasi;
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }
            musteri.FirmaYetkilisi = musteri.FirmaYetkilisi?.Trim();
            musteri.Telefon = musteri.Telefon?.Trim();
            musteri.SiteUrl = musteri.SiteUrl?.Trim();
            musteri.Teknoloji = musteri.Teknoloji?.Trim();
            musteri.Durum = musteri.Durum?.Trim();
            musteri.TalepSahibi = musteri.TalepSahibi?.Trim();
            musteri.Aciklama = musteri.Aciklama?.Trim();
            musteri.Kekleyen = NormalizeKekleyen(musteri.Kekleyen);

            var kullaniciSecenekleri = GetKullaniciSecenekleri();
            if (string.IsNullOrWhiteSpace(musteri.Kekleyen) || !kullaniciSecenekleri.Contains(musteri.Kekleyen, StringComparer.OrdinalIgnoreCase))
            {
                TempData["MusteriError"] = "Please select the user who added the record from the list.";
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            var durumSecenekleri = GetDurumSecenekleri();
            if (string.IsNullOrWhiteSpace(musteri.Durum) || !durumSecenekleri.Contains(musteri.Durum, StringComparer.OrdinalIgnoreCase))
            {
                TempData["MusteriError"] = "Please select a valid status.";
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            var seciliUrunler = (urunler ?? Array.Empty<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim().ToUpperInvariant())
                .Where(x => x is "OPERASYON" or "VPOS" or "MOBIL")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            if (seciliUrunler.Count == 0)
            {
                TempData["MusteriError"] = "En az bir ürün tipi seçmelisiniz: PF, VPOS veya Cüzdan.";
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            musteri.KayitTarihi = now;
            musteri.DurumDegisiklikTarihi = now;
            musteri.DokumanGonderildiMi = null;
            musteri.DokumanGonderimSayisi = 0;
            musteri.DokumanKontrolBaslangicTarihi = null;

            _context.Musteriler.Add(musteri);
            _context.SaveChanges();

            SaveMusteriEkAlanlari(musteri.MusteriID, VKN, HariciMusteriID);

            var musteriIdText = musteri.MusteriID.ToString(CultureInfo.InvariantCulture);
            _context.Parametreler.Add(new Parametre { Tur = ProductConfiguredParamType, ParAdi = musteriIdText });
            if (seciliUrunler.Contains("OPERASYON"))
                _context.Parametreler.Add(new Parametre { Tur = OperasyonCustomerParamType, ParAdi = musteriIdText });
            if (seciliUrunler.Contains("VPOS"))
                _context.Parametreler.Add(new Parametre { Tur = VposCustomerParamType, ParAdi = musteriIdText });
            if (seciliUrunler.Contains("MOBIL"))
                _context.Parametreler.Add(new Parametre { Tur = MobilCustomerParamType, ParAdi = musteriIdText });

            _context.SaveChanges();

            TempData["MusteriOk"] = "Customer added successfully!";
            return RedirectToLocalOr(returnUrl, nameof(Index));
        }
        catch (Exception)
        {
            TempData["MusteriError"] = "Kayıt sırasında beklenmeyen bir hata oluştu.";
            return RedirectToLocalOr(returnUrl, nameof(Index));
        }
    }

    public IActionResult GetMusteri(int id)
    {
        var musteri = _context.Musteriler.Find(id);
        if (musteri == null)
            return NotFound();

        var ekAlanlar = GetMusteriEkAlanlari(new[] { id });
        ekAlanlar.TryGetValue(id, out var ekAlan);

        return Json(new
        {
            musteriID = musteri.MusteriID,
            firma = musteri.Firma,
            vkn = ekAlan.Vkn,
            hariciMusteriID = ekAlan.HariciMusteriId,
            firmaYetkilisi = musteri.FirmaYetkilisi,
            telefon = musteri.Telefon,
            siteUrl = musteri.SiteUrl,
            teknoloji = musteri.Teknoloji,
            durum = musteri.Durum,
            talepSahibi = musteri.TalepSahibi,
            aciklama = musteri.Aciklama,
            kekleyen = musteri.Kekleyen,
            kayitTarihi = musteri.KayitTarihi?.ToString("yyyy-MM-dd"),
            durumDegisiklikTarihi = musteri.DurumDegisiklikTarihi?.ToString("yyyy-MM-dd")
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult UpdateMusteri(Musteri musteri, string? returnUrl, string? VKN, string? HariciMusteriID)
    {
        try
        {
            var existingMusteri = _context.Musteriler.Find(musteri.MusteriID);
            if (existingMusteri == null)
            {
                TempData["MusteriError"] = $"Customer ID {musteri.MusteriID} was not found";
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            var eskiDurum = (existingMusteri.Durum ?? string.Empty).Trim();
            var yeniDurum = (musteri.Durum ?? string.Empty).Trim();

            var durumSecenekleri = GetDurumSecenekleri();
            if (string.IsNullOrWhiteSpace(yeniDurum) || !durumSecenekleri.Contains(yeniDurum, StringComparer.OrdinalIgnoreCase))
            {
                TempData["MusteriError"] = "Please select a valid status.";
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            var durumDegisti = !string.Equals(eskiDurum, yeniDurum, StringComparison.OrdinalIgnoreCase);

            var ekAlanHatasi = ValidateMusteriEkAlanlari(VKN, HariciMusteriID);
            if (ekAlanHatasi != null)
            {
                TempData["MusteriError"] = ekAlanHatasi;
                return RedirectToLocalOr(returnUrl, nameof(Index));
            }

            existingMusteri.Firma = musteri.Firma?.Trim();
            existingMusteri.FirmaYetkilisi = musteri.FirmaYetkilisi?.Trim();
            existingMusteri.Telefon = musteri.Telefon?.Trim();
            existingMusteri.SiteUrl = musteri.SiteUrl?.Trim();
            existingMusteri.Teknoloji = musteri.Teknoloji?.Trim();
            existingMusteri.Durum = yeniDurum;
            existingMusteri.TalepSahibi = musteri.TalepSahibi?.Trim();
            existingMusteri.Aciklama = musteri.Aciklama?.Trim();
            existingMusteri.Kekleyen = NormalizeKekleyen(musteri.Kekleyen);

            if (durumDegisti)
            {
                existingMusteri.DurumDegisiklikTarihi = DateTime.Now;
                existingMusteri.DokumanGonderildiMi = null;
                existingMusteri.DokumanGonderimSayisi = 0;
                existingMusteri.DokumanKontrolBaslangicTarihi = existingMusteri.DurumDegisiklikTarihi;

                _context.MusteriDurumGecmisleri.Add(new MusteriDurumGecmisi
                {
                    MusteriID = existingMusteri.MusteriID,
                    EskiDurum = eskiDurum,
                    YeniDurum = yeniDurum,
                    Aciklama = string.IsNullOrWhiteSpace(musteri.Aciklama)
                        ? "No description entered."
                        : musteri.Aciklama.Trim(),
                    Tarih = existingMusteri.DurumDegisiklikTarihi.Value,
                    DegistirenKullanici = User?.Identity?.Name
                });
            }

            _context.SaveChanges();

            SaveMusteriEkAlanlari(existingMusteri.MusteriID, VKN, HariciMusteriID);

            TempData["MusteriOk"] = "Customer updated successfully!";
            return RedirectToLocalOr(returnUrl, nameof(Index));
        }
        catch (Exception)
        {
            TempData["MusteriError"] = "Güncelleme sırasında beklenmeyen bir hata oluştu.";
            return RedirectToLocalOr(returnUrl, nameof(Index));
        }
    }

    [HttpDelete]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteMusteri(int id)
    {
        var result = await MusteriSilmeHelper.TamamenSilAsync(_context, id);
        return Json(new { success = result.Success, message = result.Message });
    }

    [HttpGet("/Musteri/Data")]
    public async Task<IActionResult> Data(
        int draw,
        int start,
        int length,
        string? firma,
        string? durum,
        string? teknoloji,
        string? talepSahibi,
        string? minDate,
        string? maxDate)
    {
        IQueryable<Musteri> query = _context.Musteriler.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(firma))
        {
            var term = firma.Trim();
            var ekAlanEslesenIds = GetMusteriIdsByEkAlanSearch(term);
            query = query.Where(x =>
                (x.Firma != null && x.Firma.Contains(term)) ||
                ekAlanEslesenIds.Contains(x.MusteriID));
        }

        if (!string.IsNullOrWhiteSpace(durum))
        {
            query = query.Where(x => x.Durum == durum);
        }

        if (!string.IsNullOrWhiteSpace(teknoloji))
        {
            query = query.Where(x => x.Teknoloji == teknoloji);
        }

        if (!string.IsNullOrWhiteSpace(talepSahibi))
        {
            query = query.Where(x => x.TalepSahibi == talepSahibi);
        }

        if (TryParseTrDate(minDate, out var min))
        {
            query = query.Where(x => x.KayitTarihi != null && x.KayitTarihi.Value.Date >= min.Date);
        }

        if (TryParseTrDate(maxDate, out var max))
        {
            query = query.Where(x => x.KayitTarihi != null && x.KayitTarihi.Value.Date <= max.Date);
        }

        var recordsTotal = await _context.Musteriler.AsNoTracking().CountAsync();
        var recordsFiltered = await query.CountAsync();

        query = query
            .OrderByDescending(x => x.KayitTarihi)
            .ThenByDescending(x => x.MusteriID);

        var page = await query
            .Skip(start)
            .Take(length <= 0 ? 25 : length)
            .Select(x => new
            {
                musteriID = x.MusteriID,
                firma = x.Firma,
                firmaYetkilisi = x.FirmaYetkilisi,
                telefon = x.Telefon,
                siteUrl = x.SiteUrl,
                teknoloji = x.Teknoloji,
                durum = x.Durum,
                talepSahibi = x.TalepSahibi,
                kaynak = x.Kaynak,
                kayitEkleyen = x.Kekleyen,
                kayitTarihiText = x.KayitTarihi.HasValue ? x.KayitTarihi.Value.ToString("dd.MM.yyyy") : "-",
                aciklama = x.Aciklama
            })
            .ToListAsync();

        var pageEkAlanlar = GetMusteriEkAlanlari(page.Select(x => x.musteriID));
        var data = page.Select(x =>
        {
            pageEkAlanlar.TryGetValue(x.musteriID, out var ekAlan);
            return new
            {
                x.musteriID,
                x.firma,
                vkn = ekAlan.Vkn,
                hariciMusteriID = ekAlan.HariciMusteriId,
                x.firmaYetkilisi,
                x.telefon,
                x.siteUrl,
                x.teknoloji,
                x.durum,
                x.talepSahibi,
                x.kaynak,
                x.kayitEkleyen,
                x.kayitTarihiText,
                x.aciklama
            };
        }).ToList();

        return Json(new
        {
            draw,
            recordsTotal,
            recordsFiltered,
            data
        });
    }

    [HttpGet("/Musteri/ExportExcelByMonth")]
    public async Task<IActionResult> ExportExcelByMonth(string? month, string? lang)
    {
        var isEn = IsEnglishExport(lang);
        var exportCulture = isEn
            ? CultureInfo.GetCultureInfo("en-US")
            : CultureInfo.GetCultureInfo("tr-TR");

        var rows = await _context.Musteriler
            .AsNoTracking()
            .OrderByDescending(x => x.KayitTarihi)
            .ThenByDescending(x => x.MusteriID)
            .Select(x => new
            {
                x.MusteriID,
                x.Firma,
                x.FirmaYetkilisi,
                x.Telefon,
                x.SiteUrl,
                x.Teknoloji,
                x.Durum,
                x.TalepSahibi,
                x.Kaynak,
                x.KayitTarihi,
                x.Kekleyen,
                x.Aciklama
            })
            .ToListAsync();

        var musteriIds = rows.Select(r => r.MusteriID).Distinct().ToList();

        
        
        var ekAlanlar = GetMusteriEkAlanlari(musteriIds);

        var kekleyenFallbackByMusteri = await GetLatestDetayKekleyenByMusteriAsync(musteriIds);

        var aciklamaRows = new List<ExcelAciklamaSatiri>();

        aciklamaRows.AddRange(rows
            .Where(r => !string.IsNullOrWhiteSpace(r.Aciklama))
            .Select(r => new ExcelAciklamaSatiri
            {
                MusteriID = r.MusteriID,
                Tarih = r.KayitTarihi,
                Aciklama = r.Aciklama,
                Ekleyen = L(isEn, "Sistem", "System")
            }));

        var detayRows = await _context.Detaylar
            .AsNoTracking()
            .Where(d => musteriIds.Contains(d.MusteriID))
            .Select(d => new
            {
                d.MusteriID,
                d.Tarih,
                d.Aciklama,
                d.Kekleyen
            })
            .ToListAsync();

        aciklamaRows.AddRange(detayRows.Select(d => new ExcelAciklamaSatiri
        {
            MusteriID = d.MusteriID,
            Tarih = d.Tarih,
            Aciklama = d.Aciklama,
            Ekleyen = d.Kekleyen
        }));

        var isTakipRows = await _context.JiraYorumlar
            .AsNoTracking()
            .Include(y => y.JiraTask)
            .Where(y => y.JiraTask.MusteriID != null && musteriIds.Contains(y.JiraTask.MusteriID!.Value))
            .Select(y => new
            {
                MusteriID = y.JiraTask.MusteriID!.Value,
                y.Tarih,
                Aciklama = y.YorumMetni,
                y.Ekleyen
            })
            .ToListAsync();

        aciklamaRows.AddRange(isTakipRows.Select(y => new ExcelAciklamaSatiri
        {
            MusteriID = y.MusteriID,
            Tarih = y.Tarih,
            Aciklama = y.Aciklama,
            Ekleyen = y.Ekleyen
        }));

        aciklamaRows = aciklamaRows
            .Where(x => !string.IsNullOrWhiteSpace(x.Aciklama))
            .Where(x => !string.Equals(x.Aciklama!.Trim(), "No description entered.", StringComparison.OrdinalIgnoreCase))
            .Where(x => !string.Equals(x.Aciklama!.Trim(), "Açıklama girilmedi", StringComparison.OrdinalIgnoreCase))
            .Where(x => !x.Aciklama!.Contains("Durum Değişikliği", StringComparison.OrdinalIgnoreCase))
            .Where(x => !x.Aciklama!.Contains("Status Change", StringComparison.OrdinalIgnoreCase))
            .GroupBy(x => new
            {
                x.MusteriID,
                Tarih = x.Tarih?.ToString("yyyyMMddHHmm", CultureInfo.InvariantCulture) ?? "",
                Aciklama = NormalizeAciklama(x.Aciklama)
            })
            .Select(g => g.First())
            .OrderBy(x => x.MusteriID)
            .ThenByDescending(x => x.Tarih)
            .ToList();

        using var ms = new MemoryStream();

        using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
        {
            var workbookPart = document.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();

            var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = CreateMusteriStylesheet();
            stylesPart.Stylesheet.Save();

            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var worksheet = new Worksheet();
            var sheetData = new SheetData();

            worksheet.Append(new Columns(
                CreateColumn(1, 1, 10),  
                CreateColumn(2, 2, 20),  
                CreateColumn(3, 3, 16),  
                CreateColumn(4, 4, 12),  
                CreateColumn(5, 5, 12),  
                CreateColumn(6, 6, 18),  
                CreateColumn(7, 7, 22),  
                CreateColumn(8, 8, 24),  
                CreateColumn(9, 9, 26),  
                CreateColumn(10, 10, 18), 
                CreateColumn(11, 11, 28), 
                CreateColumn(12, 12, 18), 
                CreateColumn(13, 13, 22), 
                CreateColumn(14, 14, 22), 
                CreateColumn(15, 15, 20), 
                CreateColumn(16, 16, 22), 
                CreateColumn(17, 17, 40)  
            ));

            worksheet.Append(sheetData);

            uint currentRow = 1;

            var header = new Row { RowIndex = currentRow };
            header.Append(
                CreateTextCell("A", currentRow, L(isEn, "Sistem ID", "System ID"), 1),
                CreateTextCell("B", currentRow, L(isEn, "Müşteri ID", "Customer ID"), 1),
                CreateTextCell("C", currentRow, "VKN", 1),
                CreateTextCell("D", currentRow, L(isEn, "Kayıt Yılı", "Created Year"), 1),
                CreateTextCell("E", currentRow, L(isEn, "Kayıt Ay No", "Created Month No"), 1),
                CreateTextCell("F", currentRow, L(isEn, "Kayıt Ay", "Created Month"), 1),
                CreateTextCell("G", currentRow, L(isEn, "Kayıt Tarihi", "Created Date"), 1),
                CreateTextCell("H", currentRow, L(isEn, "Firma", "Company"), 1),
                CreateTextCell("I", currentRow, L(isEn, "Yetkili", "Authorized Person"), 1),
                CreateTextCell("J", currentRow, L(isEn, "Telefon", "Phone"), 1),
                CreateTextCell("K", currentRow, "SiteUrl", 1),
                CreateTextCell("L", currentRow, L(isEn, "Teknoloji", "Technology"), 1),
                CreateTextCell("M", currentRow, L(isEn, "Durum", "Status"), 1),
                CreateTextCell("N", currentRow, L(isEn, "Talep Sahibi", "Requester"), 1),
                CreateTextCell("O", currentRow, L(isEn, "Kaynak", "Source"), 1),
                CreateTextCell("P", currentRow, L(isEn, "Ekleyen", "Created By"), 1),
                CreateTextCell("Q", currentRow, L(isEn, "Açıklama", "Description"), 1)
            );

            sheetData.Append(header);

            foreach (var r in rows)
            {
                ekAlanlar.TryGetValue(r.MusteriID, out var ekAlan);

                var musteriAciklamalari = aciklamaRows
                    .Where(x => x.MusteriID == r.MusteriID)
                    .ToList();

                var kayitTarihi = r.KayitTarihi;
                var kayitYil = kayitTarihi?.Year.ToString(CultureInfo.InvariantCulture) ?? "-";
                var kayitAyNo = kayitTarihi?.Month.ToString("00", CultureInfo.InvariantCulture) ?? "-";
                var kayitAy = kayitTarihi?.ToString("MMMM", exportCulture) ?? "-";
                var kayitTarihiText = kayitTarihi?.ToString("dd.MM.yyyy HH:mm", exportCulture) ?? "-";

                void AppendMusteriSatiri(string? aciklama)
                {
                    currentRow++;
                    var row = new Row { RowIndex = currentRow };
                    row.Append(
                        CreateNumberCell("A", currentRow, r.MusteriID.ToString(CultureInfo.InvariantCulture), 0),
                        CreateTextCell("B", currentRow, ekAlan.HariciMusteriId, 0),
                        CreateTextCell("C", currentRow, ekAlan.Vkn, 0),
                        CreateTextCell("D", currentRow, kayitYil, 0),
                        CreateTextCell("E", currentRow, kayitAyNo, 0),
                        CreateTextCell("F", currentRow, kayitAy, 0),
                        CreateTextCell("G", currentRow, kayitTarihiText, 0),
                        CreateTextCell("H", currentRow, r.Firma, 0),
                        CreateTextCell("I", currentRow, r.FirmaYetkilisi, 0),
                        CreateTextCell("J", currentRow, r.Telefon, 0),
                        CreateTextCell("K", currentRow, r.SiteUrl, 0),
                        CreateTextCell("L", currentRow, r.Teknoloji, 0),
                        CreateTextCell("M", currentRow, TranslateExportValue(r.Durum, isEn), 0),
                        CreateTextCell("N", currentRow, r.TalepSahibi, 0),
                        CreateTextCell("O", currentRow, r.Kaynak, 0),
                        CreateTextCell("P", currentRow, ResolveKekleyen(r.MusteriID, r.Kekleyen, kekleyenFallbackByMusteri), 0),
                        CreateTextCell("Q", currentRow, aciklama, 0)
                    );
                    sheetData.Append(row);
                }

                if (!musteriAciklamalari.Any())
                {
                    AppendMusteriSatiri(string.Empty);
                    continue;
                }

                foreach (var a in musteriAciklamalari)
                {
                    AppendMusteriSatiri(FormatExcelAciklamaSatiri(a.Tarih, a.Aciklama, a.Ekleyen));
                }
            }

            var lastRowIndex = currentRow == 1 ? 1U : currentRow;
            var filterRange = $"A1:Q{lastRowIndex}";

            worksheet.Append(new AutoFilter { Reference = filterRange });

            if (rows.Any())
            {
                var tableDefinitionPart = worksheetPart.AddNewPart<TableDefinitionPart>();
                tableDefinitionPart.Table = new Table
                {
                    Id = 1U,
                    Name = "MusterilerTablo",
                    DisplayName = "MusterilerTablo",
                    Reference = filterRange,
                    TotalsRowShown = false
                };

                tableDefinitionPart.Table.AppendChild(new AutoFilter { Reference = filterRange });
                tableDefinitionPart.Table.AppendChild(new TableColumns(
                    new TableColumn { Id = 1U, Name = L(isEn, "Sistem ID", "System ID") },
                    new TableColumn { Id = 2U, Name = L(isEn, "Müşteri ID", "Customer ID") },
                    new TableColumn { Id = 3U, Name = "VKN" },
                    new TableColumn { Id = 4U, Name = L(isEn, "Kayıt Yılı", "Created Year") },
                    new TableColumn { Id = 5U, Name = L(isEn, "Kayıt Ay No", "Created Month No") },
                    new TableColumn { Id = 6U, Name = L(isEn, "Kayıt Ay", "Created Month") },
                    new TableColumn { Id = 7U, Name = L(isEn, "Kayıt Tarihi", "Created Date") },
                    new TableColumn { Id = 8U, Name = L(isEn, "Firma", "Company") },
                    new TableColumn { Id = 9U, Name = L(isEn, "Yetkili", "Authorized Person") },
                    new TableColumn { Id = 10U, Name = L(isEn, "Telefon", "Phone") },
                    new TableColumn { Id = 11U, Name = "SiteUrl" },
                    new TableColumn { Id = 12U, Name = L(isEn, "Teknoloji", "Technology") },
                    new TableColumn { Id = 13U, Name = L(isEn, "Durum", "Status") },
                    new TableColumn { Id = 14U, Name = L(isEn, "Talep Sahibi", "Requester") },
                    new TableColumn { Id = 15U, Name = L(isEn, "Kaynak", "Source") },
                    new TableColumn { Id = 16U, Name = L(isEn, "Ekleyen", "Created By") },
                    new TableColumn { Id = 17U, Name = L(isEn, "Açıklama", "Description") }
                )
                { Count = 17U });

                tableDefinitionPart.Table.AppendChild(new TableStyleInfo
                {
                    Name = "TableStyleMedium2",
                    ShowFirstColumn = false,
                    ShowLastColumn = false,
                    ShowRowStripes = true,
                    ShowColumnStripes = false
                });

                tableDefinitionPart.Table.Save();

                var tableParts = new TableParts { Count = 1U };
                tableParts.Append(new TablePart { Id = worksheetPart.GetIdOfPart(tableDefinitionPart) });
                worksheet.Append(tableParts);
            }

            worksheetPart.Worksheet = worksheet;
            worksheetPart.Worksheet.Save();

            var sheets = workbookPart.Workbook.AppendChild(new Sheets());
            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = "Musteriler"
            });

            workbookPart.Workbook.Save();
        }

        ms.Position = 0;

        return File(
            ms.ToArray(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            isEn
                ? $"Customers_AllMonths_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                : $"Musteriler_TumAylar_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
    }


    
    
    
    
    
    
    
    [HttpGet("/Musteri/ExportMusteriOzetExcel")]
    public async Task<IActionResult> ExportMusteriOzetExcel()
    {
        var rows = await _context.Musteriler
            .AsNoTracking()
            .OrderBy(x => x.Firma)
            .ThenBy(x => x.MusteriID)
            .Select(x => new
            {
                x.MusteriID,
                x.Firma,
                x.Durum
            })
            .ToListAsync();

        
        var ekAlanlar = GetMusteriEkAlanlari(rows.Select(x => x.MusteriID));

        var durumOzeti = rows
            .GroupBy(
                x => string.IsNullOrWhiteSpace(x.Durum)
                    ? "Durum Belirtilmemiş"
                    : x.Durum!.Trim(),
                StringComparer.OrdinalIgnoreCase)
            .Select(g => new
            {
                Durum = g.Key,
                MusteriSayisi = g.Count()
            })
            .OrderByDescending(x => x.MusteriSayisi)
            .ThenBy(x => x.Durum)
            .ToList();

        using var ms = new MemoryStream();

        using (var document = SpreadsheetDocument.Create(
                   ms,
                   SpreadsheetDocumentType.Workbook,
                   true))
        {
            var workbookPart = document.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();

            var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = CreateMusteriStylesheet();
            stylesPart.Stylesheet.Save();

            var sheets = workbookPart.Workbook.AppendChild(new Sheets());

            
            
            
            var customersWorksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var customersSheetData = new SheetData();
            var customersWorksheet = new Worksheet(
                new Columns(
                    CreateColumn(1, 1, 18),
                    CreateColumn(2, 2, 22),
                    CreateColumn(3, 3, 18),
                    CreateColumn(4, 4, 42),
                    CreateColumn(5, 5, 28)),
                customersSheetData);

            uint customerRowIndex = 1;

            var customerHeader = new Row { RowIndex = customerRowIndex };
            customerHeader.Append(
                CreateTextCell("A", customerRowIndex, "Sistem Müşteri ID", 1),
                CreateTextCell("B", customerRowIndex, "Müşteri ID", 1),
                CreateTextCell("C", customerRowIndex, "VKN", 1),
                CreateTextCell("D", customerRowIndex, "Firma", 1),
                CreateTextCell("E", customerRowIndex, "Durum", 1));
            customersSheetData.Append(customerHeader);

            foreach (var item in rows)
            {
                ekAlanlar.TryGetValue(item.MusteriID, out var extra);

                customerRowIndex++;
                var row = new Row { RowIndex = customerRowIndex };
                row.Append(
                    CreateNumberCell(
                        "A",
                        customerRowIndex,
                        item.MusteriID.ToString(CultureInfo.InvariantCulture),
                        0),
                    CreateTextCell(
                        "B",
                        customerRowIndex,
                        extra.HariciMusteriId,
                        0),
                    CreateTextCell(
                        "C",
                        customerRowIndex,
                        extra.Vkn,
                        0),
                    CreateTextCell(
                        "D",
                        customerRowIndex,
                        item.Firma,
                        0),
                    CreateTextCell(
                        "E",
                        customerRowIndex,
                        item.Durum,
                        0));

                customersSheetData.Append(row);
            }

            var customerLastRow = Math.Max(1U, customerRowIndex);
            customersWorksheet.Append(new AutoFilter
            {
                Reference = $"A1:E{customerLastRow}"
            });

            customersWorksheetPart.Worksheet = customersWorksheet;
            customersWorksheetPart.Worksheet.Save();

            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(customersWorksheetPart),
                SheetId = 1U,
                Name = "Musteriler"
            });

            
            
            
            var summaryWorksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var summarySheetData = new SheetData();
            var summaryWorksheet = new Worksheet(
                new Columns(
                    CreateColumn(1, 1, 36),
                    CreateColumn(2, 2, 20)),
                summarySheetData);

            uint summaryRowIndex = 1;

            var summaryHeader = new Row { RowIndex = summaryRowIndex };
            summaryHeader.Append(
                CreateTextCell("A", summaryRowIndex, "Durum", 1),
                CreateTextCell("B", summaryRowIndex, "Müşteri Sayısı", 1));
            summarySheetData.Append(summaryHeader);

            foreach (var item in durumOzeti)
            {
                summaryRowIndex++;
                var row = new Row { RowIndex = summaryRowIndex };
                row.Append(
                    CreateTextCell("A", summaryRowIndex, item.Durum, 0),
                    CreateNumberCell(
                        "B",
                        summaryRowIndex,
                        item.MusteriSayisi.ToString(CultureInfo.InvariantCulture),
                        0));
                summarySheetData.Append(row);
            }

            summaryRowIndex++;
            var totalRow = new Row { RowIndex = summaryRowIndex };
            totalRow.Append(
                CreateTextCell("A", summaryRowIndex, "TOPLAM", 1),
                CreateNumberCell(
                    "B",
                    summaryRowIndex,
                    rows.Count.ToString(CultureInfo.InvariantCulture),
                    1));
            summarySheetData.Append(totalRow);

            summaryWorksheet.Append(new AutoFilter
            {
                Reference = $"A1:B{Math.Max(1U, summaryRowIndex - 1)}"
            });

            summaryWorksheetPart.Worksheet = summaryWorksheet;
            summaryWorksheetPart.Worksheet.Save();

            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(summaryWorksheetPart),
                SheetId = 2U,
                Name = "DurumOzeti"
            });

            workbookPart.Workbook.Save();
        }

        ms.Position = 0;

        return File(
            ms.ToArray(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"Musteri_Ozet_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
    }

    [HttpGet("/Musteri/ExportNewCustomersExcelByMonth")]
    public async Task<IActionResult> ExportNewCustomersExcelByMonth(string? month, string? lang)
    {
        var isEn = IsEnglishExport(lang);
        var exportCulture = isEn
            ? CultureInfo.GetCultureInfo("en-US")
            : CultureInfo.GetCultureInfo("tr-TR");

        
        
        
        var currentMonthStart = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1, 0, 0, 0);
        var monthStart = currentMonthStart.AddMonths(-1);
        var monthEnd = currentMonthStart;

        var query = _context.Musteriler
            .AsNoTracking()
            .Where(x =>
                x.KayitTarihi != null &&
                x.KayitTarihi >= monthStart &&
                x.KayitTarihi < monthEnd);

        var rows = await query
            .OrderByDescending(x => x.KayitTarihi)
            .ThenByDescending(x => x.MusteriID)
            .Select(x => new
            {
                x.MusteriID,
                x.Firma,
                x.FirmaYetkilisi,
                x.Telefon,
                x.SiteUrl,
                x.Teknoloji,
                x.Durum,
                x.TalepSahibi,
                x.Kaynak,
                x.KayitTarihi,
                x.Kekleyen,
                x.Aciklama
            })
            .ToListAsync();

        var musteriIds = rows.Select(r => r.MusteriID).ToList();
        var kekleyenFallbackByMusteri = await GetLatestDetayKekleyenByMusteriAsync(musteriIds);

        var yorumlarByMusteri = await _context.JiraYorumlar
            .AsNoTracking()
            .Include(y => y.JiraTask)
            .Where(y => y.JiraTask.MusteriID != null && musteriIds.Contains(y.JiraTask.MusteriID!.Value))
            .Select(y => new
            {
                MusteriID = y.JiraTask.MusteriID!.Value,
                y.JiraTask.JiraId,
                y.JiraTask.TalepKonusu,
                y.Ekleyen,
                y.YorumMetni,
                y.Tarih
            })
            .OrderBy(y => y.MusteriID)
            .ThenBy(y => y.Tarih)
            .ToListAsync();

        var yorumDict = yorumlarByMusteri
            .GroupBy(y => y.MusteriID)
            .ToDictionary(
                g => g.Key,
                g => string.Join(" || ", g.Select(y =>
                    $"[{y.Tarih:dd.MM.yyyy}] {y.JiraId} - {y.TalepKonusu} | {y.Ekleyen}: {y.YorumMetni}"))
            );

        using var ms = new MemoryStream();

        using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
        {
            var workbookPart = document.AddWorkbookPart();
            workbookPart.Workbook = new Workbook();

            var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
            stylesPart.Stylesheet = CreateMusteriStylesheet();
            stylesPart.Stylesheet.Save();

            var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            var worksheet = new Worksheet();
            var sheetData = new SheetData();

            worksheet.Append(new Columns(
                CreateColumn(1, 1, 10),
                CreateColumn(2, 2, 12),
                CreateColumn(3, 3, 12),
                CreateColumn(4, 4, 18),
                CreateColumn(5, 5, 22),
                CreateColumn(6, 6, 24),
                CreateColumn(7, 7, 26),
                CreateColumn(8, 8, 18),
                CreateColumn(9, 9, 28),
                CreateColumn(10, 10, 18),
                CreateColumn(11, 11, 18),
                CreateColumn(12, 12, 20),
                CreateColumn(13, 13, 18),
                CreateColumn(14, 14, 22),
                CreateColumn(15, 15, 40),
                CreateColumn(16, 16, 70)
            ));

            worksheet.Append(sheetData);

            uint currentRow = 1;
            var header = new Row { RowIndex = currentRow };
            header.Append(
                CreateTextCell("A", currentRow, "ID", 1),
                CreateTextCell("B", currentRow, L(isEn, "Kayıt Yılı", "Created Year"), 1),
                CreateTextCell("C", currentRow, L(isEn, "Kayıt Ay No", "Created Month No"), 1),
                CreateTextCell("D", currentRow, L(isEn, "Kayıt Ay", "Created Month"), 1),
                CreateTextCell("E", currentRow, L(isEn, "Kayıt Tarihi", "Created Date"), 1),
                CreateTextCell("F", currentRow, L(isEn, "Firma", "Company"), 1),
                CreateTextCell("G", currentRow, L(isEn, "Yetkili", "Authorized Person"), 1),
                CreateTextCell("H", currentRow, L(isEn, "Telefon", "Phone"), 1),
                CreateTextCell("I", currentRow, "SiteUrl", 1),
                CreateTextCell("J", currentRow, L(isEn, "Teknoloji", "Technology"), 1),
                CreateTextCell("K", currentRow, L(isEn, "Durum", "Status"), 1),
                CreateTextCell("L", currentRow, L(isEn, "Talep Sahibi", "Requester"), 1),
                CreateTextCell("M", currentRow, L(isEn, "Kaynak", "Source"), 1),
                CreateTextCell("N", currentRow, L(isEn, "Ekleyen", "Created By"), 1),
                CreateTextCell("O", currentRow, L(isEn, "Açıklama", "Description"), 1),
                CreateTextCell("P", currentRow, L(isEn, "İş Takip Yorumları", "Work Tracking Comments"), 1)
            );
            sheetData.Append(header);

            foreach (var r in rows)
            {
                yorumDict.TryGetValue(r.MusteriID, out var yorumlar);
                currentRow++;

                var kayitTarihi = r.KayitTarihi;
                var kayitYil = kayitTarihi?.Year.ToString(CultureInfo.InvariantCulture) ?? "-";
                var kayitAyNo = kayitTarihi?.Month.ToString("00", CultureInfo.InvariantCulture) ?? "-";
                var kayitAy = kayitTarihi?.ToString("MMMM", exportCulture) ?? "-";
                var kayitTarihiText = kayitTarihi?.ToString("dd.MM.yyyy HH:mm", exportCulture) ?? "-";


                var row = new Row { RowIndex = currentRow };
                row.Append(
                    CreateNumberCell("A", currentRow, r.MusteriID.ToString(CultureInfo.InvariantCulture), 0),
                    CreateTextCell("B", currentRow, kayitYil, 0),
                    CreateTextCell("C", currentRow, kayitAyNo, 0),
                    CreateTextCell("D", currentRow, kayitAy, 0),
                    CreateTextCell("E", currentRow, kayitTarihiText, 0),
                    CreateTextCell("F", currentRow, r.Firma, 0),
                    CreateTextCell("G", currentRow, r.FirmaYetkilisi, 0),
                    CreateTextCell("H", currentRow, r.Telefon, 0),
                    CreateTextCell("I", currentRow, r.SiteUrl, 0),
                    CreateTextCell("J", currentRow, r.Teknoloji, 0),
                    CreateTextCell("K", currentRow, TranslateExportValue(r.Durum, isEn), 0),
                    CreateTextCell("L", currentRow, r.TalepSahibi, 0),
                    CreateTextCell("M", currentRow, r.Kaynak, 0),
                    CreateTextCell("N", currentRow, ResolveKekleyen(r.MusteriID, r.Kekleyen, kekleyenFallbackByMusteri), 0),
                    CreateTextCell("O", currentRow, r.Aciklama, 0),
                    CreateTextCell("P", currentRow, yorumlar, 0)
                );

                sheetData.Append(row);
            }

            var lastRowIndex = currentRow == 1 ? 1U : currentRow;
            var filterRange = $"A1:P{lastRowIndex}";
            worksheet.Append(new AutoFilter { Reference = filterRange });

            if (rows.Any())
            {
                var tableDefinitionPart = worksheetPart.AddNewPart<TableDefinitionPart>();
                tableDefinitionPart.Table = new Table
                {
                    Id = 1U,
                    Name = "YeniMusterilerTablo",
                    DisplayName = "YeniMusterilerTablo",
                    Reference = filterRange,
                    TotalsRowShown = false
                };

                tableDefinitionPart.Table.AppendChild(new AutoFilter { Reference = filterRange });
                tableDefinitionPart.Table.AppendChild(new TableColumns(
                    new TableColumn { Id = 1U, Name = "ID" },
                    new TableColumn { Id = 2U, Name = L(isEn, "Kayıt Yılı", "Created Year") },
                    new TableColumn { Id = 3U, Name = L(isEn, "Kayıt Ay No", "Created Month No") },
                    new TableColumn { Id = 4U, Name = L(isEn, "Kayıt Ay", "Created Month") },
                    new TableColumn { Id = 5U, Name = L(isEn, "Kayıt Tarihi", "Created Date") },
                    new TableColumn { Id = 6U, Name = L(isEn, "Firma", "Company") },
                    new TableColumn { Id = 7U, Name = L(isEn, "Yetkili", "Authorized Person") },
                    new TableColumn { Id = 8U, Name = L(isEn, "Telefon", "Phone") },
                    new TableColumn { Id = 9U, Name = "SiteUrl" },
                    new TableColumn { Id = 10U, Name = L(isEn, "Teknoloji", "Technology") },
                    new TableColumn { Id = 11U, Name = L(isEn, "Durum", "Status") },
                    new TableColumn { Id = 12U, Name = L(isEn, "Talep Sahibi", "Requester") },
                    new TableColumn { Id = 13U, Name = L(isEn, "Kaynak", "Source") },
                    new TableColumn { Id = 14U, Name = L(isEn, "Ekleyen", "Created By") },
                    new TableColumn { Id = 15U, Name = L(isEn, "Açıklama", "Description") },
                    new TableColumn { Id = 16U, Name = L(isEn, "İş Takip Yorumları", "Work Tracking Comments") }
                )
                { Count = 16U });

                tableDefinitionPart.Table.AppendChild(new TableStyleInfo
                {
                    Name = "TableStyleMedium2",
                    ShowFirstColumn = false,
                    ShowLastColumn = false,
                    ShowRowStripes = true,
                    ShowColumnStripes = false
                });

                tableDefinitionPart.Table.Save();

                var tableParts = new TableParts { Count = 1U };
                tableParts.Append(new TablePart { Id = worksheetPart.GetIdOfPart(tableDefinitionPart) });
                worksheet.Append(tableParts);
            }

            worksheetPart.Worksheet = worksheet;
            worksheetPart.Worksheet.Save();

            var sheets = workbookPart.Workbook.AppendChild(new Sheets());
            sheets.Append(new Sheet
            {
                Id = workbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = isEn ? "NewCustomers" : "YeniMusteriler"
            });

            workbookPart.Workbook.Save();
        }

        ms.Position = 0;
        var ayLabel = $"{monthStart:yyyy-MM}";
        return File(
            ms.ToArray(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            isEn ? $"NewCustomers_LastMonth_{ayLabel}.xlsx" : $"YeniMusteriler_GecenAy_{ayLabel}.xlsx");
    }


    private static bool TryParseTrDate(string? s, out DateTime dt)
    {
        dt = default;
        if (string.IsNullOrWhiteSpace(s)) return false;

        return DateTime.TryParseExact(
            s.Trim(),
            new[] { "dd.MM.yyyy", "d.M.yyyy", "yyyy-MM-dd" },
            new CultureInfo("tr-TR"),
            DateTimeStyles.None,
            out dt);
    }

    private static Stylesheet CreateMusteriStylesheet()
    {
        return new Stylesheet(
            new Fonts(
                new Font(new FontSize { Val = 11 }),
                new Font(new Bold(), new FontSize { Val = 11 }, new Color { Rgb = HexBinaryValue.FromString("FFFFFFFF") })
            ),
            new Fills(
                new Fill(new PatternFill { PatternType = PatternValues.None }),
                new Fill(new PatternFill { PatternType = PatternValues.Gray125 }),
                new Fill(new PatternFill(
                    new ForegroundColor { Rgb = HexBinaryValue.FromString("1D4ED8") },
                    new BackgroundColor { Indexed = 64U }
                )
                { PatternType = PatternValues.Solid })
            ),
            new Borders(
                new Border(new LeftBorder(), new RightBorder(), new TopBorder(), new BottomBorder(), new DiagonalBorder()),
                new Border(
                    new LeftBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                    new RightBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                    new TopBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                    new BottomBorder { Style = BorderStyleValues.Thin, Color = new Color { Auto = true } },
                    new DiagonalBorder())
            ),
            new CellFormats(
                new CellFormat(),
                new CellFormat
                {
                    FontId = 1U,
                    FillId = 2U,
                    BorderId = 1U,
                    ApplyFont = true,
                    ApplyFill = true,
                    ApplyBorder = true,
                    Alignment = new Alignment
                    {
                        Horizontal = HorizontalAlignmentValues.Center,
                        Vertical = VerticalAlignmentValues.Center,
                        WrapText = true
                    },
                    ApplyAlignment = true
                }
            )
        );
    }

    private static Column CreateColumn(uint min, uint max, double width)
    {
        return new Column
        {
            Min = min,
            Max = max,
            Width = width,
            CustomWidth = true
        };
    }

    private static Cell CreateTextCell(string columnName, uint rowIndex, string? text, uint styleIndex)
    {
        return new Cell
        {
            CellReference = columnName + rowIndex,
            DataType = CellValues.InlineString,
            StyleIndex = styleIndex,
            InlineString = new InlineString(new Text(text ?? string.Empty))
        };
    }

    private static Cell CreateNumberCell(string columnName, uint rowIndex, string value, uint styleIndex)
    {
        return new Cell
        {
            CellReference = columnName + rowIndex,
            CellValue = new CellValue(value),
            DataType = CellValues.Number,
            StyleIndex = styleIndex
        };
    }
    private static string FormatExcelAciklamaSatiri(DateTime? tarih, string? aciklama, string? ekleyen)
    {
        aciklama = (aciklama ?? string.Empty).Trim();

        if (string.IsNullOrWhiteSpace(aciklama))
            return string.Empty;

        var tarihText = tarih.HasValue
            ? tarih.Value.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("tr-TR"))
            : "-";

        ekleyen = string.IsNullOrWhiteSpace(ekleyen) ? "Sistem" : ekleyen.Trim();

        return $"{tarihText} -- {aciklama} -- {ekleyen}";
    }

    private static string NormalizeAciklama(string? value)
    {
        return (value ?? string.Empty)
            .Trim()
            .ToUpperInvariant()
            .Replace("\r", string.Empty)
            .Replace("\n", " ")
            .Replace("  ", " ");
    }

    
    
    private sealed class ExcelAciklamaSatiri
    {
        public int MusteriID { get; set; }
        public DateTime? Tarih { get; set; }
        public string? Aciklama { get; set; }
        public string? Ekleyen { get; set; }
    }

} 
