﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BtOperasyonTakip.ViewComponents;

public class BildirimZiliViewComponent : ViewComponent
{
    private readonly AppDbContext _context;
    private readonly BildirimStore _bildirimStore;

    public BildirimZiliViewComponent(AppDbContext context)
    {
        _context = context;
        _bildirimStore = new BildirimStore(context);
    }

    public IViewComponentResult Invoke()
    {
        if (!(UserClaimsPrincipal?.Identity?.IsAuthenticated ?? false))
            return Content(string.Empty);

        var userId = ResolveCurrentUserId();
        if (!userId.HasValue)
            return Content(string.Empty);

        var bildirimler = _bildirimStore.Listele(userId.Value, false, 8);
        ViewBag.OkunmamisSayisi = _bildirimStore.OkunmamisSayisi(userId.Value);

        return View(bildirimler);
    }

    private int? ResolveCurrentUserId()
    {
        var claimValue = UserClaimsPrincipal?.FindFirst("UserId")?.Value;
        if (int.TryParse(claimValue, out var claimUserId) && claimUserId > 0)
            return claimUserId;

        var name = (UserClaimsPrincipal?.Identity?.Name ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(name))
            return null;

        return _context.Users
            .AsNoTracking()
            .Where(x => x.UserName == name || x.Email == name || x.FullName == name)
            .Select(x => (int?)x.Id)
            .FirstOrDefault();
    }
}
